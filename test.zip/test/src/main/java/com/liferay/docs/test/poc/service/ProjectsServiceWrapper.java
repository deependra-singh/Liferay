package com.liferay.docs.test.poc.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link ProjectsService}.
 *
 * @author anuragch
 * @see ProjectsService
 * @generated
 */
public class ProjectsServiceWrapper implements ProjectsService,
    ServiceWrapper<ProjectsService> {
    private ProjectsService _projectsService;

    public ProjectsServiceWrapper(ProjectsService projectsService) {
        _projectsService = projectsService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _projectsService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _projectsService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _projectsService.invokeMethod(name, parameterTypes, arguments);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public ProjectsService getWrappedProjectsService() {
        return _projectsService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedProjectsService(ProjectsService projectsService) {
        _projectsService = projectsService;
    }

    @Override
    public ProjectsService getWrappedService() {
        return _projectsService;
    }

    @Override
    public void setWrappedService(ProjectsService projectsService) {
        _projectsService = projectsService;
    }
}
