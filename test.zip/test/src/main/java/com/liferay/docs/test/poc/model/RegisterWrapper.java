package com.liferay.docs.test.poc.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Register}.
 * </p>
 *
 * @author anuragch
 * @see Register
 * @generated
 */
public class RegisterWrapper implements Register, ModelWrapper<Register> {
    private Register _register;

    public RegisterWrapper(Register register) {
        _register = register;
    }

    @Override
    public Class<?> getModelClass() {
        return Register.class;
    }

    @Override
    public String getModelClassName() {
        return Register.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("registerId", getRegisterId());
        attributes.put("groupId", getGroupId());
        attributes.put("companyId", getCompanyId());
        attributes.put("userId", getUserId());
        attributes.put("userName", getUserName());
        attributes.put("createDate", getCreateDate());
        attributes.put("modifiedDate", getModifiedDate());
        attributes.put("email", getEmail());
        attributes.put("password", getPassword());
        attributes.put("firstname", getFirstname());
        attributes.put("lastname", getLastname());
        attributes.put("country", getCountry());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long registerId = (Long) attributes.get("registerId");

        if (registerId != null) {
            setRegisterId(registerId);
        }

        Long groupId = (Long) attributes.get("groupId");

        if (groupId != null) {
            setGroupId(groupId);
        }

        Long companyId = (Long) attributes.get("companyId");

        if (companyId != null) {
            setCompanyId(companyId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        String userName = (String) attributes.get("userName");

        if (userName != null) {
            setUserName(userName);
        }

        Date createDate = (Date) attributes.get("createDate");

        if (createDate != null) {
            setCreateDate(createDate);
        }

        Date modifiedDate = (Date) attributes.get("modifiedDate");

        if (modifiedDate != null) {
            setModifiedDate(modifiedDate);
        }

        String email = (String) attributes.get("email");

        if (email != null) {
            setEmail(email);
        }

        String password = (String) attributes.get("password");

        if (password != null) {
            setPassword(password);
        }

        String firstname = (String) attributes.get("firstname");

        if (firstname != null) {
            setFirstname(firstname);
        }

        String lastname = (String) attributes.get("lastname");

        if (lastname != null) {
            setLastname(lastname);
        }

        String country = (String) attributes.get("country");

        if (country != null) {
            setCountry(country);
        }
    }

    /**
    * Returns the primary key of this register.
    *
    * @return the primary key of this register
    */
    @Override
    public long getPrimaryKey() {
        return _register.getPrimaryKey();
    }

    /**
    * Sets the primary key of this register.
    *
    * @param primaryKey the primary key of this register
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _register.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this register.
    *
    * @return the uuid of this register
    */
    @Override
    public java.lang.String getUuid() {
        return _register.getUuid();
    }

    /**
    * Sets the uuid of this register.
    *
    * @param uuid the uuid of this register
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _register.setUuid(uuid);
    }

    /**
    * Returns the register ID of this register.
    *
    * @return the register ID of this register
    */
    @Override
    public long getRegisterId() {
        return _register.getRegisterId();
    }

    /**
    * Sets the register ID of this register.
    *
    * @param registerId the register ID of this register
    */
    @Override
    public void setRegisterId(long registerId) {
        _register.setRegisterId(registerId);
    }

    /**
    * Returns the group ID of this register.
    *
    * @return the group ID of this register
    */
    @Override
    public long getGroupId() {
        return _register.getGroupId();
    }

    /**
    * Sets the group ID of this register.
    *
    * @param groupId the group ID of this register
    */
    @Override
    public void setGroupId(long groupId) {
        _register.setGroupId(groupId);
    }

    /**
    * Returns the company ID of this register.
    *
    * @return the company ID of this register
    */
    @Override
    public long getCompanyId() {
        return _register.getCompanyId();
    }

    /**
    * Sets the company ID of this register.
    *
    * @param companyId the company ID of this register
    */
    @Override
    public void setCompanyId(long companyId) {
        _register.setCompanyId(companyId);
    }

    /**
    * Returns the user ID of this register.
    *
    * @return the user ID of this register
    */
    @Override
    public long getUserId() {
        return _register.getUserId();
    }

    /**
    * Sets the user ID of this register.
    *
    * @param userId the user ID of this register
    */
    @Override
    public void setUserId(long userId) {
        _register.setUserId(userId);
    }

    /**
    * Returns the user uuid of this register.
    *
    * @return the user uuid of this register
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _register.getUserUuid();
    }

    /**
    * Sets the user uuid of this register.
    *
    * @param userUuid the user uuid of this register
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _register.setUserUuid(userUuid);
    }

    /**
    * Returns the user name of this register.
    *
    * @return the user name of this register
    */
    @Override
    public java.lang.String getUserName() {
        return _register.getUserName();
    }

    /**
    * Sets the user name of this register.
    *
    * @param userName the user name of this register
    */
    @Override
    public void setUserName(java.lang.String userName) {
        _register.setUserName(userName);
    }

    /**
    * Returns the create date of this register.
    *
    * @return the create date of this register
    */
    @Override
    public java.util.Date getCreateDate() {
        return _register.getCreateDate();
    }

    /**
    * Sets the create date of this register.
    *
    * @param createDate the create date of this register
    */
    @Override
    public void setCreateDate(java.util.Date createDate) {
        _register.setCreateDate(createDate);
    }

    /**
    * Returns the modified date of this register.
    *
    * @return the modified date of this register
    */
    @Override
    public java.util.Date getModifiedDate() {
        return _register.getModifiedDate();
    }

    /**
    * Sets the modified date of this register.
    *
    * @param modifiedDate the modified date of this register
    */
    @Override
    public void setModifiedDate(java.util.Date modifiedDate) {
        _register.setModifiedDate(modifiedDate);
    }

    /**
    * Returns the email of this register.
    *
    * @return the email of this register
    */
    @Override
    public java.lang.String getEmail() {
        return _register.getEmail();
    }

    /**
    * Sets the email of this register.
    *
    * @param email the email of this register
    */
    @Override
    public void setEmail(java.lang.String email) {
        _register.setEmail(email);
    }

    /**
    * Returns the password of this register.
    *
    * @return the password of this register
    */
    @Override
    public java.lang.String getPassword() {
        return _register.getPassword();
    }

    /**
    * Sets the password of this register.
    *
    * @param password the password of this register
    */
    @Override
    public void setPassword(java.lang.String password) {
        _register.setPassword(password);
    }

    /**
    * Returns the firstname of this register.
    *
    * @return the firstname of this register
    */
    @Override
    public java.lang.String getFirstname() {
        return _register.getFirstname();
    }

    /**
    * Sets the firstname of this register.
    *
    * @param firstname the firstname of this register
    */
    @Override
    public void setFirstname(java.lang.String firstname) {
        _register.setFirstname(firstname);
    }

    /**
    * Returns the lastname of this register.
    *
    * @return the lastname of this register
    */
    @Override
    public java.lang.String getLastname() {
        return _register.getLastname();
    }

    /**
    * Sets the lastname of this register.
    *
    * @param lastname the lastname of this register
    */
    @Override
    public void setLastname(java.lang.String lastname) {
        _register.setLastname(lastname);
    }

    /**
    * Returns the country of this register.
    *
    * @return the country of this register
    */
    @Override
    public java.lang.String getCountry() {
        return _register.getCountry();
    }

    /**
    * Sets the country of this register.
    *
    * @param country the country of this register
    */
    @Override
    public void setCountry(java.lang.String country) {
        _register.setCountry(country);
    }

    @Override
    public boolean isNew() {
        return _register.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _register.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _register.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _register.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _register.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _register.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _register.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _register.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _register.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _register.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _register.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new RegisterWrapper((Register) _register.clone());
    }

    @Override
    public int compareTo(com.liferay.docs.test.poc.model.Register register) {
        return _register.compareTo(register);
    }

    @Override
    public int hashCode() {
        return _register.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<com.liferay.docs.test.poc.model.Register> toCacheModel() {
        return _register.toCacheModel();
    }

    @Override
    public com.liferay.docs.test.poc.model.Register toEscapedModel() {
        return new RegisterWrapper(_register.toEscapedModel());
    }

    @Override
    public com.liferay.docs.test.poc.model.Register toUnescapedModel() {
        return new RegisterWrapper(_register.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _register.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _register.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _register.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof RegisterWrapper)) {
            return false;
        }

        RegisterWrapper registerWrapper = (RegisterWrapper) obj;

        if (Validator.equals(_register, registerWrapper._register)) {
            return true;
        }

        return false;
    }

    @Override
    public StagedModelType getStagedModelType() {
        return _register.getStagedModelType();
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Register getWrappedRegister() {
        return _register;
    }

    @Override
    public Register getWrappedModel() {
        return _register;
    }

    @Override
    public void resetOriginalValues() {
        _register.resetOriginalValues();
    }
}
