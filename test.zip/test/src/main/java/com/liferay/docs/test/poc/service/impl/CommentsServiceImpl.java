package com.liferay.docs.test.poc.service.impl;

import com.liferay.docs.test.poc.service.base.CommentsServiceBaseImpl;

/**
 * The implementation of the comments remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.liferay.docs.test.poc.service.CommentsService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.base.CommentsServiceBaseImpl
 * @see com.liferay.docs.test.poc.service.CommentsServiceUtil
 */
public class CommentsServiceImpl extends CommentsServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.liferay.docs.test.poc.service.CommentsServiceUtil} to access the comments remote service.
     */
}
