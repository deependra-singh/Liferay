package com.liferay.docs.test.poc.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.docs.test.poc.model.Projects;
import com.liferay.docs.test.poc.service.base.ProjectsLocalServiceBaseImpl;
import com.liferay.portal.NoSuchUserException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portlet.asset.model.AssetEntry;

/**
 * The implementation of the projects local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.liferay.docs.test.poc.service.ProjectsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.base.ProjectsLocalServiceBaseImpl
 * @see com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil
 */
public class ProjectsLocalServiceImpl extends ProjectsLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil} to access the projects local service.
     */
	public List<Projects> getProjects1(long groupId) throws SystemException
	{
		return projectsPersistence.findByGroupId(groupId);
	}
	
	public List<Projects> getProjects(long groupId,int start,int end) throws SystemException
	{
		return projectsPersistence.findByGroupId(groupId, start, end);
	}
	
	public int getProjectsCount(long groupId) throws SystemException
	{
		return projectsPersistence.countByGroupId(groupId);
	}
	
	public Projects addProjects(long userId,String title,String description,long image,long category,long tags,ServiceContext serviceContext) throws SystemException, PortalException
	{
		Date date=new Date();
		User user=userPersistence.findByPrimaryKey(userId);
		long projectsId=counterLocalService.increment();
		long groupId=serviceContext.getScopeGroupId();
		Projects projects=projectsPersistence.create(projectsId);
		projects.setUuid(serviceContext.getUuid());
		projects.setUserId(userId);
		projects.setGroupId(groupId);
		projects.setCompanyId(user.getCompanyId());
		projects.setUserName(user.getFullName());
		projects.setCreateDate(serviceContext.getCreateDate(date));
		projects.setModifiedDate(serviceContext.getModifiedDate(date));
		projects.setTitle(title);
		projects.setDescription(description);
		projects.setImages(image);
		projects.setCategory(category);
		projects.setTags(tags);
		projects.setExpandoBridgeAttributes(serviceContext);
		projectsPersistence.update(projects);
		 AssetEntry assetEntry = assetEntryLocalService.updateEntry(userId,
                 groupId, projects.getCreateDate(),
                 projects.getModifiedDate(), Projects.class.getName(),
                 projectsId, projects.getUuid(), 0,
                 serviceContext.getAssetCategoryIds(),
                 serviceContext.getAssetTagNames(), true, null, null, null,
                 ContentTypes.TEXT_HTML, projects.getTitle(), null, null, null,
                 null, 0, 0, null, false);
		 resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       Projects.class.getName(), projectsId, false, true, true);
		return projects;
	}
	
}
