package com.liferay.docs.test.poc.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the Register service. Represents a row in the &quot;test_Register&quot; database table, with each column mapped to a property of this class.
 *
 * @author anuragch
 * @see RegisterModel
 * @see com.liferay.docs.test.poc.model.impl.RegisterImpl
 * @see com.liferay.docs.test.poc.model.impl.RegisterModelImpl
 * @generated
 */
public interface Register extends RegisterModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link com.liferay.docs.test.poc.model.impl.RegisterImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
