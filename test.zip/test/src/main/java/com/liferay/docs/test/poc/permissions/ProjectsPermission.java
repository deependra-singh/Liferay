package com.liferay.docs.test.poc.permissions;

import com.liferay.docs.test.poc.model.Projects;
import com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class ProjectsPermission {

	public static void check(PermissionChecker permissionChecker, long guestbookId, String actionId)
			throws PortalException, SystemException {

		if (!contains(permissionChecker, guestbookId, actionId)) {
			throw new PrincipalException();
		}
	}

	public static boolean contains(PermissionChecker permissionChecker, long projectsId, String actionId)
			throws PortalException, SystemException {

		Projects projects = ProjectsLocalServiceUtil.getProjects(projectsId);

		return permissionChecker.hasPermission(projects.getGroupId(), Projects.class.getName(),
				projects.getProjectsId(), actionId);

	}
}
