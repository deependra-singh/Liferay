package com.liferay.docs.test.poc.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Projects}.
 * </p>
 *
 * @author anuragch
 * @see Projects
 * @generated
 */
public class ProjectsWrapper implements Projects, ModelWrapper<Projects> {
    private Projects _projects;

    public ProjectsWrapper(Projects projects) {
        _projects = projects;
    }

    @Override
    public Class<?> getModelClass() {
        return Projects.class;
    }

    @Override
    public String getModelClassName() {
        return Projects.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("projectsId", getProjectsId());
        attributes.put("groupId", getGroupId());
        attributes.put("companyId", getCompanyId());
        attributes.put("userId", getUserId());
        attributes.put("userName", getUserName());
        attributes.put("createDate", getCreateDate());
        attributes.put("modifiedDate", getModifiedDate());
        attributes.put("title", getTitle());
        attributes.put("description", getDescription());
        attributes.put("images", getImages());
        attributes.put("category", getCategory());
        attributes.put("tags", getTags());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long projectsId = (Long) attributes.get("projectsId");

        if (projectsId != null) {
            setProjectsId(projectsId);
        }

        Long groupId = (Long) attributes.get("groupId");

        if (groupId != null) {
            setGroupId(groupId);
        }

        Long companyId = (Long) attributes.get("companyId");

        if (companyId != null) {
            setCompanyId(companyId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        String userName = (String) attributes.get("userName");

        if (userName != null) {
            setUserName(userName);
        }

        Date createDate = (Date) attributes.get("createDate");

        if (createDate != null) {
            setCreateDate(createDate);
        }

        Date modifiedDate = (Date) attributes.get("modifiedDate");

        if (modifiedDate != null) {
            setModifiedDate(modifiedDate);
        }

        String title = (String) attributes.get("title");

        if (title != null) {
            setTitle(title);
        }

        String description = (String) attributes.get("description");

        if (description != null) {
            setDescription(description);
        }

        Long images = (Long) attributes.get("images");

        if (images != null) {
            setImages(images);
        }

        Long category = (Long) attributes.get("category");

        if (category != null) {
            setCategory(category);
        }

        Long tags = (Long) attributes.get("tags");

        if (tags != null) {
            setTags(tags);
        }
    }

    /**
    * Returns the primary key of this projects.
    *
    * @return the primary key of this projects
    */
    @Override
    public long getPrimaryKey() {
        return _projects.getPrimaryKey();
    }

    /**
    * Sets the primary key of this projects.
    *
    * @param primaryKey the primary key of this projects
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _projects.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this projects.
    *
    * @return the uuid of this projects
    */
    @Override
    public java.lang.String getUuid() {
        return _projects.getUuid();
    }

    /**
    * Sets the uuid of this projects.
    *
    * @param uuid the uuid of this projects
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _projects.setUuid(uuid);
    }

    /**
    * Returns the projects ID of this projects.
    *
    * @return the projects ID of this projects
    */
    @Override
    public long getProjectsId() {
        return _projects.getProjectsId();
    }

    /**
    * Sets the projects ID of this projects.
    *
    * @param projectsId the projects ID of this projects
    */
    @Override
    public void setProjectsId(long projectsId) {
        _projects.setProjectsId(projectsId);
    }

    /**
    * Returns the group ID of this projects.
    *
    * @return the group ID of this projects
    */
    @Override
    public long getGroupId() {
        return _projects.getGroupId();
    }

    /**
    * Sets the group ID of this projects.
    *
    * @param groupId the group ID of this projects
    */
    @Override
    public void setGroupId(long groupId) {
        _projects.setGroupId(groupId);
    }

    /**
    * Returns the company ID of this projects.
    *
    * @return the company ID of this projects
    */
    @Override
    public long getCompanyId() {
        return _projects.getCompanyId();
    }

    /**
    * Sets the company ID of this projects.
    *
    * @param companyId the company ID of this projects
    */
    @Override
    public void setCompanyId(long companyId) {
        _projects.setCompanyId(companyId);
    }

    /**
    * Returns the user ID of this projects.
    *
    * @return the user ID of this projects
    */
    @Override
    public long getUserId() {
        return _projects.getUserId();
    }

    /**
    * Sets the user ID of this projects.
    *
    * @param userId the user ID of this projects
    */
    @Override
    public void setUserId(long userId) {
        _projects.setUserId(userId);
    }

    /**
    * Returns the user uuid of this projects.
    *
    * @return the user uuid of this projects
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _projects.getUserUuid();
    }

    /**
    * Sets the user uuid of this projects.
    *
    * @param userUuid the user uuid of this projects
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _projects.setUserUuid(userUuid);
    }

    /**
    * Returns the user name of this projects.
    *
    * @return the user name of this projects
    */
    @Override
    public java.lang.String getUserName() {
        return _projects.getUserName();
    }

    /**
    * Sets the user name of this projects.
    *
    * @param userName the user name of this projects
    */
    @Override
    public void setUserName(java.lang.String userName) {
        _projects.setUserName(userName);
    }

    /**
    * Returns the create date of this projects.
    *
    * @return the create date of this projects
    */
    @Override
    public java.util.Date getCreateDate() {
        return _projects.getCreateDate();
    }

    /**
    * Sets the create date of this projects.
    *
    * @param createDate the create date of this projects
    */
    @Override
    public void setCreateDate(java.util.Date createDate) {
        _projects.setCreateDate(createDate);
    }

    /**
    * Returns the modified date of this projects.
    *
    * @return the modified date of this projects
    */
    @Override
    public java.util.Date getModifiedDate() {
        return _projects.getModifiedDate();
    }

    /**
    * Sets the modified date of this projects.
    *
    * @param modifiedDate the modified date of this projects
    */
    @Override
    public void setModifiedDate(java.util.Date modifiedDate) {
        _projects.setModifiedDate(modifiedDate);
    }

    /**
    * Returns the title of this projects.
    *
    * @return the title of this projects
    */
    @Override
    public java.lang.String getTitle() {
        return _projects.getTitle();
    }

    /**
    * Sets the title of this projects.
    *
    * @param title the title of this projects
    */
    @Override
    public void setTitle(java.lang.String title) {
        _projects.setTitle(title);
    }

    /**
    * Returns the description of this projects.
    *
    * @return the description of this projects
    */
    @Override
    public java.lang.String getDescription() {
        return _projects.getDescription();
    }

    /**
    * Sets the description of this projects.
    *
    * @param description the description of this projects
    */
    @Override
    public void setDescription(java.lang.String description) {
        _projects.setDescription(description);
    }

    /**
    * Returns the images of this projects.
    *
    * @return the images of this projects
    */
    @Override
    public long getImages() {
        return _projects.getImages();
    }

    /**
    * Sets the images of this projects.
    *
    * @param images the images of this projects
    */
    @Override
    public void setImages(long images) {
        _projects.setImages(images);
    }

    /**
    * Returns the category of this projects.
    *
    * @return the category of this projects
    */
    @Override
    public long getCategory() {
        return _projects.getCategory();
    }

    /**
    * Sets the category of this projects.
    *
    * @param category the category of this projects
    */
    @Override
    public void setCategory(long category) {
        _projects.setCategory(category);
    }

    /**
    * Returns the tags of this projects.
    *
    * @return the tags of this projects
    */
    @Override
    public long getTags() {
        return _projects.getTags();
    }

    /**
    * Sets the tags of this projects.
    *
    * @param tags the tags of this projects
    */
    @Override
    public void setTags(long tags) {
        _projects.setTags(tags);
    }

    @Override
    public boolean isNew() {
        return _projects.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _projects.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _projects.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _projects.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _projects.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _projects.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _projects.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _projects.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _projects.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _projects.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _projects.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new ProjectsWrapper((Projects) _projects.clone());
    }

    @Override
    public int compareTo(com.liferay.docs.test.poc.model.Projects projects) {
        return _projects.compareTo(projects);
    }

    @Override
    public int hashCode() {
        return _projects.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<com.liferay.docs.test.poc.model.Projects> toCacheModel() {
        return _projects.toCacheModel();
    }

    @Override
    public com.liferay.docs.test.poc.model.Projects toEscapedModel() {
        return new ProjectsWrapper(_projects.toEscapedModel());
    }

    @Override
    public com.liferay.docs.test.poc.model.Projects toUnescapedModel() {
        return new ProjectsWrapper(_projects.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _projects.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _projects.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _projects.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof ProjectsWrapper)) {
            return false;
        }

        ProjectsWrapper projectsWrapper = (ProjectsWrapper) obj;

        if (Validator.equals(_projects, projectsWrapper._projects)) {
            return true;
        }

        return false;
    }

    @Override
    public StagedModelType getStagedModelType() {
        return _projects.getStagedModelType();
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Projects getWrappedProjects() {
        return _projects;
    }

    @Override
    public Projects getWrappedModel() {
        return _projects;
    }

    @Override
    public void resetOriginalValues() {
        _projects.resetOriginalValues();
    }
}
