package com.liferay.docs.test.poc.asset;

import java.util.Locale;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.liferay.docs.test.poc.model.Projects;
import com.liferay.portlet.asset.model.BaseAssetRenderer;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;

public class ProjectAssetRenderer extends BaseAssetRenderer {

	private Projects _projects;
	
	
	public ProjectAssetRenderer(Projects projects) {
		this._projects = projects;
	}

	@Override
	public String getClassName() {
		return Projects.class.getName();
	}

	@Override
	public long getClassPK() {
		return _projects.getProjectsId();
	}

	@Override
	public long getGroupId() {
		return _projects.getGroupId();
	}

	@Override
	public String getSummary(Locale locale) {
		return "Title"+_projects.getTitle();
	}

	@Override
	public String getTitle(Locale locale) {
		return _projects.getTitle();
	}

	@Override
	public long getUserId() {
		return _projects.getUserId();
	}

	@Override
	public String getUserName() {
		return _projects.getUserName();
	}

	@Override
	public String getUuid() {
		return _projects.getUuid();
	}

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse, String template) throws Exception {
		System.out.println(template);
            renderRequest.setAttribute("test_projects",_projects);
            return "/html/test/showproject.jsp";
            
    }
   
}

