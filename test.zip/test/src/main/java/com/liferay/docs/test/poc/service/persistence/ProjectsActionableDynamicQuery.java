package com.liferay.docs.test.poc.service.persistence;

import com.liferay.docs.test.poc.model.Projects;
import com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * @author anuragch
 * @generated
 */
public abstract class ProjectsActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public ProjectsActionableDynamicQuery() throws SystemException {
        setBaseLocalService(ProjectsLocalServiceUtil.getService());
        setClass(Projects.class);

        setClassLoader(com.liferay.docs.test.poc.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("projectsId");
    }
}
