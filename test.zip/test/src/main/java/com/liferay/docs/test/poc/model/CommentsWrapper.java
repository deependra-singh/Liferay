package com.liferay.docs.test.poc.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Comments}.
 * </p>
 *
 * @author anuragch
 * @see Comments
 * @generated
 */
public class CommentsWrapper implements Comments, ModelWrapper<Comments> {
    private Comments _comments;

    public CommentsWrapper(Comments comments) {
        _comments = comments;
    }

    @Override
    public Class<?> getModelClass() {
        return Comments.class;
    }

    @Override
    public String getModelClassName() {
        return Comments.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("commentsId", getCommentsId());
        attributes.put("groupId", getGroupId());
        attributes.put("companyId", getCompanyId());
        attributes.put("userId", getUserId());
        attributes.put("userName", getUserName());
        attributes.put("createDate", getCreateDate());
        attributes.put("modifiedDate", getModifiedDate());
        attributes.put("comments", getComments());
        attributes.put("projectsId", getProjectsId());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long commentsId = (Long) attributes.get("commentsId");

        if (commentsId != null) {
            setCommentsId(commentsId);
        }

        Long groupId = (Long) attributes.get("groupId");

        if (groupId != null) {
            setGroupId(groupId);
        }

        Long companyId = (Long) attributes.get("companyId");

        if (companyId != null) {
            setCompanyId(companyId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        String userName = (String) attributes.get("userName");

        if (userName != null) {
            setUserName(userName);
        }

        Date createDate = (Date) attributes.get("createDate");

        if (createDate != null) {
            setCreateDate(createDate);
        }

        Date modifiedDate = (Date) attributes.get("modifiedDate");

        if (modifiedDate != null) {
            setModifiedDate(modifiedDate);
        }

        String comments = (String) attributes.get("comments");

        if (comments != null) {
            setComments(comments);
        }

        Long projectsId = (Long) attributes.get("projectsId");

        if (projectsId != null) {
            setProjectsId(projectsId);
        }
    }

    /**
    * Returns the primary key of this comments.
    *
    * @return the primary key of this comments
    */
    @Override
    public long getPrimaryKey() {
        return _comments.getPrimaryKey();
    }

    /**
    * Sets the primary key of this comments.
    *
    * @param primaryKey the primary key of this comments
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _comments.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this comments.
    *
    * @return the uuid of this comments
    */
    @Override
    public java.lang.String getUuid() {
        return _comments.getUuid();
    }

    /**
    * Sets the uuid of this comments.
    *
    * @param uuid the uuid of this comments
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _comments.setUuid(uuid);
    }

    /**
    * Returns the comments ID of this comments.
    *
    * @return the comments ID of this comments
    */
    @Override
    public long getCommentsId() {
        return _comments.getCommentsId();
    }

    /**
    * Sets the comments ID of this comments.
    *
    * @param commentsId the comments ID of this comments
    */
    @Override
    public void setCommentsId(long commentsId) {
        _comments.setCommentsId(commentsId);
    }

    /**
    * Returns the group ID of this comments.
    *
    * @return the group ID of this comments
    */
    @Override
    public long getGroupId() {
        return _comments.getGroupId();
    }

    /**
    * Sets the group ID of this comments.
    *
    * @param groupId the group ID of this comments
    */
    @Override
    public void setGroupId(long groupId) {
        _comments.setGroupId(groupId);
    }

    /**
    * Returns the company ID of this comments.
    *
    * @return the company ID of this comments
    */
    @Override
    public long getCompanyId() {
        return _comments.getCompanyId();
    }

    /**
    * Sets the company ID of this comments.
    *
    * @param companyId the company ID of this comments
    */
    @Override
    public void setCompanyId(long companyId) {
        _comments.setCompanyId(companyId);
    }

    /**
    * Returns the user ID of this comments.
    *
    * @return the user ID of this comments
    */
    @Override
    public long getUserId() {
        return _comments.getUserId();
    }

    /**
    * Sets the user ID of this comments.
    *
    * @param userId the user ID of this comments
    */
    @Override
    public void setUserId(long userId) {
        _comments.setUserId(userId);
    }

    /**
    * Returns the user uuid of this comments.
    *
    * @return the user uuid of this comments
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _comments.getUserUuid();
    }

    /**
    * Sets the user uuid of this comments.
    *
    * @param userUuid the user uuid of this comments
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _comments.setUserUuid(userUuid);
    }

    /**
    * Returns the user name of this comments.
    *
    * @return the user name of this comments
    */
    @Override
    public java.lang.String getUserName() {
        return _comments.getUserName();
    }

    /**
    * Sets the user name of this comments.
    *
    * @param userName the user name of this comments
    */
    @Override
    public void setUserName(java.lang.String userName) {
        _comments.setUserName(userName);
    }

    /**
    * Returns the create date of this comments.
    *
    * @return the create date of this comments
    */
    @Override
    public java.util.Date getCreateDate() {
        return _comments.getCreateDate();
    }

    /**
    * Sets the create date of this comments.
    *
    * @param createDate the create date of this comments
    */
    @Override
    public void setCreateDate(java.util.Date createDate) {
        _comments.setCreateDate(createDate);
    }

    /**
    * Returns the modified date of this comments.
    *
    * @return the modified date of this comments
    */
    @Override
    public java.util.Date getModifiedDate() {
        return _comments.getModifiedDate();
    }

    /**
    * Sets the modified date of this comments.
    *
    * @param modifiedDate the modified date of this comments
    */
    @Override
    public void setModifiedDate(java.util.Date modifiedDate) {
        _comments.setModifiedDate(modifiedDate);
    }

    /**
    * Returns the comments of this comments.
    *
    * @return the comments of this comments
    */
    @Override
    public java.lang.String getComments() {
        return _comments.getComments();
    }

    /**
    * Sets the comments of this comments.
    *
    * @param comments the comments of this comments
    */
    @Override
    public void setComments(java.lang.String comments) {
        _comments.setComments(comments);
    }

    /**
    * Returns the projects ID of this comments.
    *
    * @return the projects ID of this comments
    */
    @Override
    public long getProjectsId() {
        return _comments.getProjectsId();
    }

    /**
    * Sets the projects ID of this comments.
    *
    * @param projectsId the projects ID of this comments
    */
    @Override
    public void setProjectsId(long projectsId) {
        _comments.setProjectsId(projectsId);
    }

    @Override
    public boolean isNew() {
        return _comments.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _comments.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _comments.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _comments.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _comments.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _comments.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _comments.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _comments.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _comments.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _comments.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _comments.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new CommentsWrapper((Comments) _comments.clone());
    }

    @Override
    public int compareTo(com.liferay.docs.test.poc.model.Comments comments) {
        return _comments.compareTo(comments);
    }

    @Override
    public int hashCode() {
        return _comments.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<com.liferay.docs.test.poc.model.Comments> toCacheModel() {
        return _comments.toCacheModel();
    }

    @Override
    public com.liferay.docs.test.poc.model.Comments toEscapedModel() {
        return new CommentsWrapper(_comments.toEscapedModel());
    }

    @Override
    public com.liferay.docs.test.poc.model.Comments toUnescapedModel() {
        return new CommentsWrapper(_comments.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _comments.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _comments.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _comments.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof CommentsWrapper)) {
            return false;
        }

        CommentsWrapper commentsWrapper = (CommentsWrapper) obj;

        if (Validator.equals(_comments, commentsWrapper._comments)) {
            return true;
        }

        return false;
    }

    @Override
    public StagedModelType getStagedModelType() {
        return _comments.getStagedModelType();
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public Comments getWrappedComments() {
        return _comments;
    }

    @Override
    public Comments getWrappedModel() {
        return _comments;
    }

    @Override
    public void resetOriginalValues() {
        _comments.resetOriginalValues();
    }
}
