package com.liferay.docs.test.poc.service.impl;

import com.liferay.docs.test.poc.service.base.ProjectsServiceBaseImpl;

/**
 * The implementation of the projects remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.liferay.docs.test.poc.service.ProjectsService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.base.ProjectsServiceBaseImpl
 * @see com.liferay.docs.test.poc.service.ProjectsServiceUtil
 */
public class ProjectsServiceImpl extends ProjectsServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.liferay.docs.test.poc.service.ProjectsServiceUtil} to access the projects remote service.
     */
}
