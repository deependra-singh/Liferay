package com.test;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.RoleConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.test.docs.promgmt.model.Project;
import com.test.docs.promgmt.service.ProjectLocalServiceUtil;

public class AddProjectsPortlet extends MVCPortlet 
{
	ProjectUploadDownloadImage p1 = new ProjectUploadDownloadImage();
	SearchProjects s1 = new SearchProjects();
 
	public void addProject(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException 
	{		
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);

	    String proTitle = ParamUtil.getString(request, "proTitle");
	    String description = ParamUtil.getString(request, "description");
	    long imageId = p1.uploadDocument(request, response);	    
	    long categoryId = ParamUtil.getLong(request, "Category");	    
	    
	    try 
	    {
	        ProjectLocalServiceUtil.addProject(serviceContext.getUserId(),proTitle, description, imageId, categoryId, serviceContext);
	        SessionMessages.add(request, "ProjectAdded");
	    }
	    catch (Exception e) 
	    {
	        SessionErrors.add(request, e.getClass().getName());
	        response.setRenderParameter("mvcPath", "/html/addprojects/edit_project.jsp");
	    }
	}	

	public void addComment(ActionRequest request, ActionResponse response)throws PortalException, SystemException
	{
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		
		long groupId = themeDisplay.getScopeGroupId();
		long projectId=ParamUtil.getLong(request, "projectId");	
		String comment=ParamUtil.getString(request,"comments");		
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);
		long userId=serviceContext.getUserId();
		User u =UserLocalServiceUtil.getUser(userId);
		String name=u.getFullName();
		
		p1.urlMap(request, response);
		
		MBMessageLocalServiceUtil.addDiscussionMessage(serviceContext.getUserId(), name, groupId, Project.class.getName(), projectId, projectId, projectId, "comment", comment, serviceContext);
		response.setRenderParameter("jspPage","/html/addprojects/showProjectDetails.jsp");
	}		

	public void downloadFiles(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException,PortletException, PortalException, SystemException 
	{
		p1.urlMap(actionRequest, actionResponse);
		actionResponse.setRenderParameter("jspPage","/html/addprojects/showProjectDetails.jsp");
	}	
	
	public void viewBySearch(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		s1.viewBySearch(request, response);
	}
	
	public void viewByCategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		s1.viewByCategory(request, response);	
	}
	
	@Override
	public void render(RenderRequest renderRequest,RenderResponse renderResponse) throws PortletException, IOException 
	{
	    try 
	    {
	        ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), renderRequest);

	        long groupId = serviceContext.getScopeGroupId();

	        long projectId = ParamUtil.getLong(renderRequest, "projectId");

	        List<Project> projects = ProjectLocalServiceUtil.getProjects(groupId);

	        if (projects.size() == 0) 
	        {
	        	Project project = ProjectLocalServiceUtil.addProject(serviceContext.getUserId(), "ECM", "Related To ECM", 0, 0, serviceContext);
	            projectId = project.getProjectId();
	        }

	        if (!(projectId > 0)) 
	        {
	        	projectId = projects.get(0).getProjectId();
	        }
	        
	         Project projects1 = ProjectLocalServiceUtil.getProject(projectId);	        
	         
	        int count = AssetCategoryLocalServiceUtil.getAssetCategoriesCount();
			List<AssetCategory> categori = AssetCategoryLocalServiceUtil.getAssetCategories(0, count);
			List<MBMessage> comments = MBMessageLocalServiceUtil.getMessages(Project.class.getName(), projectId, 0);
			
			List<Role> roles = RoleLocalServiceUtil.getUserRoles(serviceContext.getUserId());
			
			for (Role role : roles)
			{
				if(!role.getName().equalsIgnoreCase("Guest"))
				{
					renderRequest.setAttribute("userRole", role.getName());
					renderRequest.setAttribute("guestRole", RoleConstants.GUEST);
				}
			}
			
	        renderRequest.setAttribute("projectId", projectId);
	        renderRequest.setAttribute("groupId", groupId);
	        renderRequest.setAttribute("proList", projects);
	        renderRequest.setAttribute("categori", categori);
	        renderRequest.setAttribute("projects1", projects1);
	        renderRequest.setAttribute("comments", comments);
	    } 
	    catch (Exception e) 
	    {
	        throw new PortletException(e);
	    }
	   
	    super.render(renderRequest, renderResponse);
	}
}