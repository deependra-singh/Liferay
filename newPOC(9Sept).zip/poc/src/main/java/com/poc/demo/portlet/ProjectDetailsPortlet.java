package com.poc.demo.portlet;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.demo.poc.model.Project;
import com.demo.poc.service.ProjectLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ProjectDetailsPortlet
 */
public class ProjectDetailsPortlet extends MVCPortlet {
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws PortletException, IOException {
		long projectId = Long.parseLong(renderRequest.getParameter("projectId"));

		System.out.println("1111----1111" + projectId);
		try {
			Project project = ProjectLocalServiceUtil.getProject(projectId);

			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			FileEntry fileEntry = DLAppLocalServiceUtil.getFileEntry(project.getProjectImageId());
			String imageURL = themeDisplay.getPortalURL() + themeDisplay.getPathContext() + "/documents/"
					+ themeDisplay.getScopeGroupId() + "/" + fileEntry.getFolderId() + "/" + fileEntry.getTitle();

			List<MBMessage> comments = MBMessageLocalServiceUtil.getMessages(Project.class.getName(), projectId, 0);

			renderRequest.setAttribute("project", project);
			renderRequest.setAttribute("comments", comments);
			renderRequest.setAttribute("projectImage", imageURL);
		} catch (PortalException | SystemException e) {
			e.printStackTrace();
		}

		super.render(renderRequest, renderResponse);
	}

	public void addComment(ActionRequest actionRequest, ActionResponse actionResponse) {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();
		long projectId = ParamUtil.getLong(actionRequest, "projectId");
		String comment = ParamUtil.getString(actionRequest, "comments");

		try {
			ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), actionRequest);
			long userId = serviceContext.getUserId();
			User user = UserLocalServiceUtil.getUser(userId);
			String name = user.getFullName();
			MBMessageLocalServiceUtil.addDiscussionMessage(serviceContext.getUserId(), name, groupId,
					Project.class.getName(), projectId, projectId, projectId, "comment", comment, serviceContext);
			actionResponse.sendRedirect("/web/project-mart/project-details");
		} catch (PortalException | SystemException | IOException e) {
			e.printStackTrace();
		}
	}
}
