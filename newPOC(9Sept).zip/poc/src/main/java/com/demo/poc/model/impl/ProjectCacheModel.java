package com.demo.poc.model.impl;

import com.demo.poc.model.Project;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Project in entity cache.
 *
 * @author deependras
 * @see Project
 * @generated
 */
public class ProjectCacheModel implements CacheModel<Project>, Externalizable {
    public String uuid;
    public long projectId;
    public long groupId;
    public long companyId;
    public long userId;
    public String userName;
    public long createDate;
    public long modifiedDate;
    public String projectTitle;
    public String projectDescription;
    public long projectImageId;
    public int projectStatus;
    public long projectStatusByUserId;
    public String projectStatusByUserName;
    public long projectStatusChangeDate;
    public int projectImageNum;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(33);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", projectId=");
        sb.append(projectId);
        sb.append(", groupId=");
        sb.append(groupId);
        sb.append(", companyId=");
        sb.append(companyId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append(", userName=");
        sb.append(userName);
        sb.append(", createDate=");
        sb.append(createDate);
        sb.append(", modifiedDate=");
        sb.append(modifiedDate);
        sb.append(", projectTitle=");
        sb.append(projectTitle);
        sb.append(", projectDescription=");
        sb.append(projectDescription);
        sb.append(", projectImageId=");
        sb.append(projectImageId);
        sb.append(", projectStatus=");
        sb.append(projectStatus);
        sb.append(", projectStatusByUserId=");
        sb.append(projectStatusByUserId);
        sb.append(", projectStatusByUserName=");
        sb.append(projectStatusByUserName);
        sb.append(", projectStatusChangeDate=");
        sb.append(projectStatusChangeDate);
        sb.append(", projectImageNum=");
        sb.append(projectImageNum);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Project toEntityModel() {
        ProjectImpl projectImpl = new ProjectImpl();

        if (uuid == null) {
            projectImpl.setUuid(StringPool.BLANK);
        } else {
            projectImpl.setUuid(uuid);
        }

        projectImpl.setProjectId(projectId);
        projectImpl.setGroupId(groupId);
        projectImpl.setCompanyId(companyId);
        projectImpl.setUserId(userId);

        if (userName == null) {
            projectImpl.setUserName(StringPool.BLANK);
        } else {
            projectImpl.setUserName(userName);
        }

        if (createDate == Long.MIN_VALUE) {
            projectImpl.setCreateDate(null);
        } else {
            projectImpl.setCreateDate(new Date(createDate));
        }

        if (modifiedDate == Long.MIN_VALUE) {
            projectImpl.setModifiedDate(null);
        } else {
            projectImpl.setModifiedDate(new Date(modifiedDate));
        }

        if (projectTitle == null) {
            projectImpl.setProjectTitle(StringPool.BLANK);
        } else {
            projectImpl.setProjectTitle(projectTitle);
        }

        if (projectDescription == null) {
            projectImpl.setProjectDescription(StringPool.BLANK);
        } else {
            projectImpl.setProjectDescription(projectDescription);
        }

        projectImpl.setProjectImageId(projectImageId);
        projectImpl.setProjectStatus(projectStatus);
        projectImpl.setProjectStatusByUserId(projectStatusByUserId);

        if (projectStatusByUserName == null) {
            projectImpl.setProjectStatusByUserName(StringPool.BLANK);
        } else {
            projectImpl.setProjectStatusByUserName(projectStatusByUserName);
        }

        if (projectStatusChangeDate == Long.MIN_VALUE) {
            projectImpl.setProjectStatusChangeDate(null);
        } else {
            projectImpl.setProjectStatusChangeDate(new Date(
                    projectStatusChangeDate));
        }

        projectImpl.setProjectImageNum(projectImageNum);

        projectImpl.resetOriginalValues();

        return projectImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        projectId = objectInput.readLong();
        groupId = objectInput.readLong();
        companyId = objectInput.readLong();
        userId = objectInput.readLong();
        userName = objectInput.readUTF();
        createDate = objectInput.readLong();
        modifiedDate = objectInput.readLong();
        projectTitle = objectInput.readUTF();
        projectDescription = objectInput.readUTF();
        projectImageId = objectInput.readLong();
        projectStatus = objectInput.readInt();
        projectStatusByUserId = objectInput.readLong();
        projectStatusByUserName = objectInput.readUTF();
        projectStatusChangeDate = objectInput.readLong();
        projectImageNum = objectInput.readInt();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(projectId);
        objectOutput.writeLong(groupId);
        objectOutput.writeLong(companyId);
        objectOutput.writeLong(userId);

        if (userName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(userName);
        }

        objectOutput.writeLong(createDate);
        objectOutput.writeLong(modifiedDate);

        if (projectTitle == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(projectTitle);
        }

        if (projectDescription == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(projectDescription);
        }

        objectOutput.writeLong(projectImageId);
        objectOutput.writeInt(projectStatus);
        objectOutput.writeLong(projectStatusByUserId);

        if (projectStatusByUserName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(projectStatusByUserName);
        }

        objectOutput.writeLong(projectStatusChangeDate);
        objectOutput.writeInt(projectImageNum);
    }
}
