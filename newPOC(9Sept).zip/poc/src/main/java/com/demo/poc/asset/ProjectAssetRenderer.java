package com.demo.poc.asset;

import java.util.Locale;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.demo.poc.model.Project;
import com.liferay.portlet.asset.model.BaseAssetRenderer;

public class ProjectAssetRenderer extends BaseAssetRenderer {
	private Project _project;
	
	public ProjectAssetRenderer (Project project) 
    {
            _project = project;
    }

	@Override
	public String getClassName() {
		return Project.class.getName();
	}

	@Override
	public long getClassPK() {
		return _project.getProjectId();
	}

	@Override
	public long getGroupId() {
		return _project.getGroupId();
	}

	@Override
	public String getSummary(Locale locale) {
		return "Name: " + _project.getProjectTitle();
	}

	@Override
	public String getTitle(Locale locale) {
		return _project.getProjectTitle();
	}

	@Override
	public long getUserId() {
		return _project.getUserId();
	}

	@Override
	public String getUserName() {
		return _project.getUserName();
	}

	@Override
	public String getUuid() {
		return _project.getUuid();
	}

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse, String template) throws Exception {
		if(template.equals(TEMPLATE_FULL_CONTENT)){
			renderRequest.setAttribute("gb_project", _project);
			return "/html/project/" + template + ".jsp";
		} else {
			return null;
		}
	}
}
