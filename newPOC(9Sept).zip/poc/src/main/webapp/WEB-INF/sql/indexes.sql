create index IX_D84A4CE6 on poc_Project (groupId);
create index IX_B739E0F0 on poc_Project (uuid_);
create index IX_3FDF2D38 on poc_Project (uuid_, companyId);
create unique index IX_4341A1BA on poc_Project (uuid_, groupId);