package com.test;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.RoleConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.test.docs.promgmt.model.Project;
import com.test.docs.promgmt.service.ProjectLocalServiceUtil;

public class AddProjectsPortlet extends MVCPortlet 
{
	ProjectUploadDownloadImage p1 = new ProjectUploadDownloadImage();
 
	public void addProject(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException 
	{		
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);

	    String proTitle = ParamUtil.getString(request, "proTitle");
	    String description = ParamUtil.getString(request, "description");
	    long imageId = p1.uploadDocument(request, response);	    
	    long categoryId = ParamUtil.getLong(request, "Category");	    
	    
	    try
	    {
	        ProjectLocalServiceUtil.addProject(serviceContext.getUserId(),proTitle, description, imageId, categoryId, serviceContext);
	        response.sendRedirect("/web/poc");
	        SessionMessages.add(request, "ProjectAdded");
	    }
	    catch (Exception e) 
	    {
	        SessionErrors.add(request, e.getClass().getName());
	        response.setRenderParameter("mvcPath", "/html/addprojects/view.jsp");
	    }
	}	
	
	@Override
	public void render(RenderRequest renderRequest,RenderResponse renderResponse) throws PortletException, IOException 
	{
		try
		{
			int count = AssetCategoryLocalServiceUtil.getAssetCategoriesCount();
			List<AssetCategory> categori = AssetCategoryLocalServiceUtil.getAssetCategories(0, count);
			
			renderRequest.setAttribute("categori", categori);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	    super.render(renderRequest, renderResponse);
	}
}