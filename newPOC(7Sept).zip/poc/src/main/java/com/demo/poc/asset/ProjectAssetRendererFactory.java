package com.demo.poc.asset;

import com.demo.poc.model.Project;
import com.demo.poc.service.ProjectLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portlet.asset.model.AssetRenderer;
import com.liferay.portlet.asset.model.BaseAssetRendererFactory;

public class ProjectAssetRendererFactory extends BaseAssetRendererFactory {
	public static final String CLASS_NAME = Project.class.getName();

    public static final String TYPE = "project";

    @Override
    public AssetRenderer getAssetRenderer(long classPK, int type)
            throws PortalException, SystemException 
    {
    	Project project = ProjectLocalServiceUtil.getProject(classPK);

            return new ProjectAssetRenderer(project);
    }
    
    @Override
    public String getClassName() {
            return CLASS_NAME;
    }

    @Override
    public String getType() {
            return TYPE;
    }
    
    @Override
    public boolean isLinkable() {
            return _LINKABLE;
    }

    private static final boolean _LINKABLE = true;
}
