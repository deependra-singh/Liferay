package com.poc.demo.helper;

public class SearchPojo {
	private Long proId;
	private String proTitle;
	private String proDesc;
	private String proCategoryTitle;
	private Long proImageId;
	private String proImageLink;

	public SearchPojo(Long proId, String proTitle, String proDesc, String proCategoryTitle, Long proImageId,
			String proImageLink) {
		super();
		this.proId = proId;
		this.proTitle = proTitle;
		this.proDesc = proDesc;
		this.proCategoryTitle = proCategoryTitle;
		this.proImageId = proImageId;
		this.proImageLink = proImageLink;
	}

	public SearchPojo(Long proId, String proTitle, String proDesc, String proCategoryTitle, Long proImageId) {
		super();
		this.proId = proId;
		this.proTitle = proTitle;
		this.proDesc = proDesc;
		this.proCategoryTitle = proCategoryTitle;
		this.proImageId = proImageId;
	}

	public Long getProId() {
		return proId;
	}

	public void setProId(Long proId) {
		this.proId = proId;
	}

	public String getProTitle() {
		return proTitle;
	}

	public void setProTitle(String proTitle) {
		this.proTitle = proTitle;
	}

	public String getProDesc() {
		return proDesc;
	}

	public void setProDesc(String proDesc) {
		this.proDesc = proDesc;
	}

	public String getProCategoryTitle() {
		return proCategoryTitle;
	}

	public void setProCategoryTitle(String proCategoryTitle) {
		this.proCategoryTitle = proCategoryTitle;
	}

	public Long getProImageId() {
		return proImageId;
	}

	public void setProImageId(Long proImageId) {
		this.proImageId = proImageId;
	}
	
	public String getProImageLink() {
		return proImageLink;
	}

	public void setProImageLink(String proImageLink) {
		this.proImageLink = proImageLink;
	}

	@Override
	public String toString() {
		return "SearchPojo [proId=" + proId + ", proTitle=" + proTitle + ", proDesc=" + proDesc + ", proCategoryTitle="
				+ proCategoryTitle + ", proImageId=" + proImageId + ", proImageLink=" + proImageLink + "]";
	}
}
