package com.poc.demo.portlet;

import java.io.IOException;
import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ProjectDetailsPortlet
 */
public class ProjectDetailsPortlet extends MVCPortlet {
	SearchProjects searchProjects = new SearchProjects();
	
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws PortletException, IOException {
		int count;
		long categoryId;
		try {
			categoryId = ParamUtil.getLong(renderRequest, "categoryId");

			count = AssetCategoryLocalServiceUtil.getAssetCategoriesCount();
			List<AssetCategory> category = AssetCategoryLocalServiceUtil.getAssetCategories(0, count);
			String bCSSClass = StringPool.BLANK;

			if (!(categoryId > 0)) {
				categoryId = category.get(0).getCategoryId();
			}
			
			try {
				searchProjects.viewByCategory(renderRequest, renderResponse, categoryId);
			} catch (PortalException e) {
				e.printStackTrace();
			}

			renderRequest.setAttribute("bCSSClass", bCSSClass);
			renderRequest.setAttribute("category", category);
			renderRequest.setAttribute("categoryId", categoryId);
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		super.render(renderRequest, renderResponse);
	}
}
