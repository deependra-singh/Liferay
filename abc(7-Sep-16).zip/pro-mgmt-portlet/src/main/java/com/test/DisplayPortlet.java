package com.test;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.RoleConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.test.docs.promgmt.model.Project;
import com.test.docs.promgmt.service.ProjectLocalServiceUtil;

public class DisplayPortlet extends MVCPortlet 
{
	ProjectUploadDownloadImage p1 = new ProjectUploadDownloadImage();
	
	public void downloadFiles(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException,PortletException, PortalException, SystemException 
	{
		p1.urlMap(actionRequest, actionResponse);
	}
	
	public void addComment(ActionRequest request, ActionResponse response)throws PortalException, SystemException, IOException
	{
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		
		long groupId = themeDisplay.getScopeGroupId();
		long projectId=ParamUtil.getLong(request, "projectId");	
		String comment=ParamUtil.getString(request,"comments");		
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);
		long userId=serviceContext.getUserId();
		User u =UserLocalServiceUtil.getUser(userId);
		String name=u.getFullName();
		
		p1.urlMap(request, response);
		
		MBMessageLocalServiceUtil.addDiscussionMessage(serviceContext.getUserId(), name, groupId, Project.class.getName(), projectId, projectId, projectId, "comment", comment, serviceContext);
		response.sendRedirect("/web/poc/project-details?projectId="+projectId);
	}
	
	@Override
	public void render(RenderRequest renderRequest,RenderResponse renderResponse) throws PortletException, IOException 
	{
	    try 
	    {	        
	    	ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), renderRequest);
	    	HttpServletRequest request = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderRequest));
	    	String projectId = request.getParameter("projectId");
	    	long proId = Long.parseLong(projectId);
	    	Project project = ProjectLocalServiceUtil.getProject(proId);
	    	
	    	ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);		
			Map<String,String> urlMap = p1.getAllFileLink(themeDisplay);
			
			List<MBMessage> comments = MBMessageLocalServiceUtil.getMessages(Project.class.getName(), proId, 0);
			
			List<Role> roles = RoleLocalServiceUtil.getUserRoles(serviceContext.getUserId());
			
			for (Role role : roles)
			{
				if(!role.getName().equalsIgnoreCase("Guest"))
				{
					renderRequest.setAttribute("userRole", role.getName());
					renderRequest.setAttribute("guestRole", RoleConstants.GUEST);
				}
			}
			
			renderRequest.setAttribute("urlMap", urlMap);
	    	renderRequest.setAttribute("project", project);	
			renderRequest.setAttribute("comments", comments);
			
	    } 
	    catch (Exception e) 
	    {
	        throw new PortletException(e);
	    }
	   
	    super.render(renderRequest, renderResponse);
	}
}