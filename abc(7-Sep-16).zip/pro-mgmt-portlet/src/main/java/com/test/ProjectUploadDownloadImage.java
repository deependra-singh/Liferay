package com.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.RoleConstants;
import com.liferay.portal.service.ResourcePermissionServiceUtil;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLAppServiceUtil;
import com.liferay.util.portlet.PortletProps;

public class ProjectUploadDownloadImage 
{
	private static String ROOT_FOLDER_NAME = PortletProps.get("fileupload.folder.name");
	private static String ROOT_FOLDER_DESCRIPTION = PortletProps.get("fileupload.folder.description");
	private static long PARENT_FOLDER_ID = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;	
	
	public long uploadDocument(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException,PortletException, PortalException, SystemException
	{
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		createFolder(actionRequest, themeDisplay);
		long imgId = fileUpload(themeDisplay, actionRequest);
		return imgId;
	}	
	
	public Folder createFolder(ActionRequest actionRequest,ThemeDisplay themeDisplay)
	{
		boolean folderExist = isFolderExist(themeDisplay);
		Folder folder = null;
		if (!folderExist)
		{
			long repositoryId = themeDisplay.getScopeGroupId();
			try 
			{
				ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFolder.class.getName(), actionRequest);
				folder = DLAppServiceUtil.addFolder(repositoryId,PARENT_FOLDER_ID, ROOT_FOLDER_NAME,ROOT_FOLDER_DESCRIPTION, serviceContext);
			}
			catch (PortalException e1)
			{
				e1.printStackTrace();
			}
			catch (SystemException e1)
			{
				e1.printStackTrace();
			}
		}
		return folder;
	}
	
	public boolean isFolderExist(ThemeDisplay themeDisplay)
	{
		boolean folderExist = false;
		try
			{
				DLAppServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME);
				folderExist = true;
			}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		return folderExist; 
	}
	
	public Folder getFolder(ThemeDisplay themeDisplay)
	{
		Folder folder = null;
		try
		{
			folder =DLAppLocalServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME); 
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		return folder; 
	}
	
	public long fileUpload(ThemeDisplay themeDisplay,ActionRequest actionRequest)
	{
		long imgid=0;
		
		 char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		 StringBuilder sb = new StringBuilder();
		 Random random = new Random();
		 for (int i = 0; i < 10; i++) 
		 {
		     char c = chars[random.nextInt(chars.length)];
		     sb.append(c);
		 }
		 
		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		
		String fileName=uploadPortletRequest.getFileName("uploadedFile");
		
		File file = uploadPortletRequest.getFile("uploadedFile");
		
		String mimeType = uploadPortletRequest.getContentType("uploadedFile");
		
		String title = sb+ fileName;
		
		String description = "This file is added via programatically";
		
		long repositoryId = themeDisplay.getScopeGroupId();
		
		long userId = themeDisplay.getUserId();
		
		try 
		{ 
			Folder folder = getFolder(themeDisplay);
			
			ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(), actionRequest);
			
			InputStream is = new FileInputStream( file );
			
			FileEntry imgentryId=DLAppLocalServiceUtil.addFileEntry(userId, repositoryId, folder.getFolderId(), fileName, mimeType, title, description, "", is, file.getTotalSpace(), serviceContext);
				
				  Map<Long, String[]> roleIdsToActionIdsForFileEntrries = new HashMap<Long, String[]>();

			                Role role;
			                try
			                {
			                    role = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(), RoleConstants.GUEST);
			                    String[] actionIdsForFileEntry = new String[] { "VIEW" };
			                    roleIdsToActionIdsForFileEntrries.put(role.getRoleId(), actionIdsForFileEntry);
			                    setAccessPermissionForGuestUsers(themeDisplay, String.valueOf(folder.getFolderId()),
			                            "com.liferay.portlet.documentlibrary.model.DLFolder", actionIdsForFileEntry, role);
			            

			                        String fileEntryId = String.valueOf(imgentryId.getFileEntryId());
			                        
			                        ResourcePermissionServiceUtil.setIndividualResourcePermissions(themeDisplay.getScopeGroupId(),
			                                themeDisplay.getCompanyId(), "com.liferay.portlet.documentlibrary.model.DLFileEntry",
			                                fileEntryId, roleIdsToActionIdsForFileEntrries);
			                   
			                }
			                catch (Exception e) 
			                {
			                  System.out.println("Exception occured while save document " + e);
			                }
			
			imgid=imgentryId.getFileEntryId();
			
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		} 
		return imgid;
	}
	
	 private void setAccessPermissionForGuestUsers(ThemeDisplay themeDisplay, String entryId, String entryClassName,
	            String[] actionIds, Role role) throws PortalException, SystemException 
	 {
	        Map<Long, String[]> roleIdsToActionIds = new HashMap<Long, String[]>();
	        roleIdsToActionIds.put(role.getRoleId(), actionIds);
	        ResourcePermissionServiceUtil.setIndividualResourcePermissions(themeDisplay.getScopeGroupId(),
	        themeDisplay.getCompanyId(), entryClassName, entryId, roleIdsToActionIds);
	  }
	
	public void urlMap(ActionRequest actionRequest,ActionResponse actionResponse) 
	{
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);		
		Map<String,String> urlMap = getAllFileLink(themeDisplay);
		actionRequest.setAttribute("urlMap", urlMap);
	}
	
	public void downloadFiles(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException,PortletException, PortalException, SystemException 
	{
		urlMap(actionRequest, actionResponse);
		actionResponse.setRenderParameter("jspPage","/html/addprojects/showProjectDetails.jsp");
	}
	
	public Map<String, String> getAllFileLink(ThemeDisplay themeDisplay)
	{
		Map<String, String> urlMap = new HashMap<String, String>();
		long repositoryId = themeDisplay.getScopeGroupId();
		
		try 
		{ 
			Folder folder = getFolder(themeDisplay);
			List<FileEntry> fileEntries = DLAppServiceUtil.getFileEntries(repositoryId, folder.getFolderId());			
			
			for (FileEntry file : fileEntries)
			{	
				String url = themeDisplay.getPortalURL() + themeDisplay.getPathContext() + "/documents/" + themeDisplay.getScopeGroupId() + "/" + file.getFolderId() + "/" +file.getTitle() ; 
				urlMap.put(String.valueOf(file.getFileEntryId()), url);
			}
		}
		catch (Exception e) 
		{ 
			e.printStackTrace();
		}
		return urlMap;
	}
}