package com.test;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.test.docs.promgmt.model.Project;


public class ProjectsCategoryPortlet extends MVCPortlet 
{
	SearchProjects s1 = new SearchProjects();
	
	public void viewByCategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		s1.viewByCategory(request, response);	
	}
	
	@Override
	public void render(RenderRequest renderRequest,RenderResponse renderResponse) throws PortletException, IOException 
	{
	    try 
	    {	        
	    	long projectId = ParamUtil.getLong(renderRequest, "projectId");
	        int count = AssetCategoryLocalServiceUtil.getAssetCategoriesCount();
			List<AssetCategory> categori = AssetCategoryLocalServiceUtil.getAssetCategories(0, count);
			List<MBMessage> comments = MBMessageLocalServiceUtil.getMessages(Project.class.getName(), projectId, 0);
			
			renderRequest.setAttribute("projectId", projectId);
			renderRequest.setAttribute("categori", categori);
			renderRequest.setAttribute("comments", comments);
			
	    } 
	    catch (Exception e) 
	    {
	        throw new PortletException(e);
	    }
	   
	    super.render(renderRequest, renderResponse);
	}
}