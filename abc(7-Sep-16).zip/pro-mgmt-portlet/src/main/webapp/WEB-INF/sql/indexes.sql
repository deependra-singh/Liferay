create index IX_B256BD3F on PRM_Project (groupId);
create index IX_92289389 on PRM_Project (uuid_);
create index IX_25910FF on PRM_Project (uuid_, companyId);
create unique index IX_E49FCB41 on PRM_Project (uuid_, groupId);