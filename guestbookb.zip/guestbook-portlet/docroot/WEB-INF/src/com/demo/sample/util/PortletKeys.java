package com.demo.sample.util;

public class PortletKeys extends com.liferay.portal.util.PortletKeys {

    public static final String GUESTBOOK = "guestbook_WAR_guestbookportlet";

    public static final String GUESTBOOK_ADMIN = "guestbookadmin_WAR_guestbookportlet";

}