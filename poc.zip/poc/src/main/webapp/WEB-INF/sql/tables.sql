create table poc_project (
	uuid_ VARCHAR(75) null,
	projectId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	projectTitle VARCHAR(75) null,
	projectDescription VARCHAR(75) null,
	projectImageId LONG,
	projectStatus INTEGER,
	projectStatusChangeDate DATE null
);