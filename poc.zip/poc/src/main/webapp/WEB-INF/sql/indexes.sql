create index IX_6A8690C6 on poc_project (groupId);
create index IX_E9759CD0 on poc_project (uuid_);
create index IX_6A014558 on poc_project (uuid_, companyId);
create unique index IX_C94B41DA on poc_project (uuid_, groupId);