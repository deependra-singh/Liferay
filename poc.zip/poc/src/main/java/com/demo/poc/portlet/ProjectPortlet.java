package com.demo.poc.portlet;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ProjectPortlet
 */
public class ProjectPortlet extends MVCPortlet {
}
