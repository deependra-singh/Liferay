package com.demo.poc.helper;

public class Test {
	
	public static void main(String[] args) {
		int number = 333;
		
		for (int i = 1; i < 1000; i++){
		
		String str = String.format("%04d", i);
		
		System.out.println(str);
		}
	}
	
}
