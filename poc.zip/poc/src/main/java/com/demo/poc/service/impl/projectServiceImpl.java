package com.demo.poc.service.impl;

import com.demo.poc.service.base.projectServiceBaseImpl;

/**
 * The implementation of the project remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.demo.poc.service.projectService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author deependras
 * @see com.demo.poc.service.base.projectServiceBaseImpl
 * @see com.demo.poc.service.projectServiceUtil
 */
public class projectServiceImpl extends projectServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.demo.poc.service.projectServiceUtil} to access the project remote service.
     */
}
