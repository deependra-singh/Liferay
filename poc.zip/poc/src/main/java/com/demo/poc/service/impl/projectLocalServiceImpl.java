package com.demo.poc.service.impl;

import com.demo.poc.service.base.projectLocalServiceBaseImpl;

/**
 * The implementation of the project local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.demo.poc.service.projectLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author deependras
 * @see com.demo.poc.service.base.projectLocalServiceBaseImpl
 * @see com.demo.poc.service.projectLocalServiceUtil
 */
public class projectLocalServiceImpl extends projectLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.demo.poc.service.projectLocalServiceUtil} to access the project local service.
     */
}
