package com.demo.poc.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link project}.
 * </p>
 *
 * @author deependras
 * @see project
 * @generated
 */
public class projectWrapper implements project, ModelWrapper<project> {
    private project _project;

    public projectWrapper(project project) {
        _project = project;
    }

    @Override
    public Class<?> getModelClass() {
        return project.class;
    }

    @Override
    public String getModelClassName() {
        return project.class.getName();
    }

    @Override
    public Map<String, Object> getModelAttributes() {
        Map<String, Object> attributes = new HashMap<String, Object>();

        attributes.put("uuid", getUuid());
        attributes.put("projectId", getProjectId());
        attributes.put("groupId", getGroupId());
        attributes.put("companyId", getCompanyId());
        attributes.put("userId", getUserId());
        attributes.put("userName", getUserName());
        attributes.put("createDate", getCreateDate());
        attributes.put("modifiedDate", getModifiedDate());
        attributes.put("projectTitle", getProjectTitle());
        attributes.put("projectDescription", getProjectDescription());
        attributes.put("projectImageId", getProjectImageId());
        attributes.put("projectStatus", getProjectStatus());
        attributes.put("projectStatusChangeDate", getProjectStatusChangeDate());

        return attributes;
    }

    @Override
    public void setModelAttributes(Map<String, Object> attributes) {
        String uuid = (String) attributes.get("uuid");

        if (uuid != null) {
            setUuid(uuid);
        }

        Long projectId = (Long) attributes.get("projectId");

        if (projectId != null) {
            setProjectId(projectId);
        }

        Long groupId = (Long) attributes.get("groupId");

        if (groupId != null) {
            setGroupId(groupId);
        }

        Long companyId = (Long) attributes.get("companyId");

        if (companyId != null) {
            setCompanyId(companyId);
        }

        Long userId = (Long) attributes.get("userId");

        if (userId != null) {
            setUserId(userId);
        }

        String userName = (String) attributes.get("userName");

        if (userName != null) {
            setUserName(userName);
        }

        Date createDate = (Date) attributes.get("createDate");

        if (createDate != null) {
            setCreateDate(createDate);
        }

        Date modifiedDate = (Date) attributes.get("modifiedDate");

        if (modifiedDate != null) {
            setModifiedDate(modifiedDate);
        }

        String projectTitle = (String) attributes.get("projectTitle");

        if (projectTitle != null) {
            setProjectTitle(projectTitle);
        }

        String projectDescription = (String) attributes.get(
                "projectDescription");

        if (projectDescription != null) {
            setProjectDescription(projectDescription);
        }

        Long projectImageId = (Long) attributes.get("projectImageId");

        if (projectImageId != null) {
            setProjectImageId(projectImageId);
        }

        Integer projectStatus = (Integer) attributes.get("projectStatus");

        if (projectStatus != null) {
            setProjectStatus(projectStatus);
        }

        Date projectStatusChangeDate = (Date) attributes.get(
                "projectStatusChangeDate");

        if (projectStatusChangeDate != null) {
            setProjectStatusChangeDate(projectStatusChangeDate);
        }
    }

    /**
    * Returns the primary key of this project.
    *
    * @return the primary key of this project
    */
    @Override
    public long getPrimaryKey() {
        return _project.getPrimaryKey();
    }

    /**
    * Sets the primary key of this project.
    *
    * @param primaryKey the primary key of this project
    */
    @Override
    public void setPrimaryKey(long primaryKey) {
        _project.setPrimaryKey(primaryKey);
    }

    /**
    * Returns the uuid of this project.
    *
    * @return the uuid of this project
    */
    @Override
    public java.lang.String getUuid() {
        return _project.getUuid();
    }

    /**
    * Sets the uuid of this project.
    *
    * @param uuid the uuid of this project
    */
    @Override
    public void setUuid(java.lang.String uuid) {
        _project.setUuid(uuid);
    }

    /**
    * Returns the project ID of this project.
    *
    * @return the project ID of this project
    */
    @Override
    public long getProjectId() {
        return _project.getProjectId();
    }

    /**
    * Sets the project ID of this project.
    *
    * @param projectId the project ID of this project
    */
    @Override
    public void setProjectId(long projectId) {
        _project.setProjectId(projectId);
    }

    /**
    * Returns the group ID of this project.
    *
    * @return the group ID of this project
    */
    @Override
    public long getGroupId() {
        return _project.getGroupId();
    }

    /**
    * Sets the group ID of this project.
    *
    * @param groupId the group ID of this project
    */
    @Override
    public void setGroupId(long groupId) {
        _project.setGroupId(groupId);
    }

    /**
    * Returns the company ID of this project.
    *
    * @return the company ID of this project
    */
    @Override
    public long getCompanyId() {
        return _project.getCompanyId();
    }

    /**
    * Sets the company ID of this project.
    *
    * @param companyId the company ID of this project
    */
    @Override
    public void setCompanyId(long companyId) {
        _project.setCompanyId(companyId);
    }

    /**
    * Returns the user ID of this project.
    *
    * @return the user ID of this project
    */
    @Override
    public long getUserId() {
        return _project.getUserId();
    }

    /**
    * Sets the user ID of this project.
    *
    * @param userId the user ID of this project
    */
    @Override
    public void setUserId(long userId) {
        _project.setUserId(userId);
    }

    /**
    * Returns the user uuid of this project.
    *
    * @return the user uuid of this project
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.lang.String getUserUuid()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _project.getUserUuid();
    }

    /**
    * Sets the user uuid of this project.
    *
    * @param userUuid the user uuid of this project
    */
    @Override
    public void setUserUuid(java.lang.String userUuid) {
        _project.setUserUuid(userUuid);
    }

    /**
    * Returns the user name of this project.
    *
    * @return the user name of this project
    */
    @Override
    public java.lang.String getUserName() {
        return _project.getUserName();
    }

    /**
    * Sets the user name of this project.
    *
    * @param userName the user name of this project
    */
    @Override
    public void setUserName(java.lang.String userName) {
        _project.setUserName(userName);
    }

    /**
    * Returns the create date of this project.
    *
    * @return the create date of this project
    */
    @Override
    public java.util.Date getCreateDate() {
        return _project.getCreateDate();
    }

    /**
    * Sets the create date of this project.
    *
    * @param createDate the create date of this project
    */
    @Override
    public void setCreateDate(java.util.Date createDate) {
        _project.setCreateDate(createDate);
    }

    /**
    * Returns the modified date of this project.
    *
    * @return the modified date of this project
    */
    @Override
    public java.util.Date getModifiedDate() {
        return _project.getModifiedDate();
    }

    /**
    * Sets the modified date of this project.
    *
    * @param modifiedDate the modified date of this project
    */
    @Override
    public void setModifiedDate(java.util.Date modifiedDate) {
        _project.setModifiedDate(modifiedDate);
    }

    /**
    * Returns the project title of this project.
    *
    * @return the project title of this project
    */
    @Override
    public java.lang.String getProjectTitle() {
        return _project.getProjectTitle();
    }

    /**
    * Sets the project title of this project.
    *
    * @param projectTitle the project title of this project
    */
    @Override
    public void setProjectTitle(java.lang.String projectTitle) {
        _project.setProjectTitle(projectTitle);
    }

    /**
    * Returns the project description of this project.
    *
    * @return the project description of this project
    */
    @Override
    public java.lang.String getProjectDescription() {
        return _project.getProjectDescription();
    }

    /**
    * Sets the project description of this project.
    *
    * @param projectDescription the project description of this project
    */
    @Override
    public void setProjectDescription(java.lang.String projectDescription) {
        _project.setProjectDescription(projectDescription);
    }

    /**
    * Returns the project image ID of this project.
    *
    * @return the project image ID of this project
    */
    @Override
    public long getProjectImageId() {
        return _project.getProjectImageId();
    }

    /**
    * Sets the project image ID of this project.
    *
    * @param projectImageId the project image ID of this project
    */
    @Override
    public void setProjectImageId(long projectImageId) {
        _project.setProjectImageId(projectImageId);
    }

    /**
    * Returns the project status of this project.
    *
    * @return the project status of this project
    */
    @Override
    public int getProjectStatus() {
        return _project.getProjectStatus();
    }

    /**
    * Sets the project status of this project.
    *
    * @param projectStatus the project status of this project
    */
    @Override
    public void setProjectStatus(int projectStatus) {
        _project.setProjectStatus(projectStatus);
    }

    /**
    * Returns the project status change date of this project.
    *
    * @return the project status change date of this project
    */
    @Override
    public java.util.Date getProjectStatusChangeDate() {
        return _project.getProjectStatusChangeDate();
    }

    /**
    * Sets the project status change date of this project.
    *
    * @param projectStatusChangeDate the project status change date of this project
    */
    @Override
    public void setProjectStatusChangeDate(
        java.util.Date projectStatusChangeDate) {
        _project.setProjectStatusChangeDate(projectStatusChangeDate);
    }

    @Override
    public boolean isNew() {
        return _project.isNew();
    }

    @Override
    public void setNew(boolean n) {
        _project.setNew(n);
    }

    @Override
    public boolean isCachedModel() {
        return _project.isCachedModel();
    }

    @Override
    public void setCachedModel(boolean cachedModel) {
        _project.setCachedModel(cachedModel);
    }

    @Override
    public boolean isEscapedModel() {
        return _project.isEscapedModel();
    }

    @Override
    public java.io.Serializable getPrimaryKeyObj() {
        return _project.getPrimaryKeyObj();
    }

    @Override
    public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
        _project.setPrimaryKeyObj(primaryKeyObj);
    }

    @Override
    public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
        return _project.getExpandoBridge();
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.model.BaseModel<?> baseModel) {
        _project.setExpandoBridgeAttributes(baseModel);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
        _project.setExpandoBridgeAttributes(expandoBridge);
    }

    @Override
    public void setExpandoBridgeAttributes(
        com.liferay.portal.service.ServiceContext serviceContext) {
        _project.setExpandoBridgeAttributes(serviceContext);
    }

    @Override
    public java.lang.Object clone() {
        return new projectWrapper((project) _project.clone());
    }

    @Override
    public int compareTo(com.demo.poc.model.project project) {
        return _project.compareTo(project);
    }

    @Override
    public int hashCode() {
        return _project.hashCode();
    }

    @Override
    public com.liferay.portal.model.CacheModel<com.demo.poc.model.project> toCacheModel() {
        return _project.toCacheModel();
    }

    @Override
    public com.demo.poc.model.project toEscapedModel() {
        return new projectWrapper(_project.toEscapedModel());
    }

    @Override
    public com.demo.poc.model.project toUnescapedModel() {
        return new projectWrapper(_project.toUnescapedModel());
    }

    @Override
    public java.lang.String toString() {
        return _project.toString();
    }

    @Override
    public java.lang.String toXmlString() {
        return _project.toXmlString();
    }

    @Override
    public void persist()
        throws com.liferay.portal.kernel.exception.SystemException {
        _project.persist();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof projectWrapper)) {
            return false;
        }

        projectWrapper projectWrapper = (projectWrapper) obj;

        if (Validator.equals(_project, projectWrapper._project)) {
            return true;
        }

        return false;
    }

    @Override
    public StagedModelType getStagedModelType() {
        return _project.getStagedModelType();
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
     */
    public project getWrappedproject() {
        return _project;
    }

    @Override
    public project getWrappedModel() {
        return _project;
    }

    @Override
    public void resetOriginalValues() {
        _project.resetOriginalValues();
    }
}
