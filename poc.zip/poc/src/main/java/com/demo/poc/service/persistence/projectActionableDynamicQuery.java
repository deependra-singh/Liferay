package com.demo.poc.service.persistence;

import com.demo.poc.model.project;
import com.demo.poc.service.projectLocalServiceUtil;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * @author deependras
 * @generated
 */
public abstract class projectActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public projectActionableDynamicQuery() throws SystemException {
        setBaseLocalService(projectLocalServiceUtil.getService());
        setClass(project.class);

        setClassLoader(com.demo.poc.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("projectId");
    }
}
