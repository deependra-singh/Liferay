package com.demo.poc.model;

import com.liferay.portal.kernel.util.Accessor;
import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the project service. Represents a row in the &quot;poc_project&quot; database table, with each column mapped to a property of this class.
 *
 * @author deependras
 * @see projectModel
 * @see com.demo.poc.model.impl.projectImpl
 * @see com.demo.poc.model.impl.projectModelImpl
 * @generated
 */
public interface project extends projectModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link com.demo.poc.model.impl.projectImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
    public static final Accessor<project, String> UUID_ACCESSOR = new Accessor<project, String>() {
            @Override
            public String get(project project) {
                return project.getUuid();
            }
        };
}
