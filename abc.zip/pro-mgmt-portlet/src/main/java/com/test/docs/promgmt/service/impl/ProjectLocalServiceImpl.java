package com.test.docs.promgmt.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.search.Indexer;
import com.liferay.portal.kernel.search.IndexerRegistryUtil;
import com.liferay.portal.kernel.util.ContentTypes;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portlet.asset.model.AssetEntry;
import com.liferay.portlet.asset.model.AssetLinkConstants;
import com.test.docs.promgmt.ProjectDescriptionException;
import com.test.docs.promgmt.ProjectTitleException;
import com.test.docs.promgmt.model.Project;
import com.test.docs.promgmt.service.base.ProjectLocalServiceBaseImpl;

/**
 * The implementation of the project local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.test.docs.promgmt.service.ProjectLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author mukulkul
 * @see com.test.docs.promgmt.service.base.ProjectLocalServiceBaseImpl
 * @see com.test.docs.promgmt.service.ProjectLocalServiceUtil
 */
public class ProjectLocalServiceImpl extends ProjectLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.test.docs.promgmt.service.ProjectLocalServiceUtil} to access the project local service.
     */
	
	public List<Project> getProjects (long groupId) throws SystemException 
	{
	    return projectPersistence.findByGroupId(groupId);
	}

	public List<Project> getProjects (long groupId, int start, int end) throws SystemException 
	{
	    return projectPersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate (String proTitle, String description) throws PortalException 
	{
	    if (Validator.isNull(proTitle)) 
	    {
	       throw new ProjectTitleException();
	    }
	    
	    if (Validator.isNull(description)) 
	    {
	       throw new ProjectDescriptionException();
	    }
	}
	
	public Project addProject(long userId, String proTitle,String description, long imageId, long categoryId, ServiceContext serviceContext) throws SystemException, PortalException 
	{
		System.out.println("In Service");
		
		long groupId = serviceContext.getScopeGroupId();

		User user = userPersistence.findByPrimaryKey(userId);

		Date now = new Date();
		
		long [] l = {categoryId};

		//validate(proTitle, description);
		long projectId = counterLocalService.increment();

		Project project = projectPersistence.create(projectId);

		project.setUuid(serviceContext.getUuid());
		project.setUserId(userId);
		project.setGroupId(groupId);
		project.setCompanyId(user.getCompanyId());
		project.setUserName(user.getFullName());
		project.setCreateDate(serviceContext.getCreateDate(now));
		project.setModifiedDate(serviceContext.getModifiedDate(now));
		project.setProTitle(proTitle);
		project.setDescription(description);
		project.setExpandoBridgeAttributes(serviceContext);
		project.setImageId(imageId);
		
		projectPersistence.update(project);
		AssetEntry assetEntry = assetEntryLocalService.updateEntry(userId,
                groupId, project.getCreateDate(),
                project.getModifiedDate(), Project.class.getName(),
                projectId, project.getUuid(), 0,
                l,
                serviceContext.getAssetTagNames(), true, null, null, null,
                ContentTypes.TEXT_HTML, project.getProTitle(), null, null, null,
                null, 0, 0, null, false);

				assetLinkLocalService.updateLinks(userId, assetEntry.getEntryId(),
                serviceContext.getAssetLinkEntryIds(),
                AssetLinkConstants.TYPE_RELATED);
				
				Indexer indexer = IndexerRegistryUtil.nullSafeGetIndexer(Project.class);

				indexer.reindex(project);
		return project;
		}
}