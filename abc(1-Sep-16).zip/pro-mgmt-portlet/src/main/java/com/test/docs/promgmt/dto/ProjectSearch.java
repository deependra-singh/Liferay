package com.test.docs.promgmt.dto;

public class ProjectSearch 
{
	private Long proId;
	private String title;
	private String desc;
	private String categoryTitle;
	private Long imageId;
	
	public ProjectSearch(Long proId, String title, String desc, String categoryTitle, Long imageId) 
	{
		this.proId = proId;
		this.title = title;
		this.desc = desc;
		this.categoryTitle = categoryTitle;
		this.imageId = imageId;
	}

	public Long getProId() {
		return proId;
	}

	public void setProId(Long proId) {
		this.proId = proId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getCategoryTitle() {
		return categoryTitle;
	}

	public void setCategoryTitle(String categoryTitle) {
		this.categoryTitle = categoryTitle;
	}

	public Long getImageId() {
		return imageId;
	}

	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}

	@Override
	public String toString() {
		return "ProjectSearch [proId=" + proId + ", title=" + title + ", desc=" + desc + ", categoryTitle="
				+ categoryTitle + ", imageId=" + imageId + "]";
	}
	
	
	
	
	
}
