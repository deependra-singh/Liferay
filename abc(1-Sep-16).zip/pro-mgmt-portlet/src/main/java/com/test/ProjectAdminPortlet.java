package com.test;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLAppServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFileEntryLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.liferay.util.portlet.PortletProps;
import com.test.docs.promgmt.model.Project;
import com.test.docs.promgmt.service.ProjectLocalServiceUtil;


public class ProjectAdminPortlet extends MVCPortlet 
{ 		
	public void approve(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	{
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);
		long userId = serviceContext.getUserId();
		long projectId = ParamUtil.getLong(request, "projectId");
		
		ProjectLocalServiceUtil.updateStatus(userId, projectId, 0, serviceContext);
	}
	
	public void reject(ActionRequest request, ActionResponse response) throws PortalException, SystemException
	{
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);
		long userId = serviceContext.getUserId();
		long projectId = ParamUtil.getLong(request, "projectId");
		
		ProjectLocalServiceUtil.updateStatus(userId, projectId, 1, serviceContext);
	}	
	
	@Override
	public void render(RenderRequest request, RenderResponse response) throws PortletException, IOException 
	{		
		try 
		{
			ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);
	        long groupId = serviceContext.getScopeGroupId();
			List<Project> projList = ProjectLocalServiceUtil.getProjects(groupId);
			long projectID = ParamUtil.getLong(request, "projectId");
			
			 int count = AssetCategoryLocalServiceUtil.getAssetCategoriesCount();
			List<AssetCategory> categori = AssetCategoryLocalServiceUtil.getAssetCategories(0, count);
			request.setAttribute("categoriAdmin", categori);
			
			request.setAttribute("projList", projList);
			request.setAttribute("projectID", projectID);
			
		}
		catch (SystemException e) 
		{
			e.printStackTrace();
		}
		catch (PortalException e) 
		{
			e.printStackTrace();
		}		
		
		super.render(request, response);
	}
	
	public void editProject(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException, SystemException 
	{
		 ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		 
		 ProjectUploadDownloadImage p1 = new ProjectUploadDownloadImage();
		 Map<String,String> urlMap = p1.getAllFileLink(themeDisplay);
		 
		 long projectId=ParamUtil.getLong(actionRequest, "projectId");
		 Project p= ProjectLocalServiceUtil.getProject(projectId);
		 
		 HttpServletRequest request= PortalUtil.getHttpServletRequest(actionRequest);
		 
		 request.setAttribute("project",p);
		 request.setAttribute("images", urlMap);
		 
		 actionResponse.setRenderParameter("jspPage","/html/projectadmin/edit_project.jsp");
	}
	
	
	public void updateProject(ActionRequest request, ActionResponse response)throws PortalException, SystemException 
	{     
		     try 
		     {   
		    	 ProjectUploadDownloadImage p1 = new ProjectUploadDownloadImage();
		     	 long projectId=ParamUtil.getLong(request, "projectId");		     	 
			 	 Project project=ProjectLocalServiceUtil.getProject(projectId);
			 	
			 	 String title=ParamUtil.getString(request, "title");
			 	 String description=ParamUtil.getString(request, "description");
	 			 
	     		 ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
	     		 
	     		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(request);
	    		
	    		String fileName=uploadPortletRequest.getFileName("uploadedFile");

				 project.setProTitle(title);
				 project.setDescription(description);				 
				 
				 if(fileName=="")
				 {
					  project.setImageId(ParamUtil.getLong(request, "imageid"));
				 }				 
				 else
				 {
					 long imageId = p1.fileUpload(themeDisplay, request);
					 long img = ParamUtil.getLong(request, "imageid");					 
					 project.setImageId(imageId);
					 
					 DLAppLocalServiceUtil.deleteFileEntry(img);		 			
		 		}
			         Project project1 = ProjectLocalServiceUtil.updateProject(project);
			         SessionMessages.add(request, "projectadded");
			     }
			     catch (Exception e) 
			     {   
			         SessionErrors.add(request, e.getClass().getName());
			         response.setRenderParameter("mvcPath","/html/projectadmin/edit_project.jsp");
			     }
	}
}