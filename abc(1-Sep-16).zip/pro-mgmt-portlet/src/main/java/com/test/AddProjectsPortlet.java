package com.test;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.search.BooleanClauseOccur;
import com.liferay.portal.kernel.search.BooleanQuery;
import com.liferay.portal.kernel.search.BooleanQueryFactoryUtil;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.kernel.search.Hits;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.SearchEngineUtil;
import com.liferay.portal.kernel.search.Sort;
import com.liferay.portal.kernel.search.TermQuery;
import com.liferay.portal.kernel.search.TermQueryFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppServiceUtil;
import com.liferay.portlet.messageboards.model.MBMessage;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.liferay.util.portlet.PortletProps;
import com.test.docs.promgmt.dto.ProjectSearch;
import com.test.docs.promgmt.model.Project;
import com.test.docs.promgmt.service.ProjectLocalServiceUtil;


public class AddProjectsPortlet extends MVCPortlet 
{
	private static String ROOT_FOLDER_NAME = PortletProps.get("fileupload.folder.name");
	private static String ROOT_FOLDER_DESCRIPTION = PortletProps.get("fileupload.folder.description");
	private static long PARENT_FOLDER_ID = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;
	
 
	public void addProject(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException 
	{		
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);

	    String proTitle = ParamUtil.getString(request, "proTitle");
	    String description = ParamUtil.getString(request, "description");
	    long imageId = uploadDocument(request, response);	    
	    long categoryId = ParamUtil.getLong(request, "Category");	    
	    
	    try 
	    {
	        ProjectLocalServiceUtil.addProject(serviceContext.getUserId(),proTitle, description, imageId, categoryId, serviceContext);
	        SessionMessages.add(request, "ProjectAdded");
	    }
	    catch (Exception e) 
	    {
	        SessionErrors.add(request, e.getClass().getName());
	        response.setRenderParameter("mvcPath", "/html/addprojects/edit_project.jsp");
	    }
	}
	
	
	public void viewBySearch(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		String textBox=null;
		textBox = ParamUtil.getString(request, "searchTextbox");
		
		HttpServletRequest hrequest = PortalUtil.getHttpServletRequest(request);
		SearchContext searchContext = SearchContextFactory.getInstance(PortalUtil.getHttpServletRequest(request));
        String searchEngineId = searchContext.getSearchEngineId();
        Long companyId = searchContext.getCompanyId();
        
        if(textBox!=null && !textBox.isEmpty())
        {
        	  BooleanQuery fullQuery = BooleanQueryFactoryUtil.create(searchContext);
              BooleanQuery classNameQuery = BooleanQueryFactoryUtil.create(searchContext);
              BooleanQuery searchQuery = BooleanQueryFactoryUtil.create(searchContext);
              
              classNameQuery.addRequiredTerm(Field.ENTRY_CLASS_NAME, Project.class.getName());
              
              searchQuery.addTerm(Field.ASSET_TAG_NAMES, textBox);
              searchQuery.addTerm(Field.TITLE, textBox);
              searchQuery.addTerm(Field.ASSET_CATEGORY_TITLES, textBox);
              
              fullQuery.add(classNameQuery, BooleanClauseOccur.MUST);
              fullQuery.add(searchQuery, BooleanClauseOccur.MUST);
              
              Hits hits = SearchEngineUtil.search(searchContext, fullQuery);
              
              List<ProjectSearch> psList = new ArrayList<ProjectSearch>();
      		
      		for(int i=0;i<hits.getDocs().length;i++)
      		{
      			Document doc = hits.doc(i);
      			
      			String title = doc.get("title");
      			String categoryTitle = doc.get("assetCategoryTitles");
      			String desc = doc.get("description");
      			Long imageId= Long.parseLong(doc.get("content"));
      			Long proId = Long.parseLong(doc.get("classPK"));
      			
      			ProjectSearch ps = new ProjectSearch(proId, title, desc, categoryTitle, imageId);
      			psList.add(ps);
      		}
      		hrequest.setAttribute("projects2", psList);
      		
      		/*ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
      		Map<String,String> urlMap = getAllFileLink(themeDisplay);
      		request.setAttribute("urlMap", urlMap);*/
      		
      		urlMap(request, response);
      		
      		response.setRenderParameter("jspPage","/html/addprojects/showProjectsByCategory.jsp");    		
              
        }
        
        else
        {
        	System.out.println("Something Went Wrong....");
        }		
	}
	
	public void viewByCategory(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		long categoryId=0;
		categoryId = ParamUtil.getLong(request, "categoryId");
		
		String textBox=null;
		textBox = ParamUtil.getString(request, "searchTextbox");
		
		HttpServletRequest hrequest = PortalUtil.getHttpServletRequest(request);
		SearchContext searchContext = SearchContextFactory.getInstance(PortalUtil.getHttpServletRequest(request));
        String searchEngineId = searchContext.getSearchEngineId();
        Long companyId = searchContext.getCompanyId();

        BooleanQuery booleanQuery = BooleanQueryFactoryUtil.create(searchContext);

        TermQuery termQuery = TermQueryFactoryUtil.create(searchContext, Field.ENTRY_CLASS_NAME,Project.class.getName());
        booleanQuery.add(termQuery, BooleanClauseOccur.MUST);
        
        if(categoryId!=0)
        {
        	TermQuery termQuery1 = TermQueryFactoryUtil.create(searchContext, Field.ASSET_CATEGORY_IDS,	categoryId);
        	 booleanQuery.add(termQuery1, BooleanClauseOccur.MUST);  
        }
        
        /*if(textBox!=null && !textBox.isEmpty())
        {
        	  BooleanQuery fullQuery = BooleanQueryFactoryUtil.create(searchContext);
              BooleanQuery classNameQuery = BooleanQueryFactoryUtil.create(searchContext);
              BooleanQuery searchQuery = BooleanQueryFactoryUtil.create(searchContext);
              
              classNameQuery.addRequiredTerm(Field.ENTRY_CLASS_NAME, Project.class.getName());
              
              searchQuery.addTerm(Field.ASSET_TAG_NAMES, textBox);
              searchQuery.addTerm(Field.TITLE, textBox);
              
              fullQuery.add(classNameQuery, BooleanClauseOccur.MUST);
              fullQuery.add(searchQuery, BooleanClauseOccur.MUST);
              
              
        	TermQuery termQuery2 = TermQueryFactoryUtil.create(searchContext, Field.ASSET_TAG_NAMES,textBox);
        	 booleanQuery.add(termQuery2, BooleanClauseOccur.MUST);   
        }*/
   
        Sort[] sorts = new Sort[] {};
        
		Hits hits = SearchEngineUtil.search(searchEngineId, companyId, booleanQuery, sorts, 0, 10);
		
		List<ProjectSearch> psList = new ArrayList<ProjectSearch>();
		
		for(int i=0;i<hits.getDocs().length;i++)
		{
			Document doc = hits.doc(i);
			
			String title = doc.get("title");
			String categoryTitle = doc.get("assetCategoryTitles");
			String desc = doc.get("description");
			Long imageId= Long.parseLong(doc.get("content"));
			Long proId = Long.parseLong(doc.get("classPK"));
			
			ProjectSearch ps = new ProjectSearch(proId, title, desc, categoryTitle, imageId);
			psList.add(ps);
		}
		hrequest.setAttribute("projects2", psList);
		
		urlMap(request, response);
		
		response.setRenderParameter("jspPage","/html/addprojects/showProjectsByCategory.jsp");
		
	}
	
	@Override
	public void render(RenderRequest renderRequest,RenderResponse renderResponse) throws PortletException, IOException 
	{
	    try 
	    {
	        ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), renderRequest);

	        long groupId = serviceContext.getScopeGroupId();

	        long projectId = ParamUtil.getLong(renderRequest, "projectId");

	        List<Project> projects = ProjectLocalServiceUtil.getProjects(groupId);

	        if (projects.size() == 0) 
	        {
	        	Project project = ProjectLocalServiceUtil.addProject(serviceContext.getUserId(), "ECM", "Related To ECM", 0, 0, serviceContext);
	            projectId = project.getProjectId();
	        }

	        if (!(projectId > 0)) 
	        {
	        	projectId = projects.get(0).getProjectId();
	        }
	        
	         Project projects1 = ProjectLocalServiceUtil.getProject(projectId);
	        
	         
	        int count = AssetCategoryLocalServiceUtil.getAssetCategoriesCount();
			List<AssetCategory> categori = AssetCategoryLocalServiceUtil.getAssetCategories(0, count);
			List<MBMessage> comments = MBMessageLocalServiceUtil.getMessages(Project.class.getName(), projectId, 0);
			
	        renderRequest.setAttribute("projectId", projectId);
	        renderRequest.setAttribute("groupId", groupId);
	        renderRequest.setAttribute("proList", projects);
	        renderRequest.setAttribute("categori", categori);
	        renderRequest.setAttribute("projects1", projects1);
	        renderRequest.setAttribute("comments", comments);
	    } 
	    catch (Exception e) 
	    {
	        throw new PortletException(e);
	    }
	   
	    super.render(renderRequest, renderResponse);
	}
	
	public void addComment(ActionRequest request, ActionResponse response)throws PortalException, SystemException
	{
		ThemeDisplay themeDisplay = (ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
		
		long groupId = themeDisplay.getScopeGroupId();
		long projectId=ParamUtil.getLong(request, "projectId");	
		String comment=ParamUtil.getString(request,"comments");		
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Project.class.getName(), request);
		long userId=serviceContext.getUserId();
		User u =UserLocalServiceUtil.getUser(userId);
		String name=u.getFullName();
		
		urlMap(request, response);
		
		MBMessageLocalServiceUtil.addDiscussionMessage(serviceContext.getUserId(), name, groupId, Project.class.getName(), projectId, projectId, projectId, "comment", comment, serviceContext);
		response.setRenderParameter("jspPage","/html/addprojects/showProjectDetails.jsp");
	}
	
	
	
	public long uploadDocument(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException,PortletException, PortalException, SystemException
	{
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		createFolder(actionRequest, themeDisplay);
		long imgId = fileUpload(themeDisplay, actionRequest);
		return imgId;
	}	
	
	public Folder createFolder(ActionRequest actionRequest,ThemeDisplay themeDisplay)
	{
		boolean folderExist = isFolderExist(themeDisplay);
		Folder folder = null;
		if (!folderExist)
		{
			long repositoryId = themeDisplay.getScopeGroupId();
			try 
			{
				ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFolder.class.getName(), actionRequest);
				folder = DLAppServiceUtil.addFolder(repositoryId,PARENT_FOLDER_ID, ROOT_FOLDER_NAME,ROOT_FOLDER_DESCRIPTION, serviceContext);
			}
			catch (PortalException e1)
			{
				e1.printStackTrace();
			}
			catch (SystemException e1)
			{
				e1.printStackTrace();
			}
		}
		return folder;
	}
	
	
	public boolean isFolderExist(ThemeDisplay themeDisplay)
	{
		boolean folderExist = false;
		try
			{
				DLAppServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME);
				folderExist = true;
			}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		return folderExist; 
	}
	
	public Folder getFolder(ThemeDisplay themeDisplay)
	{
		Folder folder = null;
		try
		{
			folder =DLAppServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME); 
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		return folder; 
	}
	
	public long fileUpload(ThemeDisplay themeDisplay,ActionRequest actionRequest)
	{
		long imgid=0;
		
		 char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		 StringBuilder sb = new StringBuilder();
		 Random random = new Random();
		 for (int i = 0; i < 10; i++) 
		 {
		     char c = chars[random.nextInt(chars.length)];
		     sb.append(c);
		 }
		
		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		String fileName=uploadPortletRequest.getFileName("uploadedFile");
		System.out.println("Fileeee------------------->" + fileName);
		File file = uploadPortletRequest.getFile("uploadedFile");
		String mimeType = uploadPortletRequest.getContentType("uploadedFile");
		String title = sb+ fileName;
		String description = "This file is added via programatically";
		
		long repositoryId = themeDisplay.getScopeGroupId();
		
		try 
		{ 
			Folder folder = getFolder(themeDisplay);
			ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(), actionRequest);
			InputStream is = new FileInputStream( file );
			FileEntry imgentryId=DLAppServiceUtil.addFileEntry(repositoryId, folder.getFolderId(), fileName, mimeType, title, description, "", is, file.getTotalSpace(), serviceContext);
			imgid=imgentryId.getFileEntryId();
		}
		catch (Exception e)
		{ 
			System.out.println(e.getMessage());
			e.printStackTrace();
		} 
		return imgid;
	}
	
	private void urlMap(ActionRequest actionRequest,ActionResponse actionResponse) {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		Map<String,String> urlMap = getAllFileLink(themeDisplay);
		actionRequest.setAttribute("urlMap", urlMap);
	}
	
	public void downloadFiles(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException,PortletException, PortalException, SystemException 
	{
		urlMap(actionRequest, actionResponse);
		actionResponse.setRenderParameter("jspPage","/html/addprojects/showProjectDetails.jsp");
	}
	
	public Map<String, String> getAllFileLink(ThemeDisplay themeDisplay)
	{
		Map<String, String> urlMap = new HashMap<String, String>(); //key = file name ,value = url 
		long repositoryId = themeDisplay.getScopeGroupId();
		try 
		{ 
			Folder folder =getFolder(themeDisplay);
			List<FileEntry> fileEntries = DLAppServiceUtil.getFileEntries(repositoryId, folder.getFolderId());
			for (FileEntry file : fileEntries)
			{
				String url = themeDisplay.getPortalURL() + themeDisplay.getPathContext() + "/documents/" + themeDisplay.getScopeGroupId() + "/" + file.getFolderId() + "/" +file.getTitle() ; 
				urlMap.put(String.valueOf(file.getFileEntryId()), url);
			}
		}
		catch (Exception e) 
		{ 
			e.printStackTrace();
		}
		return urlMap;
	}

	
}