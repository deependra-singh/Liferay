package com.poc.demo.portlet;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class SearchPortlet
 */
public class SearchPortlet extends MVCPortlet {
	SearchProjects searchProjects = new SearchProjects();
	
	public void viewBySearch(ActionRequest request, ActionResponse response) throws PortalException, SystemException, IOException, PortletException
	{
		String searchText = ParamUtil.getString(request, "searchTextbox");
		if (searchText != null && !searchText.isEmpty())
			searchProjects.viewBySearch(request, response, searchText);
	}
	
	public void projectDetails(ActionRequest actionRequest, ActionResponse actionResponse){
		System.out.println(ParamUtil.getString(actionRequest, "projectId"));
		try {
			actionResponse.sendRedirect("/web/project-mart/project-details");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
