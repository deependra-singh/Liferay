create index IX_C44075CC on test_Comments (groupId, projectsId);
create index IX_D1C43D2D on test_Comments (uuid_);
create index IX_B7D7B8DB on test_Comments (uuid_, companyId);
create unique index IX_FE1EBA1D on test_Comments (uuid_, groupId);

create index IX_8121A39D on test_Projects (groupId);
create index IX_D904F583 on test_Projects (groupId, status);
create index IX_48957967 on test_Projects (uuid_);
create index IX_E5687461 on test_Projects (uuid_, companyId);
create unique index IX_31949F23 on test_Projects (uuid_, groupId);

create index IX_A28849D4 on test_Register (groupId);
create index IX_A50E415E on test_Register (uuid_);
create index IX_11E3DC0A on test_Register (uuid_, companyId);
create unique index IX_25E7DD0C on test_Register (uuid_, groupId);