
package com.liferay.docs.test.poc;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.io.File;
import java.io.FileInputStream;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import com.liferay.docs.test.poc.images.ImagesUploadDownload;
import com.liferay.docs.test.poc.model.Projects;
import com.liferay.docs.test.poc.model.Register;
import com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil;
import com.liferay.docs.test.poc.service.RegisterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.search.BooleanClauseOccur;
import com.liferay.portal.kernel.search.BooleanQuery;
import com.liferay.portal.kernel.search.BooleanQueryFactoryUtil;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.kernel.search.Hits;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchContextFactory;
import com.liferay.portal.kernel.search.SearchEngineUtil;
import com.liferay.portal.kernel.search.TermQuery;
import com.liferay.portal.kernel.search.TermQueryFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.model.AssetVocabulary;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.asset.service.AssetVocabularyLocalServiceUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.model.DLFolderConstants;
import com.liferay.portlet.documentlibrary.service.DLAppServiceUtil;
import com.liferay.portlet.messageboards.service.MBMessageLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.liferay.util.portlet.PortletProps;

/**
 * Portlet implementation class TestPortlet
 */
public class TestPortlet extends MVCPortlet {
	
	String[] SEARCH_FIELDS = {Field.TITLE,Field.ASSET_TAG_NAMES,Field.ASSET_CATEGORY_TITLES};
	
	public void addProject(ActionRequest request, ActionResponse response)
			throws PortalException, SystemException, IOException, PortletException {
		long categoryId = 0;
		ImagesUploadDownload img = new ImagesUploadDownload();
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Register.class.getName(), request);
		String title = ParamUtil.getString(request, "title");
		String description = ParamUtil.getString(request, "description");
		long imageId = img.uploadDocument(request, response);
		String category = ParamUtil.getString(request, "categories");
		long tags = ParamUtil.getLong(request, "tags");
		List<AssetCategory> categoryList = null;
		AssetVocabulary vocabulary = AssetVocabularyLocalServiceUtil
				.getGroupVocabulary(serviceContext.getScopeGroupId(), "POC"); 
		long vocabularyId = vocabulary.getVocabularyId();
		categoryList = AssetCategoryLocalServiceUtil.getVocabularyCategories(vocabularyId, -1, -1, null); 
		for (AssetCategory asset : categoryList) {
			if (asset.getName().equals(category)) {
				categoryId = asset.getCategoryId();
			}
		}
		ProjectsLocalServiceUtil.addProjects(serviceContext.getUserId(), title, description, imageId, categoryId, tags,
				serviceContext);
		SessionMessages.add(request, "Projects added Complete");
		System.out.println("Projects added Complete");
	}

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws PortletException, IOException {
		try {
			ServiceContext serviceContext = ServiceContextFactory.getInstance(Projects.class.getName(), renderRequest);
			long groupId = serviceContext.getScopeGroupId();
			long projectId = ParamUtil.getLong(renderRequest, "projectsId");
			List<Projects> listprojects = ProjectsLocalServiceUtil.getProjects(groupId,
					WorkflowConstants.STATUS_APPROVED);
			if (listprojects.size() == 0) {
				Projects projects = ProjectsLocalServiceUtil.addProjects(serviceContext.getUserId(), "main", "Main",
						123, 0, 1, serviceContext);
				projectId = projects.getProjectsId();
			}
			if (!(projectId > 0)) {
				projectId = listprojects.get(0).getProjectsId();
			}
			ImagesUploadDownload img = new ImagesUploadDownload();
			Map<Long, String> category = new HashMap<Long, String>();
			List<AssetCategory> categoryList = null;
			AssetVocabulary vocabulary = AssetVocabularyLocalServiceUtil.getGroupVocabulary(groupId, "POC");
			long vocabularyId = vocabulary.getVocabularyId();
			categoryList = AssetCategoryLocalServiceUtil.getVocabularyCategories(vocabularyId, -1, -1, null);
			for (AssetCategory asset : categoryList) {
				String categoryName = asset.getName();
				category.put(asset.getCategoryId(), categoryName);
			}
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			Map<String, String> urlMap = img.getAllFileLink(themeDisplay);
			renderRequest.setAttribute("completeListProjects", listprojects);
			renderRequest.setAttribute("urlMap", urlMap);
			renderRequest.setAttribute("category", category);
			renderRequest.setAttribute("projectId", projectId);
		} catch (Exception e) {

			throw new PortletException(e);
		}
		super.render(renderRequest, renderResponse);
	}

	public void downloadFiles(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException, PortalException, SystemException {
		ImagesUploadDownload img=new ImagesUploadDownload();
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		Map<String, String> urlMap =img. getAllFileLink(themeDisplay);
		actionRequest.setAttribute("urlMap", urlMap);
		actionResponse.setRenderParameter("jspPage", "/html/test/showproject.jsp");
	}

	public void displaycategoryWiseProject(ActionRequest request, ActionResponse response)
			throws IOException, SystemException, PortalException {
		String title = null;
		long proId = 0;
		HttpServletRequest serrequest = PortalUtil.getHttpServletRequest(request);
		SearchContext searchContext = SearchContextFactory.getInstance(serrequest);
		long categoryId = ParamUtil.getLong(request, "passingCategory");
		BooleanQuery booleanQuery = BooleanQueryFactoryUtil.create(searchContext);
		TermQuery termQuery1 = TermQueryFactoryUtil.create(searchContext, Field.ENTRY_CLASS_NAME,
				Projects.class.getName());
		TermQuery termQuery2 = TermQueryFactoryUtil.create(searchContext, Field.ASSET_CATEGORY_IDS, categoryId);
		booleanQuery.add(termQuery1, BooleanClauseOccur.MUST);
		booleanQuery.add(termQuery2, BooleanClauseOccur.MUST);
		Hits hits = SearchEngineUtil.search(searchContext, booleanQuery);
		Map<Long, String> entries = new HashMap<Long, String>();
		for (int i = 0; i < hits.getDocs().length; i++) {
			Document doc = hits.doc(i);
			long projectsId = GetterUtil.getLong(doc.get(Field.ENTRY_CLASS_PK));
			Projects projects = null;
			try {
				projects = ProjectsLocalServiceUtil.getProjects(projectsId);
				title = projects.getTitle();
				proId = projects.getProjectsId();
				System.out.println("title" + title);
				System.out.println("proId" + proId);
			} catch (PortalException pe) {
				pe.printStackTrace();
			} catch (SystemException se) {
				se.printStackTrace();
			}
			entries.put(proId, title);
		}
		request.setAttribute("projTitle", entries);

		/*
		 * Map<String, Long> projTitle = new HashMap<String, Long>(); long
		 * categoryId=ParamUtil.getLong(request, "passingCategory");
		 * System.out.println(categoryId); List<AssetEntry> categoryList
		 * =AssetEntryLocalServiceUtil.getAssetCategoryAssetEntries(categoryId);
		 * for(AssetEntry pro: categoryList) {
		 * System.out.println("PK---"+pro.getClassPK()); DynamicQuery

		 * dynamicQuery = DynamicQueryFactoryUtil.forClass(Projects.class,
		 * "test-portlet");
		 * dynamicQuery.add(PropertyFactoryUtil.forName("projectsId").eq(pro.
		 * getClassPK())); List<Projects> projectsList
		 * =(List<Projects>)ProjectsLocalServiceUtil.dynamicQuery(dynamicQuery);
		 * for(Projects proj: projectsList) {
		 * projTitle.put(proj.getTitle(),proj.getProjectsId()); } }
		 * 
		 * request.setAttribute("projTitle",projTitle);
		 */
		response.setRenderParameter("jspPage", "/html/test/displaycategoryWiseProject.jsp");
	}
	/*
	 * private void setAccessPermissionForGuestUsers(ThemeDisplay themeDisplay,
	 * String entryId, String entryClassName, String[] actionIds, Role role)
	 * throws PortalException, SystemException {
	 * 
	 * Map<Long, String[]> roleIdsToActionIds = new HashMap<Long, String[]>();
	 * roleIdsToActionIds.put(role.getRoleId(), actionIds);
	 * ResourcePermissionServiceUtil.setIndividualResourcePermissions(
	 * themeDisplay.getScopeGroupId(), themeDisplay.getCompanyId(),
	 * entryClassName, entryId, roleIdsToActionIds);
	 * 
	 * }
	 */
	
	public void searching(ActionRequest request, ActionResponse response) throws PortalException, SystemException {
		String keywordSeach = ParamUtil.getString(request, "keywords");
		Hits hits = null;
		System.out.println(keywordSeach);
		HttpServletRequest servletRequest = PortalUtil.getHttpServletRequest(request);
		SearchContext searchContext = SearchContextFactory.getInstance(servletRequest);
		BooleanQuery booleanQuery = BooleanQueryFactoryUtil.create(searchContext);
		Map<Long, String> searchEntries = new HashMap<Long, String>();
		TermQuery termQuery1 = TermQueryFactoryUtil.create(searchContext, Field.ENTRY_CLASS_NAME,
				Projects.class.getName());
		booleanQuery.add(termQuery1, BooleanClauseOccur.MUST);
		if (Validator.isNotNull(keywordSeach)) {
			BooleanQuery booleanKeywordsSearchQuery = BooleanQueryFactoryUtil.create(searchContext);
			booleanKeywordsSearchQuery.addTerms(SEARCH_FIELDS, keywordSeach, true);
			booleanQuery.add(booleanKeywordsSearchQuery, BooleanClauseOccur.MUST);
		}

		hits = SearchEngineUtil.search(searchContext, booleanQuery);
		System.out.println("Hits length----" + hits.getDocs().length);
		ImagesUploadDownload img = new ImagesUploadDownload();
		for (int i = 0; i < hits.getDocs().length; i++) {
			Document doc = hits.doc(i);
			long entryId = GetterUtil.getLong(doc.get(Field.ENTRY_CLASS_PK));
			Projects projects = ProjectsLocalServiceUtil.getProjects(entryId);
			searchEntries.put(projects.getProjectsId(), projects.getTitle());
			System.out.println("entryID" + entryId);
			System.out.println("Projects Title" + projects.getTitle());
			System.out.println("Projects Image" + projects.getImages());
		}
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		Map<String, String> urlImagesMap = img.getAllFileLink(themeDisplay);
		request.setAttribute("urlImagesMap", urlImagesMap);
		request.setAttribute("searchEntries", searchEntries);
	}
	
	public void addComment(ActionRequest request, ActionResponse response)
			throws PortalException, SystemException, IOException, PortletException {
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		long groupId = themeDisplay.getScopeGroupId();
		long projectId = ParamUtil.getLong(request, "projectId");
		String comment = ParamUtil.getString(request, "comments");
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Projects.class.getName(), request);
		long userId = serviceContext.getUserId();
		User u = UserLocalServiceUtil.getUser(userId);
		String name = u.getFullName();
		MBMessageLocalServiceUtil.addDiscussionMessage(serviceContext.getUserId(), name, groupId,
				Projects.class.getName(), projectId, projectId, projectId, "comment", comment, serviceContext);
		response.setRenderParameter("jspPage", "/html/test/showproject.jsp");
	}
	
	/////////////////////////////////////////////////////
	
	/*public void addUser(ActionRequest request, ActionResponse response) throws PortalException, SystemException {
	ServiceContext serviceContext = ServiceContextFactory.getInstance(Register.class.getName(), request);
	String email = ParamUtil.getString(request, "email");
	String password = ParamUtil.getString(request, "password");
	String firstname = ParamUtil.getString(request, "firstname");
	String lastname = ParamUtil.getString(request, "lastname");
	String country = ParamUtil.getString(request, "country");
	RegisterLocalServiceUtil.addUsers(serviceContext.getUserId(), email, password, firstname, lastname, country,
			serviceContext);
	SessionMessages.add(request, "regitration Complete");
}

public void loginUser(ActionRequest request, ActionResponse response)
		throws PortalException, SystemException, IOException {

	List<MBMessage> mb=MBMessageLocalServiceUtil.getm;
	for (MBMessage mbMessage : mb) {
		System.out.println(mbMessage.getUserName());
	}
	//ServiceContext serviceContext = ServiceContextFactory.getInstance(Register.class.getName(), request);
	
	
	 * String email=ParamUtil.getString(request, "email"); String
	 * password=ParamUtil.getString(request, "password"); boolean
	 * flag=RegisterLocalServiceUtil.loginUser(email,password,serviceContext
	 * ); if(flag==true) { response.setRenderParameter("mvcPath",
	 * "/html/test/addProject.jsp"); } else {
	 * response.setRenderParameter("mvcPath", "/html/test/view.jsp"); }
	 
}*/
	
	
	/*public Map<String, String> getAllFileLink(ThemeDisplay themeDisplay) {
	Map<String, String> urlMap = new HashMap<String, String>();
	long repositoryId = themeDisplay.getScopeGroupId();
	try {
		Folder folder = getFolder(themeDisplay);
		List<FileEntry> fileEntries = DLAppServiceUtil.getFileEntries(repositoryId, folder.getFolderId());

		
		 * Map<Long, String[]> roleIdsToActionIdsForFileEntrries = new
		 * HashMap<Long, String[]>(); Role role; try { role =
		 * RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),
		 * RoleConstants.GUEST); String[] actionIdsForFileEntry = new
		 * String[] { "VIEW" };
		 * roleIdsToActionIdsForFileEntrries.put(role.getRoleId(),
		 * actionIdsForFileEntry);
		 * setAccessPermissionForGuestUsers(themeDisplay,
		 * String.valueOf(folder.getFolderId()),
		 * "com.liferay.portlet.documentlibrary.model.DLFolder",
		 * actionIdsForFileEntry, role); for (FileEntry createdFileEntry :
		 * fileEntries) {
		 * 
		 * String fileEntryId =
		 * String.valueOf(createdFileEntry.getFileEntryId());
		 * ResourcePermissionServiceUtil.setIndividualResourcePermissions(
		 * themeDisplay.getScopeGroupId(), themeDisplay.getCompanyId(),
		 * "com.liferay.portlet.documentlibrary.model.DLFileEntry",
		 * fileEntryId, roleIdsToActionIdsForFileEntrries); } } catch
		 * (Exception e) { e.printStackTrace(); }
		 
		for (FileEntry file : fileEntries) {
			String url = themeDisplay.getPortalURL() + themeDisplay.getPathContext() + "/documents/"
					+ themeDisplay.getScopeGroupId() + "/" + file.getFolderId() + "/" + file.getTitle();
			urlMap.put(String.valueOf(file.getFileEntryId()), url);

		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return urlMap;

}
*/
	
	
	/*private static String ROOT_FOLDER_NAME = PortletProps.get("fileupload.folder.name");
	private static String ROOT_FOLDER_DESCRIPTION = PortletProps.get("fileupload.folder.description");
	private static long PARENT_FOLDER_ID = DLFolderConstants.DEFAULT_PARENT_FOLDER_ID;

	public long uploadDocument(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException, PortalException, SystemException {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		createFolder(actionRequest, themeDisplay);
		long imgId = fileUpload(themeDisplay, actionRequest);
		return imgId;

	}

	public Folder createFolder(ActionRequest actionRequest, ThemeDisplay themeDisplay) {
		boolean folderExist = isFolderExist(themeDisplay);
		Folder folder = null;
		if (!folderExist) {
			long repositoryId = themeDisplay.getScopeGroupId();
			try {
				ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFolder.class.getName(),
						actionRequest);
				folder = DLAppServiceUtil.addFolder(repositoryId, PARENT_FOLDER_ID, ROOT_FOLDER_NAME,
						ROOT_FOLDER_DESCRIPTION, serviceContext);
			} catch (PortalException e1) {
				e1.printStackTrace();
			} catch (SystemException e1) {
				e1.printStackTrace();
			}
		}
		return folder;
	}

	public boolean isFolderExist(ThemeDisplay themeDisplay) {
		boolean folderExist = false;
		try {
			DLAppServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME);
			folderExist = true;
			System.out.println("Folder is already Exist");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return folderExist;
	}

	public Folder getFolder(ThemeDisplay themeDisplay) {
		Folder folder = null;
		try {
			folder = DLAppServiceUtil.getFolder(themeDisplay.getScopeGroupId(), PARENT_FOLDER_ID, ROOT_FOLDER_NAME);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return folder;
	}

	public long fileUpload(ThemeDisplay themeDisplay, ActionRequest actionRequest) {
		long imageId = 0;
		char[] chars = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < 10; i++) {
		    char c = chars[random.nextInt(chars.length)];
		    sb.append(c);
		}
		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);

		String fileName = uploadPortletRequest.getFileName("uploadedFile");
		File file = uploadPortletRequest.getFile("uploadedFile");
		String mimeType = uploadPortletRequest.getContentType("uploadedFile");
		String title =sb+fileName;
		String description = "This file is added via programatically";
		long repositoryId = themeDisplay.getScopeGroupId();
		System.out.println("Title=>" + title);
		try {
			Folder folder = getFolder(themeDisplay);
			ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(),
					actionRequest);
			InputStream is = new FileInputStream(file);
			FileEntry dbfile = DLAppServiceUtil.addFileEntry(repositoryId, folder.getFolderId(), fileName, mimeType,
					title, description, "", is, file.getTotalSpace(), serviceContext);
			imageId = dbfile.getFileEntryId();
			System.out.println("imageId--1------" + imageId);
			return imageId;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return imageId;
		}

	}*/
	
}

