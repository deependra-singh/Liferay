package com.liferay.docs.test.poc.search;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;

import javax.portlet.PortletURL;

import com.liferay.docs.test.poc.model.Projects;
import com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil;
import com.liferay.docs.test.poc.service.persistence.ProjectsActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.search.BaseIndexer;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.kernel.search.SearchContext;
import com.liferay.portal.kernel.search.SearchEngineUtil;
import com.liferay.portal.kernel.search.Summary;
import com.liferay.portal.kernel.util.GetterUtil;

public class ProjectsIndexer extends BaseIndexer {

	public static final String[] CLASS_NAMES = { Projects.class.getName() };

	public static final String PORTLET_ID = "test-portlet";

	public ProjectsIndexer() {
		setPermissionAware(true);
	}

	@Override
	public String[] getClassNames() {

		return CLASS_NAMES;
	}

	@Override
	public String getPortletId() {
		return PORTLET_ID;
	}

	@Override
	protected void doDelete(Object obj) throws Exception {
		Projects projects = (Projects) obj;
		deleteDocument(projects.getCompanyId(), projects.getProjectsId());
		
	}

	
	@Override
	protected Document doGetDocument(Object obj) throws Exception {
		Projects projects = (Projects) obj;
		//String [] projectDetails={projects.getDescription(), String.valueOf(projects.getImages())};
		Document document = getBaseModelDocument(PORTLET_ID, projects);
		document.addText(Field.ENTRY_CLASS_NAME, Projects.class.getName());
		document.addDate(Field.MODIFIED_DATE, projects.getModifiedDate());
		document.addText(Field.TITLE, projects.getTitle());
		document.addText(Field.CONTENT, projects.getDescription());
		document.addText(Field.CONTENT, String.valueOf(projects.getImages()));
		document.addText(Field.CONTENT, String.valueOf(projects.getProjectsId()));
		//document.addText(Field.CONTENT,projectDetails );
		document.addKeyword(Field.GROUP_ID, getSiteGroupId(projects.getGroupId()));
		document.addKeyword(Field.SCOPE_GROUP_ID, projects.getGroupId());

		return document;
	}  

	@Override
	protected Summary doGetSummary(Document document, Locale locale, String snippet, PortletURL portletURL)
			throws Exception {
		Summary summary = createSummary(document);
		summary.setMaxContentLength(200);
		return summary;
	}

	@Override
	protected void doReindex(Object obj) throws Exception {
		Projects projects = (Projects) obj;
		Document document = getDocument(projects);
		SearchEngineUtil.updateDocument(getSearchEngineId(), projects.getCompanyId(), document,true);

	}

	@Override
	protected void doReindex(String className, long classPK) throws Exception {
		Projects projects = ProjectsLocalServiceUtil.getProjects(classPK);

		doReindex(projects);

	}

	@Override
	protected void doReindex(String[] ids) throws Exception {
		long companyId = GetterUtil.getLong(ids[0]);
		reindexEntries(companyId);

	}

	@Override
	protected String getPortletId(SearchContext searchContext) {
		return PORTLET_ID;
	}

	protected void reindexEntries(long companyId) throws PortalException, SystemException {

		final Collection<Document> documents = new ArrayList<Document>();
		ActionableDynamicQuery actionableDynamicQuery = new ProjectsActionableDynamicQuery() {
			@Override
			protected void addCriteria(DynamicQuery dynamicQuery) {
			}
			@Override
			protected void performAction(Object object) throws PortalException {
				Projects projects = (Projects) object;
				Document document = getDocument(projects);
				documents.add(document);
			}

		};
		actionableDynamicQuery.setCompanyId(companyId);
		actionableDynamicQuery.performActions();
		SearchEngineUtil.updateDocuments(getSearchEngineId(), companyId, documents,true);
	}

}
