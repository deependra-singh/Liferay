package com.liferay.docs.test.poc.model;

import com.liferay.portal.model.PersistedModel;

/**
 * The extended model interface for the Comments service. Represents a row in the &quot;test_Comments&quot; database table, with each column mapped to a property of this class.
 *
 * @author anuragch
 * @see CommentsModel
 * @see com.liferay.docs.test.poc.model.impl.CommentsImpl
 * @see com.liferay.docs.test.poc.model.impl.CommentsModelImpl
 * @generated
 */
public interface Comments extends CommentsModel, PersistedModel {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this interface directly. Add methods to {@link com.liferay.docs.test.poc.model.impl.CommentsImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
     */
}
