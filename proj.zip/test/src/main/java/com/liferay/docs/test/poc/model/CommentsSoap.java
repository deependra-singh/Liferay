package com.liferay.docs.test.poc.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.liferay.docs.test.poc.service.http.CommentsServiceSoap}.
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.http.CommentsServiceSoap
 * @generated
 */
public class CommentsSoap implements Serializable {
    private String _uuid;
    private long _commentsId;
    private long _groupId;
    private long _companyId;
    private long _userId;
    private String _userName;
    private Date _createDate;
    private Date _modifiedDate;
    private String _comments;
    private long _projectsId;

    public CommentsSoap() {
    }

    public static CommentsSoap toSoapModel(Comments model) {
        CommentsSoap soapModel = new CommentsSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setCommentsId(model.getCommentsId());
        soapModel.setGroupId(model.getGroupId());
        soapModel.setCompanyId(model.getCompanyId());
        soapModel.setUserId(model.getUserId());
        soapModel.setUserName(model.getUserName());
        soapModel.setCreateDate(model.getCreateDate());
        soapModel.setModifiedDate(model.getModifiedDate());
        soapModel.setComments(model.getComments());
        soapModel.setProjectsId(model.getProjectsId());

        return soapModel;
    }

    public static CommentsSoap[] toSoapModels(Comments[] models) {
        CommentsSoap[] soapModels = new CommentsSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static CommentsSoap[][] toSoapModels(Comments[][] models) {
        CommentsSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new CommentsSoap[models.length][models[0].length];
        } else {
            soapModels = new CommentsSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static CommentsSoap[] toSoapModels(List<Comments> models) {
        List<CommentsSoap> soapModels = new ArrayList<CommentsSoap>(models.size());

        for (Comments model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new CommentsSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _commentsId;
    }

    public void setPrimaryKey(long pk) {
        setCommentsId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getCommentsId() {
        return _commentsId;
    }

    public void setCommentsId(long commentsId) {
        _commentsId = commentsId;
    }

    public long getGroupId() {
        return _groupId;
    }

    public void setGroupId(long groupId) {
        _groupId = groupId;
    }

    public long getCompanyId() {
        return _companyId;
    }

    public void setCompanyId(long companyId) {
        _companyId = companyId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }

    public String getUserName() {
        return _userName;
    }

    public void setUserName(String userName) {
        _userName = userName;
    }

    public Date getCreateDate() {
        return _createDate;
    }

    public void setCreateDate(Date createDate) {
        _createDate = createDate;
    }

    public Date getModifiedDate() {
        return _modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        _modifiedDate = modifiedDate;
    }

    public String getComments() {
        return _comments;
    }

    public void setComments(String comments) {
        _comments = comments;
    }

    public long getProjectsId() {
        return _projectsId;
    }

    public void setProjectsId(long projectsId) {
        _projectsId = projectsId;
    }
}
