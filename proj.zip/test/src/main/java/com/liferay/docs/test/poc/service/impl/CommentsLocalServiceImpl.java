package com.liferay.docs.test.poc.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.docs.test.poc.model.Comments;
import com.liferay.docs.test.poc.service.base.CommentsLocalServiceBaseImpl;
import com.liferay.portal.NoSuchUserException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;

/**
 * The implementation of the comments local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.liferay.docs.test.poc.service.CommentsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.base.CommentsLocalServiceBaseImpl
 * @see com.liferay.docs.test.poc.service.CommentsLocalServiceUtil
 */
public class CommentsLocalServiceImpl extends CommentsLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.liferay.docs.test.poc.service.CommentsLocalServiceUtil} to access the comments local service.
     */
	public List<Comments> getComments(long groupId,long projectsId) throws SystemException
	{
		return commentsPersistence.findByG_G(groupId, projectsId);
	}
	
	public List<Comments> getComments(long groupId,long projectsId,int start,int end) throws SystemException
	{
		return commentsPersistence.findByG_G(groupId, projectsId, start, end);
	}
	
	public int getCountComments(long groupId,long projectsId) throws SystemException
	{
		return commentsPersistence.countByG_G(groupId, projectsId);
	}
	
	public Comments addComments(long userId,long projectsId,String givenComments,ServiceContext serviceContext) throws NoSuchUserException, SystemException
	{
		User user=userPersistence.findByPrimaryKey(userId);
		Date now=new Date();
		long commentsId=counterLocalService.increment();
		long groupId=serviceContext.getScopeGroupId();
		
		Comments comments=commentsPersistence.create(commentsId);
		comments.setUuid(serviceContext.getUuid());
		comments.setUserId(userId);
		comments.setGroupId(groupId);
		comments.setCompanyId(user.getCompanyId());
		comments.setUserName(user.getFullName());
		comments.setCreateDate(serviceContext.getCreateDate(now));
		comments.setModifiedDate(serviceContext.getModifiedDate(now));
		comments.setExpandoBridgeAttributes(serviceContext);
		comments.setComments(givenComments);
		comments.setProjectsId(projectsId);
		commentsPersistence.update(comments);
	    return comments;	
	}
}
