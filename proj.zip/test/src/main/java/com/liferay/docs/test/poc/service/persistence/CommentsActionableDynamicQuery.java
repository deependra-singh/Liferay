package com.liferay.docs.test.poc.service.persistence;

import com.liferay.docs.test.poc.model.Comments;
import com.liferay.docs.test.poc.service.CommentsLocalServiceUtil;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * @author anuragch
 * @generated
 */
public abstract class CommentsActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public CommentsActionableDynamicQuery() throws SystemException {
        setBaseLocalService(CommentsLocalServiceUtil.getService());
        setClass(Comments.class);

        setClassLoader(com.liferay.docs.test.poc.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("commentsId");
    }
}
