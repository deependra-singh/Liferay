
package com.liferay.docs.test.poc.service.classname;

import com.liferay.docs.test.poc.model.Projects;

public class ClassnameService {


	public static String getProjectsClassName() {

		return Projects.class.getName();
	}


}
