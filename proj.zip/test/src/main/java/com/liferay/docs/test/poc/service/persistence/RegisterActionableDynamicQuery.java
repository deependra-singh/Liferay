package com.liferay.docs.test.poc.service.persistence;

import com.liferay.docs.test.poc.model.Register;
import com.liferay.docs.test.poc.service.RegisterLocalServiceUtil;

import com.liferay.portal.kernel.dao.orm.BaseActionableDynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * @author anuragch
 * @generated
 */
public abstract class RegisterActionableDynamicQuery
    extends BaseActionableDynamicQuery {
    public RegisterActionableDynamicQuery() throws SystemException {
        setBaseLocalService(RegisterLocalServiceUtil.getService());
        setClass(Register.class);

        setClassLoader(com.liferay.docs.test.poc.service.ClpSerializer.class.getClassLoader());

        setPrimaryKeyPropertyName("registerId");
    }
}
