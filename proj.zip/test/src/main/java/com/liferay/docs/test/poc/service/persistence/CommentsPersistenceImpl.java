package com.liferay.docs.test.poc.service.persistence;

import com.liferay.docs.test.poc.NoSuchCommentsException;
import com.liferay.docs.test.poc.model.Comments;
import com.liferay.docs.test.poc.model.impl.CommentsImpl;
import com.liferay.docs.test.poc.model.impl.CommentsModelImpl;
import com.liferay.docs.test.poc.service.persistence.CommentsPersistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the comments service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author anuragch
 * @see CommentsPersistence
 * @see CommentsUtil
 * @generated
 */
public class CommentsPersistenceImpl extends BasePersistenceImpl<Comments>
    implements CommentsPersistence {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this class directly. Always use {@link CommentsUtil} to access the comments persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */
    public static final String FINDER_CLASS_NAME_ENTITY = CommentsImpl.class.getName();
    public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List1";
    public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
        ".List2";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
    public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
            new String[] {
                String.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
            new String[] { String.class.getName() },
            CommentsModelImpl.UUID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
            new String[] { String.class.getName() });
    private static final String _FINDER_COLUMN_UUID_UUID_1 = "comments.uuid IS NULL";
    private static final String _FINDER_COLUMN_UUID_UUID_2 = "comments.uuid = ?";
    private static final String _FINDER_COLUMN_UUID_UUID_3 = "(comments.uuid IS NULL OR comments.uuid = '')";
    public static final FinderPath FINDER_PATH_FETCH_BY_UUID_G = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_ENTITY, "fetchByUUID_G",
            new String[] { String.class.getName(), Long.class.getName() },
            CommentsModelImpl.UUID_COLUMN_BITMASK |
            CommentsModelImpl.GROUPID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID_G = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUUID_G",
            new String[] { String.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_UUID_G_UUID_1 = "comments.uuid IS NULL AND ";
    private static final String _FINDER_COLUMN_UUID_G_UUID_2 = "comments.uuid = ? AND ";
    private static final String _FINDER_COLUMN_UUID_G_UUID_3 = "(comments.uuid IS NULL OR comments.uuid = '') AND ";
    private static final String _FINDER_COLUMN_UUID_G_GROUPID_2 = "comments.groupId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid_C",
            new String[] {
                String.class.getName(), Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C =
        new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid_C",
            new String[] { String.class.getName(), Long.class.getName() },
            CommentsModelImpl.UUID_COLUMN_BITMASK |
            CommentsModelImpl.COMPANYID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_UUID_C = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid_C",
            new String[] { String.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_UUID_C_UUID_1 = "comments.uuid IS NULL AND ";
    private static final String _FINDER_COLUMN_UUID_C_UUID_2 = "comments.uuid = ? AND ";
    private static final String _FINDER_COLUMN_UUID_C_UUID_3 = "(comments.uuid IS NULL OR comments.uuid = '') AND ";
    private static final String _FINDER_COLUMN_UUID_C_COMPANYID_2 = "comments.companyId = ?";
    public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_G_G = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByG_G",
            new String[] {
                Long.class.getName(), Long.class.getName(),
                
            Integer.class.getName(), Integer.class.getName(),
                OrderByComparator.class.getName()
            });
    public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_G = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, CommentsImpl.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByG_G",
            new String[] { Long.class.getName(), Long.class.getName() },
            CommentsModelImpl.GROUPID_COLUMN_BITMASK |
            CommentsModelImpl.PROJECTSID_COLUMN_BITMASK);
    public static final FinderPath FINDER_PATH_COUNT_BY_G_G = new FinderPath(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsModelImpl.FINDER_CACHE_ENABLED, Long.class,
            FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByG_G",
            new String[] { Long.class.getName(), Long.class.getName() });
    private static final String _FINDER_COLUMN_G_G_GROUPID_2 = "comments.groupId = ? AND ";
    private static final String _FINDER_COLUMN_G_G_PROJECTSID_2 = "comments.projectsId = ?";
    private static final String _SQL_SELECT_COMMENTS = "SELECT comments FROM Comments comments";
    private static final String _SQL_SELECT_COMMENTS_WHERE = "SELECT comments FROM Comments comments WHERE ";
    private static final String _SQL_COUNT_COMMENTS = "SELECT COUNT(comments) FROM Comments comments";
    private static final String _SQL_COUNT_COMMENTS_WHERE = "SELECT COUNT(comments) FROM Comments comments WHERE ";
    private static final String _ORDER_BY_ENTITY_ALIAS = "comments.";
    private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No Comments exists with the primary key ";
    private static final String _NO_SUCH_ENTITY_WITH_KEY = "No Comments exists with the key {";
    private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
                PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
    private static Log _log = LogFactoryUtil.getLog(CommentsPersistenceImpl.class);
    private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
                "uuid"
            });
    private static Comments _nullComments = new CommentsImpl() {
            @Override
            public Object clone() {
                return this;
            }

            @Override
            public CacheModel<Comments> toCacheModel() {
                return _nullCommentsCacheModel;
            }
        };

    private static CacheModel<Comments> _nullCommentsCacheModel = new CacheModel<Comments>() {
            @Override
            public Comments toEntityModel() {
                return _nullComments;
            }
        };

    public CommentsPersistenceImpl() {
        setModelClass(Comments.class);
    }

    /**
     * Returns all the commentses where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByUuid(String uuid) throws SystemException {
        return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the commentses where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @return the range of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByUuid(String uuid, int start, int end)
        throws SystemException {
        return findByUuid(uuid, start, end, null);
    }

    /**
     * Returns an ordered range of all the commentses where uuid = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByUuid(String uuid, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
            finderArgs = new Object[] { uuid, start, end, orderByComparator };
        }

        List<Comments> list = (List<Comments>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (Comments comments : list) {
                if (!Validator.equals(uuid, comments.getUuid())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(3 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(3);
            }

            query.append(_SQL_SELECT_COMMENTS_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CommentsModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                if (!pagination) {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Comments>(list);
                } else {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first comments in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByUuid_First(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByUuid_First(uuid, orderByComparator);

        if (comments != null) {
            return comments;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCommentsException(msg.toString());
    }

    /**
     * Returns the first comments in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByUuid_First(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        List<Comments> list = findByUuid(uuid, 0, 1, orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last comments in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByUuid_Last(String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByUuid_Last(uuid, orderByComparator);

        if (comments != null) {
            return comments;
        }

        StringBundler msg = new StringBundler(4);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCommentsException(msg.toString());
    }

    /**
     * Returns the last comments in the ordered set where uuid = &#63;.
     *
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByUuid_Last(String uuid,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid(uuid);

        if (count == 0) {
            return null;
        }

        List<Comments> list = findByUuid(uuid, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the commentses before and after the current comments in the ordered set where uuid = &#63;.
     *
     * @param commentsId the primary key of the current comments
     * @param uuid the uuid
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments[] findByUuid_PrevAndNext(long commentsId, String uuid,
        OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = findByPrimaryKey(commentsId);

        Session session = null;

        try {
            session = openSession();

            Comments[] array = new CommentsImpl[3];

            array[0] = getByUuid_PrevAndNext(session, comments, uuid,
                    orderByComparator, true);

            array[1] = comments;

            array[2] = getByUuid_PrevAndNext(session, comments, uuid,
                    orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected Comments getByUuid_PrevAndNext(Session session,
        Comments comments, String uuid, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_COMMENTS_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_UUID_2);
        }

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CommentsModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(comments);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<Comments> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the commentses where uuid = &#63; from the database.
     *
     * @param uuid the uuid
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid(String uuid) throws SystemException {
        for (Comments comments : findByUuid(uuid, QueryUtil.ALL_POS,
                QueryUtil.ALL_POS, null)) {
            remove(comments);
        }
    }

    /**
     * Returns the number of commentses where uuid = &#63;.
     *
     * @param uuid the uuid
     * @return the number of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid(String uuid) throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

        Object[] finderArgs = new Object[] { uuid };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(2);

            query.append(_SQL_COUNT_COMMENTS_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_UUID_2);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns the comments where uuid = &#63; and groupId = &#63; or throws a {@link com.liferay.docs.test.poc.NoSuchCommentsException} if it could not be found.
     *
     * @param uuid the uuid
     * @param groupId the group ID
     * @return the matching comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByUUID_G(String uuid, long groupId)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByUUID_G(uuid, groupId);

        if (comments == null) {
            StringBundler msg = new StringBundler(6);

            msg.append(_NO_SUCH_ENTITY_WITH_KEY);

            msg.append("uuid=");
            msg.append(uuid);

            msg.append(", groupId=");
            msg.append(groupId);

            msg.append(StringPool.CLOSE_CURLY_BRACE);

            if (_log.isWarnEnabled()) {
                _log.warn(msg.toString());
            }

            throw new NoSuchCommentsException(msg.toString());
        }

        return comments;
    }

    /**
     * Returns the comments where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
     *
     * @param uuid the uuid
     * @param groupId the group ID
     * @return the matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByUUID_G(String uuid, long groupId)
        throws SystemException {
        return fetchByUUID_G(uuid, groupId, true);
    }

    /**
     * Returns the comments where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
     *
     * @param uuid the uuid
     * @param groupId the group ID
     * @param retrieveFromCache whether to use the finder cache
     * @return the matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByUUID_G(String uuid, long groupId,
        boolean retrieveFromCache) throws SystemException {
        Object[] finderArgs = new Object[] { uuid, groupId };

        Object result = null;

        if (retrieveFromCache) {
            result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_UUID_G,
                    finderArgs, this);
        }

        if (result instanceof Comments) {
            Comments comments = (Comments) result;

            if (!Validator.equals(uuid, comments.getUuid()) ||
                    (groupId != comments.getGroupId())) {
                result = null;
            }
        }

        if (result == null) {
            StringBundler query = new StringBundler(4);

            query.append(_SQL_SELECT_COMMENTS_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_G_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_G_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_G_UUID_2);
            }

            query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                qPos.add(groupId);

                List<Comments> list = q.list();

                if (list.isEmpty()) {
                    FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
                        finderArgs, list);
                } else {
                    Comments comments = list.get(0);

                    result = comments;

                    cacheResult(comments);

                    if ((comments.getUuid() == null) ||
                            !comments.getUuid().equals(uuid) ||
                            (comments.getGroupId() != groupId)) {
                        FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
                            finderArgs, comments);
                    }
                }
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G,
                    finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        if (result instanceof List<?>) {
            return null;
        } else {
            return (Comments) result;
        }
    }

    /**
     * Removes the comments where uuid = &#63; and groupId = &#63; from the database.
     *
     * @param uuid the uuid
     * @param groupId the group ID
     * @return the comments that was removed
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments removeByUUID_G(String uuid, long groupId)
        throws NoSuchCommentsException, SystemException {
        Comments comments = findByUUID_G(uuid, groupId);

        return remove(comments);
    }

    /**
     * Returns the number of commentses where uuid = &#63; and groupId = &#63;.
     *
     * @param uuid the uuid
     * @param groupId the group ID
     * @return the number of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUUID_G(String uuid, long groupId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_G;

        Object[] finderArgs = new Object[] { uuid, groupId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_COMMENTS_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_G_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_G_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_G_UUID_2);
            }

            query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                qPos.add(groupId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the commentses where uuid = &#63; and companyId = &#63;.
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @return the matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByUuid_C(String uuid, long companyId)
        throws SystemException {
        return findByUuid_C(uuid, companyId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the commentses where uuid = &#63; and companyId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @return the range of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByUuid_C(String uuid, long companyId, int start,
        int end) throws SystemException {
        return findByUuid_C(uuid, companyId, start, end, null);
    }

    /**
     * Returns an ordered range of all the commentses where uuid = &#63; and companyId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByUuid_C(String uuid, long companyId, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C;
            finderArgs = new Object[] { uuid, companyId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C;
            finderArgs = new Object[] {
                    uuid, companyId,
                    
                    start, end, orderByComparator
                };
        }

        List<Comments> list = (List<Comments>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (Comments comments : list) {
                if (!Validator.equals(uuid, comments.getUuid()) ||
                        (companyId != comments.getCompanyId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_COMMENTS_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_C_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_C_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_C_UUID_2);
            }

            query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CommentsModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                qPos.add(companyId);

                if (!pagination) {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Comments>(list);
                } else {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first comments in the ordered set where uuid = &#63; and companyId = &#63;.
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByUuid_C_First(String uuid, long companyId,
        OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByUuid_C_First(uuid, companyId,
                orderByComparator);

        if (comments != null) {
            return comments;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(", companyId=");
        msg.append(companyId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCommentsException(msg.toString());
    }

    /**
     * Returns the first comments in the ordered set where uuid = &#63; and companyId = &#63;.
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByUuid_C_First(String uuid, long companyId,
        OrderByComparator orderByComparator) throws SystemException {
        List<Comments> list = findByUuid_C(uuid, companyId, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last comments in the ordered set where uuid = &#63; and companyId = &#63;.
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByUuid_C_Last(String uuid, long companyId,
        OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByUuid_C_Last(uuid, companyId,
                orderByComparator);

        if (comments != null) {
            return comments;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("uuid=");
        msg.append(uuid);

        msg.append(", companyId=");
        msg.append(companyId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCommentsException(msg.toString());
    }

    /**
     * Returns the last comments in the ordered set where uuid = &#63; and companyId = &#63;.
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByUuid_C_Last(String uuid, long companyId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByUuid_C(uuid, companyId);

        if (count == 0) {
            return null;
        }

        List<Comments> list = findByUuid_C(uuid, companyId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the commentses before and after the current comments in the ordered set where uuid = &#63; and companyId = &#63;.
     *
     * @param commentsId the primary key of the current comments
     * @param uuid the uuid
     * @param companyId the company ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments[] findByUuid_C_PrevAndNext(long commentsId, String uuid,
        long companyId, OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = findByPrimaryKey(commentsId);

        Session session = null;

        try {
            session = openSession();

            Comments[] array = new CommentsImpl[3];

            array[0] = getByUuid_C_PrevAndNext(session, comments, uuid,
                    companyId, orderByComparator, true);

            array[1] = comments;

            array[2] = getByUuid_C_PrevAndNext(session, comments, uuid,
                    companyId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected Comments getByUuid_C_PrevAndNext(Session session,
        Comments comments, String uuid, long companyId,
        OrderByComparator orderByComparator, boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_COMMENTS_WHERE);

        boolean bindUuid = false;

        if (uuid == null) {
            query.append(_FINDER_COLUMN_UUID_C_UUID_1);
        } else if (uuid.equals(StringPool.BLANK)) {
            query.append(_FINDER_COLUMN_UUID_C_UUID_3);
        } else {
            bindUuid = true;

            query.append(_FINDER_COLUMN_UUID_C_UUID_2);
        }

        query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CommentsModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        if (bindUuid) {
            qPos.add(uuid);
        }

        qPos.add(companyId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(comments);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<Comments> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the commentses where uuid = &#63; and companyId = &#63; from the database.
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByUuid_C(String uuid, long companyId)
        throws SystemException {
        for (Comments comments : findByUuid_C(uuid, companyId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(comments);
        }
    }

    /**
     * Returns the number of commentses where uuid = &#63; and companyId = &#63;.
     *
     * @param uuid the uuid
     * @param companyId the company ID
     * @return the number of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByUuid_C(String uuid, long companyId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_C;

        Object[] finderArgs = new Object[] { uuid, companyId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_COMMENTS_WHERE);

            boolean bindUuid = false;

            if (uuid == null) {
                query.append(_FINDER_COLUMN_UUID_C_UUID_1);
            } else if (uuid.equals(StringPool.BLANK)) {
                query.append(_FINDER_COLUMN_UUID_C_UUID_3);
            } else {
                bindUuid = true;

                query.append(_FINDER_COLUMN_UUID_C_UUID_2);
            }

            query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                if (bindUuid) {
                    qPos.add(uuid);
                }

                qPos.add(companyId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Returns all the commentses where groupId = &#63; and projectsId = &#63;.
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @return the matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByG_G(long groupId, long projectsId)
        throws SystemException {
        return findByG_G(groupId, projectsId, QueryUtil.ALL_POS,
            QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the commentses where groupId = &#63; and projectsId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @return the range of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByG_G(long groupId, long projectsId, int start,
        int end) throws SystemException {
        return findByG_G(groupId, projectsId, start, end, null);
    }

    /**
     * Returns an ordered range of all the commentses where groupId = &#63; and projectsId = &#63;.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findByG_G(long groupId, long projectsId, int start,
        int end, OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_G;
            finderArgs = new Object[] { groupId, projectsId };
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_G_G;
            finderArgs = new Object[] {
                    groupId, projectsId,
                    
                    start, end, orderByComparator
                };
        }

        List<Comments> list = (List<Comments>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if ((list != null) && !list.isEmpty()) {
            for (Comments comments : list) {
                if ((groupId != comments.getGroupId()) ||
                        (projectsId != comments.getProjectsId())) {
                    list = null;

                    break;
                }
            }
        }

        if (list == null) {
            StringBundler query = null;

            if (orderByComparator != null) {
                query = new StringBundler(4 +
                        (orderByComparator.getOrderByFields().length * 3));
            } else {
                query = new StringBundler(4);
            }

            query.append(_SQL_SELECT_COMMENTS_WHERE);

            query.append(_FINDER_COLUMN_G_G_GROUPID_2);

            query.append(_FINDER_COLUMN_G_G_PROJECTSID_2);

            if (orderByComparator != null) {
                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);
            } else
             if (pagination) {
                query.append(CommentsModelImpl.ORDER_BY_JPQL);
            }

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(groupId);

                qPos.add(projectsId);

                if (!pagination) {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Comments>(list);
                } else {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Returns the first comments in the ordered set where groupId = &#63; and projectsId = &#63;.
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByG_G_First(long groupId, long projectsId,
        OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByG_G_First(groupId, projectsId,
                orderByComparator);

        if (comments != null) {
            return comments;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("groupId=");
        msg.append(groupId);

        msg.append(", projectsId=");
        msg.append(projectsId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCommentsException(msg.toString());
    }

    /**
     * Returns the first comments in the ordered set where groupId = &#63; and projectsId = &#63;.
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the first matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByG_G_First(long groupId, long projectsId,
        OrderByComparator orderByComparator) throws SystemException {
        List<Comments> list = findByG_G(groupId, projectsId, 0, 1,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the last comments in the ordered set where groupId = &#63; and projectsId = &#63;.
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByG_G_Last(long groupId, long projectsId,
        OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByG_G_Last(groupId, projectsId,
                orderByComparator);

        if (comments != null) {
            return comments;
        }

        StringBundler msg = new StringBundler(6);

        msg.append(_NO_SUCH_ENTITY_WITH_KEY);

        msg.append("groupId=");
        msg.append(groupId);

        msg.append(", projectsId=");
        msg.append(projectsId);

        msg.append(StringPool.CLOSE_CURLY_BRACE);

        throw new NoSuchCommentsException(msg.toString());
    }

    /**
     * Returns the last comments in the ordered set where groupId = &#63; and projectsId = &#63;.
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the last matching comments, or <code>null</code> if a matching comments could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByG_G_Last(long groupId, long projectsId,
        OrderByComparator orderByComparator) throws SystemException {
        int count = countByG_G(groupId, projectsId);

        if (count == 0) {
            return null;
        }

        List<Comments> list = findByG_G(groupId, projectsId, count - 1, count,
                orderByComparator);

        if (!list.isEmpty()) {
            return list.get(0);
        }

        return null;
    }

    /**
     * Returns the commentses before and after the current comments in the ordered set where groupId = &#63; and projectsId = &#63;.
     *
     * @param commentsId the primary key of the current comments
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
     * @return the previous, current, and next comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments[] findByG_G_PrevAndNext(long commentsId, long groupId,
        long projectsId, OrderByComparator orderByComparator)
        throws NoSuchCommentsException, SystemException {
        Comments comments = findByPrimaryKey(commentsId);

        Session session = null;

        try {
            session = openSession();

            Comments[] array = new CommentsImpl[3];

            array[0] = getByG_G_PrevAndNext(session, comments, groupId,
                    projectsId, orderByComparator, true);

            array[1] = comments;

            array[2] = getByG_G_PrevAndNext(session, comments, groupId,
                    projectsId, orderByComparator, false);

            return array;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    protected Comments getByG_G_PrevAndNext(Session session, Comments comments,
        long groupId, long projectsId, OrderByComparator orderByComparator,
        boolean previous) {
        StringBundler query = null;

        if (orderByComparator != null) {
            query = new StringBundler(6 +
                    (orderByComparator.getOrderByFields().length * 6));
        } else {
            query = new StringBundler(3);
        }

        query.append(_SQL_SELECT_COMMENTS_WHERE);

        query.append(_FINDER_COLUMN_G_G_GROUPID_2);

        query.append(_FINDER_COLUMN_G_G_PROJECTSID_2);

        if (orderByComparator != null) {
            String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

            if (orderByConditionFields.length > 0) {
                query.append(WHERE_AND);
            }

            for (int i = 0; i < orderByConditionFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByConditionFields[i]);

                if ((i + 1) < orderByConditionFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN_HAS_NEXT);
                    } else {
                        query.append(WHERE_LESSER_THAN_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(WHERE_GREATER_THAN);
                    } else {
                        query.append(WHERE_LESSER_THAN);
                    }
                }
            }

            query.append(ORDER_BY_CLAUSE);

            String[] orderByFields = orderByComparator.getOrderByFields();

            for (int i = 0; i < orderByFields.length; i++) {
                query.append(_ORDER_BY_ENTITY_ALIAS);
                query.append(orderByFields[i]);

                if ((i + 1) < orderByFields.length) {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC_HAS_NEXT);
                    } else {
                        query.append(ORDER_BY_DESC_HAS_NEXT);
                    }
                } else {
                    if (orderByComparator.isAscending() ^ previous) {
                        query.append(ORDER_BY_ASC);
                    } else {
                        query.append(ORDER_BY_DESC);
                    }
                }
            }
        } else {
            query.append(CommentsModelImpl.ORDER_BY_JPQL);
        }

        String sql = query.toString();

        Query q = session.createQuery(sql);

        q.setFirstResult(0);
        q.setMaxResults(2);

        QueryPos qPos = QueryPos.getInstance(q);

        qPos.add(groupId);

        qPos.add(projectsId);

        if (orderByComparator != null) {
            Object[] values = orderByComparator.getOrderByConditionValues(comments);

            for (Object value : values) {
                qPos.add(value);
            }
        }

        List<Comments> list = q.list();

        if (list.size() == 2) {
            return list.get(1);
        } else {
            return null;
        }
    }

    /**
     * Removes all the commentses where groupId = &#63; and projectsId = &#63; from the database.
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeByG_G(long groupId, long projectsId)
        throws SystemException {
        for (Comments comments : findByG_G(groupId, projectsId,
                QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
            remove(comments);
        }
    }

    /**
     * Returns the number of commentses where groupId = &#63; and projectsId = &#63;.
     *
     * @param groupId the group ID
     * @param projectsId the projects ID
     * @return the number of matching commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countByG_G(long groupId, long projectsId)
        throws SystemException {
        FinderPath finderPath = FINDER_PATH_COUNT_BY_G_G;

        Object[] finderArgs = new Object[] { groupId, projectsId };

        Long count = (Long) FinderCacheUtil.getResult(finderPath, finderArgs,
                this);

        if (count == null) {
            StringBundler query = new StringBundler(3);

            query.append(_SQL_COUNT_COMMENTS_WHERE);

            query.append(_FINDER_COLUMN_G_G_GROUPID_2);

            query.append(_FINDER_COLUMN_G_G_PROJECTSID_2);

            String sql = query.toString();

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                QueryPos qPos = QueryPos.getInstance(q);

                qPos.add(groupId);

                qPos.add(projectsId);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(finderPath, finderArgs, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    /**
     * Caches the comments in the entity cache if it is enabled.
     *
     * @param comments the comments
     */
    @Override
    public void cacheResult(Comments comments) {
        EntityCacheUtil.putResult(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsImpl.class, comments.getPrimaryKey(), comments);

        FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
            new Object[] { comments.getUuid(), comments.getGroupId() }, comments);

        comments.resetOriginalValues();
    }

    /**
     * Caches the commentses in the entity cache if it is enabled.
     *
     * @param commentses the commentses
     */
    @Override
    public void cacheResult(List<Comments> commentses) {
        for (Comments comments : commentses) {
            if (EntityCacheUtil.getResult(
                        CommentsModelImpl.ENTITY_CACHE_ENABLED,
                        CommentsImpl.class, comments.getPrimaryKey()) == null) {
                cacheResult(comments);
            } else {
                comments.resetOriginalValues();
            }
        }
    }

    /**
     * Clears the cache for all commentses.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache() {
        if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
            CacheRegistryUtil.clear(CommentsImpl.class.getName());
        }

        EntityCacheUtil.clearCache(CommentsImpl.class.getName());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }

    /**
     * Clears the cache for the comments.
     *
     * <p>
     * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
     * </p>
     */
    @Override
    public void clearCache(Comments comments) {
        EntityCacheUtil.removeResult(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsImpl.class, comments.getPrimaryKey());

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        clearUniqueFindersCache(comments);
    }

    @Override
    public void clearCache(List<Comments> commentses) {
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

        for (Comments comments : commentses) {
            EntityCacheUtil.removeResult(CommentsModelImpl.ENTITY_CACHE_ENABLED,
                CommentsImpl.class, comments.getPrimaryKey());

            clearUniqueFindersCache(comments);
        }
    }

    protected void cacheUniqueFindersCache(Comments comments) {
        if (comments.isNew()) {
            Object[] args = new Object[] {
                    comments.getUuid(), comments.getGroupId()
                };

            FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
                Long.valueOf(1));
            FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
                comments);
        } else {
            CommentsModelImpl commentsModelImpl = (CommentsModelImpl) comments;

            if ((commentsModelImpl.getColumnBitmask() &
                    FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        comments.getUuid(), comments.getGroupId()
                    };

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
                    Long.valueOf(1));
                FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
                    comments);
            }
        }
    }

    protected void clearUniqueFindersCache(Comments comments) {
        CommentsModelImpl commentsModelImpl = (CommentsModelImpl) comments;

        Object[] args = new Object[] { comments.getUuid(), comments.getGroupId() };

        FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
        FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);

        if ((commentsModelImpl.getColumnBitmask() &
                FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
            args = new Object[] {
                    commentsModelImpl.getOriginalUuid(),
                    commentsModelImpl.getOriginalGroupId()
                };

            FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
            FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);
        }
    }

    /**
     * Creates a new comments with the primary key. Does not add the comments to the database.
     *
     * @param commentsId the primary key for the new comments
     * @return the new comments
     */
    @Override
    public Comments create(long commentsId) {
        Comments comments = new CommentsImpl();

        comments.setNew(true);
        comments.setPrimaryKey(commentsId);

        String uuid = PortalUUIDUtil.generate();

        comments.setUuid(uuid);

        return comments;
    }

    /**
     * Removes the comments with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param commentsId the primary key of the comments
     * @return the comments that was removed
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments remove(long commentsId)
        throws NoSuchCommentsException, SystemException {
        return remove((Serializable) commentsId);
    }

    /**
     * Removes the comments with the primary key from the database. Also notifies the appropriate model listeners.
     *
     * @param primaryKey the primary key of the comments
     * @return the comments that was removed
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments remove(Serializable primaryKey)
        throws NoSuchCommentsException, SystemException {
        Session session = null;

        try {
            session = openSession();

            Comments comments = (Comments) session.get(CommentsImpl.class,
                    primaryKey);

            if (comments == null) {
                if (_log.isWarnEnabled()) {
                    _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
                }

                throw new NoSuchCommentsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                    primaryKey);
            }

            return remove(comments);
        } catch (NoSuchCommentsException nsee) {
            throw nsee;
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }
    }

    @Override
    protected Comments removeImpl(Comments comments) throws SystemException {
        comments = toUnwrappedModel(comments);

        Session session = null;

        try {
            session = openSession();

            if (!session.contains(comments)) {
                comments = (Comments) session.get(CommentsImpl.class,
                        comments.getPrimaryKeyObj());
            }

            if (comments != null) {
                session.delete(comments);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        if (comments != null) {
            clearCache(comments);
        }

        return comments;
    }

    @Override
    public Comments updateImpl(
        com.liferay.docs.test.poc.model.Comments comments)
        throws SystemException {
        comments = toUnwrappedModel(comments);

        boolean isNew = comments.isNew();

        CommentsModelImpl commentsModelImpl = (CommentsModelImpl) comments;

        if (Validator.isNull(comments.getUuid())) {
            String uuid = PortalUUIDUtil.generate();

            comments.setUuid(uuid);
        }

        Session session = null;

        try {
            session = openSession();

            if (comments.isNew()) {
                session.save(comments);

                comments.setNew(false);
            } else {
                session.merge(comments);
            }
        } catch (Exception e) {
            throw processException(e);
        } finally {
            closeSession(session);
        }

        FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

        if (isNew || !CommentsModelImpl.COLUMN_BITMASK_ENABLED) {
            FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
        }
        else {
            if ((commentsModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
                Object[] args = new Object[] { commentsModelImpl.getOriginalUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);

                args = new Object[] { commentsModelImpl.getUuid() };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
                    args);
            }

            if ((commentsModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        commentsModelImpl.getOriginalUuid(),
                        commentsModelImpl.getOriginalCompanyId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
                    args);

                args = new Object[] {
                        commentsModelImpl.getUuid(),
                        commentsModelImpl.getCompanyId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
                    args);
            }

            if ((commentsModelImpl.getColumnBitmask() &
                    FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_G.getColumnBitmask()) != 0) {
                Object[] args = new Object[] {
                        commentsModelImpl.getOriginalGroupId(),
                        commentsModelImpl.getOriginalProjectsId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_G_G, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_G,
                    args);

                args = new Object[] {
                        commentsModelImpl.getGroupId(),
                        commentsModelImpl.getProjectsId()
                    };

                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_G_G, args);
                FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_G_G,
                    args);
            }
        }

        EntityCacheUtil.putResult(CommentsModelImpl.ENTITY_CACHE_ENABLED,
            CommentsImpl.class, comments.getPrimaryKey(), comments);

        clearUniqueFindersCache(comments);
        cacheUniqueFindersCache(comments);

        return comments;
    }

    protected Comments toUnwrappedModel(Comments comments) {
        if (comments instanceof CommentsImpl) {
            return comments;
        }

        CommentsImpl commentsImpl = new CommentsImpl();

        commentsImpl.setNew(comments.isNew());
        commentsImpl.setPrimaryKey(comments.getPrimaryKey());

        commentsImpl.setUuid(comments.getUuid());
        commentsImpl.setCommentsId(comments.getCommentsId());
        commentsImpl.setGroupId(comments.getGroupId());
        commentsImpl.setCompanyId(comments.getCompanyId());
        commentsImpl.setUserId(comments.getUserId());
        commentsImpl.setUserName(comments.getUserName());
        commentsImpl.setCreateDate(comments.getCreateDate());
        commentsImpl.setModifiedDate(comments.getModifiedDate());
        commentsImpl.setComments(comments.getComments());
        commentsImpl.setProjectsId(comments.getProjectsId());

        return commentsImpl;
    }

    /**
     * Returns the comments with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
     *
     * @param primaryKey the primary key of the comments
     * @return the comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByPrimaryKey(Serializable primaryKey)
        throws NoSuchCommentsException, SystemException {
        Comments comments = fetchByPrimaryKey(primaryKey);

        if (comments == null) {
            if (_log.isWarnEnabled()) {
                _log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
            }

            throw new NoSuchCommentsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
                primaryKey);
        }

        return comments;
    }

    /**
     * Returns the comments with the primary key or throws a {@link com.liferay.docs.test.poc.NoSuchCommentsException} if it could not be found.
     *
     * @param commentsId the primary key of the comments
     * @return the comments
     * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments findByPrimaryKey(long commentsId)
        throws NoSuchCommentsException, SystemException {
        return findByPrimaryKey((Serializable) commentsId);
    }

    /**
     * Returns the comments with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param primaryKey the primary key of the comments
     * @return the comments, or <code>null</code> if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByPrimaryKey(Serializable primaryKey)
        throws SystemException {
        Comments comments = (Comments) EntityCacheUtil.getResult(CommentsModelImpl.ENTITY_CACHE_ENABLED,
                CommentsImpl.class, primaryKey);

        if (comments == _nullComments) {
            return null;
        }

        if (comments == null) {
            Session session = null;

            try {
                session = openSession();

                comments = (Comments) session.get(CommentsImpl.class, primaryKey);

                if (comments != null) {
                    cacheResult(comments);
                } else {
                    EntityCacheUtil.putResult(CommentsModelImpl.ENTITY_CACHE_ENABLED,
                        CommentsImpl.class, primaryKey, _nullComments);
                }
            } catch (Exception e) {
                EntityCacheUtil.removeResult(CommentsModelImpl.ENTITY_CACHE_ENABLED,
                    CommentsImpl.class, primaryKey);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return comments;
    }

    /**
     * Returns the comments with the primary key or returns <code>null</code> if it could not be found.
     *
     * @param commentsId the primary key of the comments
     * @return the comments, or <code>null</code> if a comments with the primary key could not be found
     * @throws SystemException if a system exception occurred
     */
    @Override
    public Comments fetchByPrimaryKey(long commentsId)
        throws SystemException {
        return fetchByPrimaryKey((Serializable) commentsId);
    }

    /**
     * Returns all the commentses.
     *
     * @return the commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findAll() throws SystemException {
        return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
    }

    /**
     * Returns a range of all the commentses.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @return the range of commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findAll(int start, int end) throws SystemException {
        return findAll(start, end, null);
    }

    /**
     * Returns an ordered range of all the commentses.
     *
     * <p>
     * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
     * </p>
     *
     * @param start the lower bound of the range of commentses
     * @param end the upper bound of the range of commentses (not inclusive)
     * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
     * @return the ordered range of commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public List<Comments> findAll(int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        boolean pagination = true;
        FinderPath finderPath = null;
        Object[] finderArgs = null;

        if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
                (orderByComparator == null)) {
            pagination = false;
            finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
            finderArgs = FINDER_ARGS_EMPTY;
        } else {
            finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
            finderArgs = new Object[] { start, end, orderByComparator };
        }

        List<Comments> list = (List<Comments>) FinderCacheUtil.getResult(finderPath,
                finderArgs, this);

        if (list == null) {
            StringBundler query = null;
            String sql = null;

            if (orderByComparator != null) {
                query = new StringBundler(2 +
                        (orderByComparator.getOrderByFields().length * 3));

                query.append(_SQL_SELECT_COMMENTS);

                appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
                    orderByComparator);

                sql = query.toString();
            } else {
                sql = _SQL_SELECT_COMMENTS;

                if (pagination) {
                    sql = sql.concat(CommentsModelImpl.ORDER_BY_JPQL);
                }
            }

            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(sql);

                if (!pagination) {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end, false);

                    Collections.sort(list);

                    list = new UnmodifiableList<Comments>(list);
                } else {
                    list = (List<Comments>) QueryUtil.list(q, getDialect(),
                            start, end);
                }

                cacheResult(list);

                FinderCacheUtil.putResult(finderPath, finderArgs, list);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(finderPath, finderArgs);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return list;
    }

    /**
     * Removes all the commentses from the database.
     *
     * @throws SystemException if a system exception occurred
     */
    @Override
    public void removeAll() throws SystemException {
        for (Comments comments : findAll()) {
            remove(comments);
        }
    }

    /**
     * Returns the number of commentses.
     *
     * @return the number of commentses
     * @throws SystemException if a system exception occurred
     */
    @Override
    public int countAll() throws SystemException {
        Long count = (Long) FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
                FINDER_ARGS_EMPTY, this);

        if (count == null) {
            Session session = null;

            try {
                session = openSession();

                Query q = session.createQuery(_SQL_COUNT_COMMENTS);

                count = (Long) q.uniqueResult();

                FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY, count);
            } catch (Exception e) {
                FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
                    FINDER_ARGS_EMPTY);

                throw processException(e);
            } finally {
                closeSession(session);
            }
        }

        return count.intValue();
    }

    @Override
    protected Set<String> getBadColumnNames() {
        return _badColumnNames;
    }

    /**
     * Initializes the comments persistence.
     */
    public void afterPropertiesSet() {
        String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
                    com.liferay.util.service.ServiceProps.get(
                        "value.object.listener.com.liferay.docs.test.poc.model.Comments")));

        if (listenerClassNames.length > 0) {
            try {
                List<ModelListener<Comments>> listenersList = new ArrayList<ModelListener<Comments>>();

                for (String listenerClassName : listenerClassNames) {
                    listenersList.add((ModelListener<Comments>) InstanceFactory.newInstance(
                            getClassLoader(), listenerClassName));
                }

                listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
            } catch (Exception e) {
                _log.error(e);
            }
        }
    }

    public void destroy() {
        EntityCacheUtil.removeCache(CommentsImpl.class.getName());
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
        FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
    }
}
