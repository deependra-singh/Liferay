package com.liferay.docs.test.poc.service.impl;

import com.liferay.docs.test.poc.service.base.RegisterServiceBaseImpl;

/**
 * The implementation of the register remote service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.liferay.docs.test.poc.service.RegisterService} interface.
 *
 * <p>
 * This is a remote service. Methods of this service are expected to have security checks based on the propagated JAAS credentials because this service can be accessed remotely.
 * </p>
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.base.RegisterServiceBaseImpl
 * @see com.liferay.docs.test.poc.service.RegisterServiceUtil
 */
public class RegisterServiceImpl extends RegisterServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.liferay.docs.test.poc.service.RegisterServiceUtil} to access the register remote service.
     */
}
