package com.liferay.docs.test.poc.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CommentsLocalService}.
 *
 * @author anuragch
 * @see CommentsLocalService
 * @generated
 */
public class CommentsLocalServiceWrapper implements CommentsLocalService,
    ServiceWrapper<CommentsLocalService> {
    private CommentsLocalService _commentsLocalService;

    public CommentsLocalServiceWrapper(
        CommentsLocalService commentsLocalService) {
        _commentsLocalService = commentsLocalService;
    }

    /**
    * Adds the comments to the database. Also notifies the appropriate model listeners.
    *
    * @param comments the comments
    * @return the comments that was added
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments addComments(
        com.liferay.docs.test.poc.model.Comments comments)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.addComments(comments);
    }

    /**
    * Creates a new comments with the primary key. Does not add the comments to the database.
    *
    * @param commentsId the primary key for the new comments
    * @return the new comments
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments createComments(
        long commentsId) {
        return _commentsLocalService.createComments(commentsId);
    }

    /**
    * Deletes the comments with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param commentsId the primary key of the comments
    * @return the comments that was removed
    * @throws PortalException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments deleteComments(
        long commentsId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.deleteComments(commentsId);
    }

    /**
    * Deletes the comments from the database. Also notifies the appropriate model listeners.
    *
    * @param comments the comments
    * @return the comments that was removed
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments deleteComments(
        com.liferay.docs.test.poc.model.Comments comments)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.deleteComments(comments);
    }

    @Override
    public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
        return _commentsLocalService.dynamicQuery();
    }

    /**
    * Performs a dynamic query on the database and returns the matching rows.
    *
    * @param dynamicQuery the dynamic query
    * @return the matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.dynamicQuery(dynamicQuery);
    }

    /**
    * Performs a dynamic query on the database and returns a range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @return the range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end) throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.dynamicQuery(dynamicQuery, start, end);
    }

    /**
    * Performs a dynamic query on the database and returns an ordered range of the matching rows.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param dynamicQuery the dynamic query
    * @param start the lower bound of the range of model instances
    * @param end the upper bound of the range of model instances (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching rows
    * @throws SystemException if a system exception occurred
    */
    @Override
    @SuppressWarnings("rawtypes")
    public java.util.List dynamicQuery(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
        int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.dynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.dynamicQueryCount(dynamicQuery);
    }

    /**
    * Returns the number of rows that match the dynamic query.
    *
    * @param dynamicQuery the dynamic query
    * @param projection the projection to apply to the query
    * @return the number of rows that match the dynamic query
    * @throws SystemException if a system exception occurred
    */
    @Override
    public long dynamicQueryCount(
        com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
        com.liferay.portal.kernel.dao.orm.Projection projection)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.dynamicQueryCount(dynamicQuery, projection);
    }

    @Override
    public com.liferay.docs.test.poc.model.Comments fetchComments(
        long commentsId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.fetchComments(commentsId);
    }

    /**
    * Returns the comments with the matching UUID and company.
    *
    * @param uuid the comments's UUID
    * @param companyId the primary key of the company
    * @return the matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments fetchCommentsByUuidAndCompanyId(
        java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.fetchCommentsByUuidAndCompanyId(uuid,
            companyId);
    }

    /**
    * Returns the comments matching the UUID and group.
    *
    * @param uuid the comments's UUID
    * @param groupId the primary key of the group
    * @return the matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments fetchCommentsByUuidAndGroupId(
        java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.fetchCommentsByUuidAndGroupId(uuid, groupId);
    }

    /**
    * Returns the comments with the primary key.
    *
    * @param commentsId the primary key of the comments
    * @return the comments
    * @throws PortalException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments getComments(long commentsId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getComments(commentsId);
    }

    @Override
    public com.liferay.portal.model.PersistedModel getPersistedModel(
        java.io.Serializable primaryKeyObj)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getPersistedModel(primaryKeyObj);
    }

    /**
    * Returns the comments with the matching UUID and company.
    *
    * @param uuid the comments's UUID
    * @param companyId the primary key of the company
    * @return the matching comments
    * @throws PortalException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments getCommentsByUuidAndCompanyId(
        java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getCommentsByUuidAndCompanyId(uuid,
            companyId);
    }

    /**
    * Returns the comments matching the UUID and group.
    *
    * @param uuid the comments's UUID
    * @param groupId the primary key of the group
    * @return the matching comments
    * @throws PortalException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments getCommentsByUuidAndGroupId(
        java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.PortalException,
            com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getCommentsByUuidAndGroupId(uuid, groupId);
    }

    /**
    * Returns a range of all the commentses.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of commentses
    * @throws SystemException if a system exception occurred
    */
    @Override
    public java.util.List<com.liferay.docs.test.poc.model.Comments> getCommentses(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getCommentses(start, end);
    }

    /**
    * Returns the number of commentses.
    *
    * @return the number of commentses
    * @throws SystemException if a system exception occurred
    */
    @Override
    public int getCommentsesCount()
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getCommentsesCount();
    }

    /**
    * Updates the comments in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
    *
    * @param comments the comments
    * @return the comments that was updated
    * @throws SystemException if a system exception occurred
    */
    @Override
    public com.liferay.docs.test.poc.model.Comments updateComments(
        com.liferay.docs.test.poc.model.Comments comments)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.updateComments(comments);
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _commentsLocalService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _commentsLocalService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _commentsLocalService.invokeMethod(name, parameterTypes,
            arguments);
    }

    @Override
    public java.util.List<com.liferay.docs.test.poc.model.Comments> getComments(
        long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getComments(groupId, projectsId);
    }

    @Override
    public java.util.List<com.liferay.docs.test.poc.model.Comments> getComments(
        long groupId, long projectsId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getComments(groupId, projectsId, start, end);
    }

    @Override
    public int getCountComments(long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.getCountComments(groupId, projectsId);
    }

    @Override
    public com.liferay.docs.test.poc.model.Comments addComments(long userId,
        long projectsId, java.lang.String givenComments,
        com.liferay.portal.service.ServiceContext serviceContext)
        throws com.liferay.portal.NoSuchUserException,
            com.liferay.portal.kernel.exception.SystemException {
        return _commentsLocalService.addComments(userId, projectsId,
            givenComments, serviceContext);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public CommentsLocalService getWrappedCommentsLocalService() {
        return _commentsLocalService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedCommentsLocalService(
        CommentsLocalService commentsLocalService) {
        _commentsLocalService = commentsLocalService;
    }

    @Override
    public CommentsLocalService getWrappedService() {
        return _commentsLocalService;
    }

    @Override
    public void setWrappedService(CommentsLocalService commentsLocalService) {
        _commentsLocalService = commentsLocalService;
    }
}
