package com.liferay.docs.test.poc.model.impl;

import com.liferay.docs.test.poc.model.Comments;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Comments in entity cache.
 *
 * @author anuragch
 * @see Comments
 * @generated
 */
public class CommentsCacheModel implements CacheModel<Comments>, Externalizable {
    public String uuid;
    public long commentsId;
    public long groupId;
    public long companyId;
    public long userId;
    public String userName;
    public long createDate;
    public long modifiedDate;
    public String comments;
    public long projectsId;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(21);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", commentsId=");
        sb.append(commentsId);
        sb.append(", groupId=");
        sb.append(groupId);
        sb.append(", companyId=");
        sb.append(companyId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append(", userName=");
        sb.append(userName);
        sb.append(", createDate=");
        sb.append(createDate);
        sb.append(", modifiedDate=");
        sb.append(modifiedDate);
        sb.append(", comments=");
        sb.append(comments);
        sb.append(", projectsId=");
        sb.append(projectsId);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Comments toEntityModel() {
        CommentsImpl commentsImpl = new CommentsImpl();

        if (uuid == null) {
            commentsImpl.setUuid(StringPool.BLANK);
        } else {
            commentsImpl.setUuid(uuid);
        }

        commentsImpl.setCommentsId(commentsId);
        commentsImpl.setGroupId(groupId);
        commentsImpl.setCompanyId(companyId);
        commentsImpl.setUserId(userId);

        if (userName == null) {
            commentsImpl.setUserName(StringPool.BLANK);
        } else {
            commentsImpl.setUserName(userName);
        }

        if (createDate == Long.MIN_VALUE) {
            commentsImpl.setCreateDate(null);
        } else {
            commentsImpl.setCreateDate(new Date(createDate));
        }

        if (modifiedDate == Long.MIN_VALUE) {
            commentsImpl.setModifiedDate(null);
        } else {
            commentsImpl.setModifiedDate(new Date(modifiedDate));
        }

        if (comments == null) {
            commentsImpl.setComments(StringPool.BLANK);
        } else {
            commentsImpl.setComments(comments);
        }

        commentsImpl.setProjectsId(projectsId);

        commentsImpl.resetOriginalValues();

        return commentsImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        commentsId = objectInput.readLong();
        groupId = objectInput.readLong();
        companyId = objectInput.readLong();
        userId = objectInput.readLong();
        userName = objectInput.readUTF();
        createDate = objectInput.readLong();
        modifiedDate = objectInput.readLong();
        comments = objectInput.readUTF();
        projectsId = objectInput.readLong();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(commentsId);
        objectOutput.writeLong(groupId);
        objectOutput.writeLong(companyId);
        objectOutput.writeLong(userId);

        if (userName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(userName);
        }

        objectOutput.writeLong(createDate);
        objectOutput.writeLong(modifiedDate);

        if (comments == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(comments);
        }

        objectOutput.writeLong(projectsId);
    }
}
