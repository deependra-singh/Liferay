package com.liferay.docs.test.poc.service.persistence;

import com.liferay.docs.test.poc.model.Comments;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the comments service. This utility wraps {@link CommentsPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author anuragch
 * @see CommentsPersistence
 * @see CommentsPersistenceImpl
 * @generated
 */
public class CommentsUtil {
    private static CommentsPersistence _persistence;

    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
     */

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
     */
    public static void clearCache() {
        getPersistence().clearCache();
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
     */
    public static void clearCache(Comments comments) {
        getPersistence().clearCache(comments);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
     */
    public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().countWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
     */
    public static List<Comments> findWithDynamicQuery(DynamicQuery dynamicQuery)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
     */
    public static List<Comments> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end)
        throws SystemException {
        return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
     */
    public static List<Comments> findWithDynamicQuery(
        DynamicQuery dynamicQuery, int start, int end,
        OrderByComparator orderByComparator) throws SystemException {
        return getPersistence()
                   .findWithDynamicQuery(dynamicQuery, start, end,
            orderByComparator);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
     */
    public static Comments update(Comments comments) throws SystemException {
        return getPersistence().update(comments);
    }

    /**
     * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
     */
    public static Comments update(Comments comments,
        ServiceContext serviceContext) throws SystemException {
        return getPersistence().update(comments, serviceContext);
    }

    /**
    * Returns all the commentses where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid);
    }

    /**
    * Returns a range of all the commentses where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end);
    }

    /**
    * Returns an ordered range of all the commentses where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid(uuid, start, end, orderByComparator);
    }

    /**
    * Returns the first comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the first comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_First(uuid, orderByComparator);
    }

    /**
    * Returns the last comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the last comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
    }

    /**
    * Returns the commentses before and after the current comments in the ordered set where uuid = &#63;.
    *
    * @param commentsId the primary key of the current comments
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments[] findByUuid_PrevAndNext(
        long commentsId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByUuid_PrevAndNext(commentsId, uuid, orderByComparator);
    }

    /**
    * Removes all the commentses where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid(uuid);
    }

    /**
    * Returns the number of commentses where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid(uuid);
    }

    /**
    * Returns the comments where uuid = &#63; and groupId = &#63; or throws a {@link com.liferay.docs.test.poc.NoSuchCommentsException} if it could not be found.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUUID_G(uuid, groupId);
    }

    /**
    * Returns the comments where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUUID_G(uuid, groupId);
    }

    /**
    * Returns the comments where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @param retrieveFromCache whether to use the finder cache
    * @return the matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByUUID_G(
        java.lang.String uuid, long groupId, boolean retrieveFromCache)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
    }

    /**
    * Removes the comments where uuid = &#63; and groupId = &#63; from the database.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the comments that was removed
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments removeByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().removeByUUID_G(uuid, groupId);
    }

    /**
    * Returns the number of commentses where uuid = &#63; and groupId = &#63;.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static int countByUUID_G(java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUUID_G(uuid, groupId);
    }

    /**
    * Returns all the commentses where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @return the matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid_C(
        java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid_C(uuid, companyId);
    }

    /**
    * Returns a range of all the commentses where uuid = &#63; and companyId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid_C(
        java.lang.String uuid, long companyId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByUuid_C(uuid, companyId, start, end);
    }

    /**
    * Returns an ordered range of all the commentses where uuid = &#63; and companyId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid_C(
        java.lang.String uuid, long companyId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
    }

    /**
    * Returns the first comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByUuid_C_First(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByUuid_C_First(uuid, companyId, orderByComparator);
    }

    /**
    * Returns the first comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByUuid_C_First(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
    }

    /**
    * Returns the last comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByUuid_C_Last(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByUuid_C_Last(uuid, companyId, orderByComparator);
    }

    /**
    * Returns the last comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByUuid_C_Last(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
    }

    /**
    * Returns the commentses before and after the current comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param commentsId the primary key of the current comments
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments[] findByUuid_C_PrevAndNext(
        long commentsId, java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByUuid_C_PrevAndNext(commentsId, uuid, companyId,
            orderByComparator);
    }

    /**
    * Removes all the commentses where uuid = &#63; and companyId = &#63; from the database.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByUuid_C(java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByUuid_C(uuid, companyId);
    }

    /**
    * Returns the number of commentses where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static int countByUuid_C(java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByUuid_C(uuid, companyId);
    }

    /**
    * Returns all the commentses where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @return the matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByG_G(
        long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByG_G(groupId, projectsId);
    }

    /**
    * Returns a range of all the commentses where groupId = &#63; and projectsId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByG_G(
        long groupId, long projectsId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByG_G(groupId, projectsId, start, end);
    }

    /**
    * Returns an ordered range of all the commentses where groupId = &#63; and projectsId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findByG_G(
        long groupId, long projectsId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByG_G(groupId, projectsId, start, end, orderByComparator);
    }

    /**
    * Returns the first comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByG_G_First(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByG_G_First(groupId, projectsId, orderByComparator);
    }

    /**
    * Returns the first comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByG_G_First(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByG_G_First(groupId, projectsId, orderByComparator);
    }

    /**
    * Returns the last comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByG_G_Last(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByG_G_Last(groupId, projectsId, orderByComparator);
    }

    /**
    * Returns the last comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByG_G_Last(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .fetchByG_G_Last(groupId, projectsId, orderByComparator);
    }

    /**
    * Returns the commentses before and after the current comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param commentsId the primary key of the current comments
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments[] findByG_G_PrevAndNext(
        long commentsId, long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence()
                   .findByG_G_PrevAndNext(commentsId, groupId, projectsId,
            orderByComparator);
    }

    /**
    * Removes all the commentses where groupId = &#63; and projectsId = &#63; from the database.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @throws SystemException if a system exception occurred
    */
    public static void removeByG_G(long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeByG_G(groupId, projectsId);
    }

    /**
    * Returns the number of commentses where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public static int countByG_G(long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countByG_G(groupId, projectsId);
    }

    /**
    * Caches the comments in the entity cache if it is enabled.
    *
    * @param comments the comments
    */
    public static void cacheResult(
        com.liferay.docs.test.poc.model.Comments comments) {
        getPersistence().cacheResult(comments);
    }

    /**
    * Caches the commentses in the entity cache if it is enabled.
    *
    * @param commentses the commentses
    */
    public static void cacheResult(
        java.util.List<com.liferay.docs.test.poc.model.Comments> commentses) {
        getPersistence().cacheResult(commentses);
    }

    /**
    * Creates a new comments with the primary key. Does not add the comments to the database.
    *
    * @param commentsId the primary key for the new comments
    * @return the new comments
    */
    public static com.liferay.docs.test.poc.model.Comments create(
        long commentsId) {
        return getPersistence().create(commentsId);
    }

    /**
    * Removes the comments with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param commentsId the primary key of the comments
    * @return the comments that was removed
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments remove(
        long commentsId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().remove(commentsId);
    }

    public static com.liferay.docs.test.poc.model.Comments updateImpl(
        com.liferay.docs.test.poc.model.Comments comments)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().updateImpl(comments);
    }

    /**
    * Returns the comments with the primary key or throws a {@link com.liferay.docs.test.poc.NoSuchCommentsException} if it could not be found.
    *
    * @param commentsId the primary key of the comments
    * @return the comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments findByPrimaryKey(
        long commentsId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findByPrimaryKey(commentsId);
    }

    /**
    * Returns the comments with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param commentsId the primary key of the comments
    * @return the comments, or <code>null</code> if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public static com.liferay.docs.test.poc.model.Comments fetchByPrimaryKey(
        long commentsId)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().fetchByPrimaryKey(commentsId);
    }

    /**
    * Returns all the commentses.
    *
    * @return the commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll();
    }

    /**
    * Returns a range of all the commentses.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end);
    }

    /**
    * Returns an ordered range of all the commentses.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of commentses
    * @throws SystemException if a system exception occurred
    */
    public static java.util.List<com.liferay.docs.test.poc.model.Comments> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().findAll(start, end, orderByComparator);
    }

    /**
    * Removes all the commentses from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public static void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        getPersistence().removeAll();
    }

    /**
    * Returns the number of commentses.
    *
    * @return the number of commentses
    * @throws SystemException if a system exception occurred
    */
    public static int countAll()
        throws com.liferay.portal.kernel.exception.SystemException {
        return getPersistence().countAll();
    }

    public static CommentsPersistence getPersistence() {
        if (_persistence == null) {
            _persistence = (CommentsPersistence) PortletBeanLocatorUtil.locate(com.liferay.docs.test.poc.service.ClpSerializer.getServletContextName(),
                    CommentsPersistence.class.getName());

            ReferenceRegistry.registerReference(CommentsUtil.class,
                "_persistence");
        }

        return _persistence;
    }

    /**
     * @deprecated As of 6.2.0
     */
    public void setPersistence(CommentsPersistence persistence) {
    }
}
