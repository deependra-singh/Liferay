package com.liferay.docs.test.poc.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.liferay.docs.test.poc.service.http.RegisterServiceSoap}.
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.http.RegisterServiceSoap
 * @generated
 */
public class RegisterSoap implements Serializable {
    private String _uuid;
    private long _registerId;
    private long _groupId;
    private long _companyId;
    private long _userId;
    private String _userName;
    private Date _createDate;
    private Date _modifiedDate;
    private String _email;
    private String _password;
    private String _firstname;
    private String _lastname;
    private String _country;

    public RegisterSoap() {
    }

    public static RegisterSoap toSoapModel(Register model) {
        RegisterSoap soapModel = new RegisterSoap();

        soapModel.setUuid(model.getUuid());
        soapModel.setRegisterId(model.getRegisterId());
        soapModel.setGroupId(model.getGroupId());
        soapModel.setCompanyId(model.getCompanyId());
        soapModel.setUserId(model.getUserId());
        soapModel.setUserName(model.getUserName());
        soapModel.setCreateDate(model.getCreateDate());
        soapModel.setModifiedDate(model.getModifiedDate());
        soapModel.setEmail(model.getEmail());
        soapModel.setPassword(model.getPassword());
        soapModel.setFirstname(model.getFirstname());
        soapModel.setLastname(model.getLastname());
        soapModel.setCountry(model.getCountry());

        return soapModel;
    }

    public static RegisterSoap[] toSoapModels(Register[] models) {
        RegisterSoap[] soapModels = new RegisterSoap[models.length];

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModel(models[i]);
        }

        return soapModels;
    }

    public static RegisterSoap[][] toSoapModels(Register[][] models) {
        RegisterSoap[][] soapModels = null;

        if (models.length > 0) {
            soapModels = new RegisterSoap[models.length][models[0].length];
        } else {
            soapModels = new RegisterSoap[0][0];
        }

        for (int i = 0; i < models.length; i++) {
            soapModels[i] = toSoapModels(models[i]);
        }

        return soapModels;
    }

    public static RegisterSoap[] toSoapModels(List<Register> models) {
        List<RegisterSoap> soapModels = new ArrayList<RegisterSoap>(models.size());

        for (Register model : models) {
            soapModels.add(toSoapModel(model));
        }

        return soapModels.toArray(new RegisterSoap[soapModels.size()]);
    }

    public long getPrimaryKey() {
        return _registerId;
    }

    public void setPrimaryKey(long pk) {
        setRegisterId(pk);
    }

    public String getUuid() {
        return _uuid;
    }

    public void setUuid(String uuid) {
        _uuid = uuid;
    }

    public long getRegisterId() {
        return _registerId;
    }

    public void setRegisterId(long registerId) {
        _registerId = registerId;
    }

    public long getGroupId() {
        return _groupId;
    }

    public void setGroupId(long groupId) {
        _groupId = groupId;
    }

    public long getCompanyId() {
        return _companyId;
    }

    public void setCompanyId(long companyId) {
        _companyId = companyId;
    }

    public long getUserId() {
        return _userId;
    }

    public void setUserId(long userId) {
        _userId = userId;
    }

    public String getUserName() {
        return _userName;
    }

    public void setUserName(String userName) {
        _userName = userName;
    }

    public Date getCreateDate() {
        return _createDate;
    }

    public void setCreateDate(Date createDate) {
        _createDate = createDate;
    }

    public Date getModifiedDate() {
        return _modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        _modifiedDate = modifiedDate;
    }

    public String getEmail() {
        return _email;
    }

    public void setEmail(String email) {
        _email = email;
    }

    public String getPassword() {
        return _password;
    }

    public void setPassword(String password) {
        _password = password;
    }

    public String getFirstname() {
        return _firstname;
    }

    public void setFirstname(String firstname) {
        _firstname = firstname;
    }

    public String getLastname() {
        return _lastname;
    }

    public void setLastname(String lastname) {
        _lastname = lastname;
    }

    public String getCountry() {
        return _country;
    }

    public void setCountry(String country) {
        _country = country;
    }
}
