package com.liferay.docs.test.poc.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CommentsService}.
 *
 * @author anuragch
 * @see CommentsService
 * @generated
 */
public class CommentsServiceWrapper implements CommentsService,
    ServiceWrapper<CommentsService> {
    private CommentsService _commentsService;

    public CommentsServiceWrapper(CommentsService commentsService) {
        _commentsService = commentsService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _commentsService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _commentsService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _commentsService.invokeMethod(name, parameterTypes, arguments);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public CommentsService getWrappedCommentsService() {
        return _commentsService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedCommentsService(CommentsService commentsService) {
        _commentsService = commentsService;
    }

    @Override
    public CommentsService getWrappedService() {
        return _commentsService;
    }

    @Override
    public void setWrappedService(CommentsService commentsService) {
        _commentsService = commentsService;
    }
}
