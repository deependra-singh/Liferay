package com.liferay.docs.test.poc.service.persistence;

import com.liferay.docs.test.poc.model.Comments;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the comments service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author anuragch
 * @see CommentsPersistenceImpl
 * @see CommentsUtil
 * @generated
 */
public interface CommentsPersistence extends BasePersistence<Comments> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link CommentsUtil} to access the comments persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the commentses where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the commentses where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the commentses where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last comments in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the commentses before and after the current comments in the ordered set where uuid = &#63;.
    *
    * @param commentsId the primary key of the current comments
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments[] findByUuid_PrevAndNext(
        long commentsId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the commentses where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of commentses where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the comments where uuid = &#63; and groupId = &#63; or throws a {@link com.liferay.docs.test.poc.NoSuchCommentsException} if it could not be found.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the comments where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the comments where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @param retrieveFromCache whether to use the finder cache
    * @return the matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByUUID_G(
        java.lang.String uuid, long groupId, boolean retrieveFromCache)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes the comments where uuid = &#63; and groupId = &#63; from the database.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the comments that was removed
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments removeByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of commentses where uuid = &#63; and groupId = &#63;.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public int countByUUID_G(java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the commentses where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @return the matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid_C(
        java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the commentses where uuid = &#63; and companyId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid_C(
        java.lang.String uuid, long companyId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the commentses where uuid = &#63; and companyId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByUuid_C(
        java.lang.String uuid, long companyId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByUuid_C_First(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByUuid_C_First(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByUuid_C_Last(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByUuid_C_Last(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the commentses before and after the current comments in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param commentsId the primary key of the current comments
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments[] findByUuid_C_PrevAndNext(
        long commentsId, java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the commentses where uuid = &#63; and companyId = &#63; from the database.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid_C(java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of commentses where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid_C(java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the commentses where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @return the matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByG_G(
        long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the commentses where groupId = &#63; and projectsId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByG_G(
        long groupId, long projectsId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the commentses where groupId = &#63; and projectsId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findByG_G(
        long groupId, long projectsId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByG_G_First(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByG_G_First(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByG_G_Last(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching comments, or <code>null</code> if a matching comments could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByG_G_Last(
        long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the commentses before and after the current comments in the ordered set where groupId = &#63; and projectsId = &#63;.
    *
    * @param commentsId the primary key of the current comments
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments[] findByG_G_PrevAndNext(
        long commentsId, long groupId, long projectsId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the commentses where groupId = &#63; and projectsId = &#63; from the database.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByG_G(long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of commentses where groupId = &#63; and projectsId = &#63;.
    *
    * @param groupId the group ID
    * @param projectsId the projects ID
    * @return the number of matching commentses
    * @throws SystemException if a system exception occurred
    */
    public int countByG_G(long groupId, long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the comments in the entity cache if it is enabled.
    *
    * @param comments the comments
    */
    public void cacheResult(com.liferay.docs.test.poc.model.Comments comments);

    /**
    * Caches the commentses in the entity cache if it is enabled.
    *
    * @param commentses the commentses
    */
    public void cacheResult(
        java.util.List<com.liferay.docs.test.poc.model.Comments> commentses);

    /**
    * Creates a new comments with the primary key. Does not add the comments to the database.
    *
    * @param commentsId the primary key for the new comments
    * @return the new comments
    */
    public com.liferay.docs.test.poc.model.Comments create(long commentsId);

    /**
    * Removes the comments with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param commentsId the primary key of the comments
    * @return the comments that was removed
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments remove(long commentsId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    public com.liferay.docs.test.poc.model.Comments updateImpl(
        com.liferay.docs.test.poc.model.Comments comments)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the comments with the primary key or throws a {@link com.liferay.docs.test.poc.NoSuchCommentsException} if it could not be found.
    *
    * @param commentsId the primary key of the comments
    * @return the comments
    * @throws com.liferay.docs.test.poc.NoSuchCommentsException if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments findByPrimaryKey(
        long commentsId)
        throws com.liferay.docs.test.poc.NoSuchCommentsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the comments with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param commentsId the primary key of the comments
    * @return the comments, or <code>null</code> if a comments with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Comments fetchByPrimaryKey(
        long commentsId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the commentses.
    *
    * @return the commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the commentses.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @return the range of commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the commentses.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.CommentsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of commentses
    * @param end the upper bound of the range of commentses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of commentses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Comments> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the commentses from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of commentses.
    *
    * @return the number of commentses
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
