package com.liferay.docs.test.poc.service.persistence;

import com.liferay.docs.test.poc.model.Projects;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the projects service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author anuragch
 * @see ProjectsPersistenceImpl
 * @see ProjectsUtil
 * @generated
 */
public interface ProjectsPersistence extends BasePersistence<Projects> {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never modify or reference this interface directly. Always use {@link ProjectsUtil} to access the projects persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
     */

    /**
    * Returns all the projectses where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByUuid(
        java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the projectses where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @return the range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByUuid(
        java.lang.String uuid, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the projectses where uuid = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByUuid(
        java.lang.String uuid, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByUuid_First(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where uuid = &#63;.
    *
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByUuid_Last(
        java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projectses before and after the current projects in the ordered set where uuid = &#63;.
    *
    * @param projectsId the primary key of the current projects
    * @param uuid the uuid
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects[] findByUuid_PrevAndNext(
        long projectsId, java.lang.String uuid,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the projectses where uuid = &#63; from the database.
    *
    * @param uuid the uuid
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses where uuid = &#63;.
    *
    * @param uuid the uuid
    * @return the number of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid(java.lang.String uuid)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projects where uuid = &#63; and groupId = &#63; or throws a {@link com.liferay.docs.test.poc.NoSuchProjectsException} if it could not be found.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projects where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projects where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @param retrieveFromCache whether to use the finder cache
    * @return the matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByUUID_G(
        java.lang.String uuid, long groupId, boolean retrieveFromCache)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes the projects where uuid = &#63; and groupId = &#63; from the database.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the projects that was removed
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects removeByUUID_G(
        java.lang.String uuid, long groupId)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses where uuid = &#63; and groupId = &#63;.
    *
    * @param uuid the uuid
    * @param groupId the group ID
    * @return the number of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public int countByUUID_G(java.lang.String uuid, long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the projectses where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @return the matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByUuid_C(
        java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the projectses where uuid = &#63; and companyId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @return the range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByUuid_C(
        java.lang.String uuid, long companyId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the projectses where uuid = &#63; and companyId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByUuid_C(
        java.lang.String uuid, long companyId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByUuid_C_First(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByUuid_C_First(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByUuid_C_Last(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByUuid_C_Last(
        java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projectses before and after the current projects in the ordered set where uuid = &#63; and companyId = &#63;.
    *
    * @param projectsId the primary key of the current projects
    * @param uuid the uuid
    * @param companyId the company ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects[] findByUuid_C_PrevAndNext(
        long projectsId, java.lang.String uuid, long companyId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the projectses where uuid = &#63; and companyId = &#63; from the database.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByUuid_C(java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses where uuid = &#63; and companyId = &#63;.
    *
    * @param uuid the uuid
    * @param companyId the company ID
    * @return the number of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public int countByUuid_C(java.lang.String uuid, long companyId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the projectses where groupId = &#63;.
    *
    * @param groupId the group ID
    * @return the matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByGroupId(
        long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the projectses where groupId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @return the range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByGroupId(
        long groupId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the projectses where groupId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByGroupId(
        long groupId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where groupId = &#63;.
    *
    * @param groupId the group ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByGroupId_First(
        long groupId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where groupId = &#63;.
    *
    * @param groupId the group ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByGroupId_First(
        long groupId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where groupId = &#63;.
    *
    * @param groupId the group ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByGroupId_Last(
        long groupId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where groupId = &#63;.
    *
    * @param groupId the group ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByGroupId_Last(
        long groupId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projectses before and after the current projects in the ordered set where groupId = &#63;.
    *
    * @param projectsId the primary key of the current projects
    * @param groupId the group ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects[] findByGroupId_PrevAndNext(
        long projectsId, long groupId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the projectses that the user has permission to view where groupId = &#63;.
    *
    * @param groupId the group ID
    * @return the matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> filterFindByGroupId(
        long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the projectses that the user has permission to view where groupId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @return the range of matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> filterFindByGroupId(
        long groupId, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the projectses that the user has permissions to view where groupId = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> filterFindByGroupId(
        long groupId, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projectses before and after the current projects in the ordered set of projectses that the user has permission to view where groupId = &#63;.
    *
    * @param projectsId the primary key of the current projects
    * @param groupId the group ID
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects[] filterFindByGroupId_PrevAndNext(
        long projectsId, long groupId,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the projectses where groupId = &#63; from the database.
    *
    * @param groupId the group ID
    * @throws SystemException if a system exception occurred
    */
    public void removeByGroupId(long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses where groupId = &#63;.
    *
    * @param groupId the group ID
    * @return the number of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public int countByGroupId(long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses that the user has permission to view where groupId = &#63;.
    *
    * @param groupId the group ID
    * @return the number of matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public int filterCountByGroupId(long groupId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the projectses where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @return the matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByP_S(
        long groupId, int status)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the projectses where groupId = &#63; and status = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param status the status
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @return the range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByP_S(
        long groupId, int status, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the projectses where groupId = &#63; and status = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param status the status
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findByP_S(
        long groupId, int status, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByP_S_First(
        long groupId, int status,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the first projects in the ordered set where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the first matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByP_S_First(
        long groupId, int status,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByP_S_Last(
        long groupId, int status,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the last projects in the ordered set where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the last matching projects, or <code>null</code> if a matching projects could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByP_S_Last(
        long groupId, int status,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projectses before and after the current projects in the ordered set where groupId = &#63; and status = &#63;.
    *
    * @param projectsId the primary key of the current projects
    * @param groupId the group ID
    * @param status the status
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects[] findByP_S_PrevAndNext(
        long projectsId, long groupId, int status,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the projectses that the user has permission to view where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @return the matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> filterFindByP_S(
        long groupId, int status)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the projectses that the user has permission to view where groupId = &#63; and status = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param status the status
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @return the range of matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> filterFindByP_S(
        long groupId, int status, int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the projectses that the user has permissions to view where groupId = &#63; and status = &#63;.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param groupId the group ID
    * @param status the status
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> filterFindByP_S(
        long groupId, int status, int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projectses before and after the current projects in the ordered set of projectses that the user has permission to view where groupId = &#63; and status = &#63;.
    *
    * @param projectsId the primary key of the current projects
    * @param groupId the group ID
    * @param status the status
    * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
    * @return the previous, current, and next projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects[] filterFindByP_S_PrevAndNext(
        long projectsId, long groupId, int status,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the projectses where groupId = &#63; and status = &#63; from the database.
    *
    * @param groupId the group ID
    * @param status the status
    * @throws SystemException if a system exception occurred
    */
    public void removeByP_S(long groupId, int status)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @return the number of matching projectses
    * @throws SystemException if a system exception occurred
    */
    public int countByP_S(long groupId, int status)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses that the user has permission to view where groupId = &#63; and status = &#63;.
    *
    * @param groupId the group ID
    * @param status the status
    * @return the number of matching projectses that the user has permission to view
    * @throws SystemException if a system exception occurred
    */
    public int filterCountByP_S(long groupId, int status)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Caches the projects in the entity cache if it is enabled.
    *
    * @param projects the projects
    */
    public void cacheResult(com.liferay.docs.test.poc.model.Projects projects);

    /**
    * Caches the projectses in the entity cache if it is enabled.
    *
    * @param projectses the projectses
    */
    public void cacheResult(
        java.util.List<com.liferay.docs.test.poc.model.Projects> projectses);

    /**
    * Creates a new projects with the primary key. Does not add the projects to the database.
    *
    * @param projectsId the primary key for the new projects
    * @return the new projects
    */
    public com.liferay.docs.test.poc.model.Projects create(long projectsId);

    /**
    * Removes the projects with the primary key from the database. Also notifies the appropriate model listeners.
    *
    * @param projectsId the primary key of the projects
    * @return the projects that was removed
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects remove(long projectsId)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    public com.liferay.docs.test.poc.model.Projects updateImpl(
        com.liferay.docs.test.poc.model.Projects projects)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projects with the primary key or throws a {@link com.liferay.docs.test.poc.NoSuchProjectsException} if it could not be found.
    *
    * @param projectsId the primary key of the projects
    * @return the projects
    * @throws com.liferay.docs.test.poc.NoSuchProjectsException if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects findByPrimaryKey(
        long projectsId)
        throws com.liferay.docs.test.poc.NoSuchProjectsException,
            com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the projects with the primary key or returns <code>null</code> if it could not be found.
    *
    * @param projectsId the primary key of the projects
    * @return the projects, or <code>null</code> if a projects with the primary key could not be found
    * @throws SystemException if a system exception occurred
    */
    public com.liferay.docs.test.poc.model.Projects fetchByPrimaryKey(
        long projectsId)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns all the projectses.
    *
    * @return the projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns a range of all the projectses.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @return the range of projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findAll(
        int start, int end)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns an ordered range of all the projectses.
    *
    * <p>
    * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.liferay.docs.test.poc.model.impl.ProjectsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
    * </p>
    *
    * @param start the lower bound of the range of projectses
    * @param end the upper bound of the range of projectses (not inclusive)
    * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
    * @return the ordered range of projectses
    * @throws SystemException if a system exception occurred
    */
    public java.util.List<com.liferay.docs.test.poc.model.Projects> findAll(
        int start, int end,
        com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Removes all the projectses from the database.
    *
    * @throws SystemException if a system exception occurred
    */
    public void removeAll()
        throws com.liferay.portal.kernel.exception.SystemException;

    /**
    * Returns the number of projectses.
    *
    * @return the number of projectses
    * @throws SystemException if a system exception occurred
    */
    public int countAll()
        throws com.liferay.portal.kernel.exception.SystemException;
}
