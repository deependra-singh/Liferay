package com.liferay.docs.test.poc.service.messaging;

import com.liferay.docs.test.poc.service.ClpSerializer;
import com.liferay.docs.test.poc.service.CommentsLocalServiceUtil;
import com.liferay.docs.test.poc.service.CommentsServiceUtil;
import com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil;
import com.liferay.docs.test.poc.service.ProjectsServiceUtil;
import com.liferay.docs.test.poc.service.RegisterLocalServiceUtil;
import com.liferay.docs.test.poc.service.RegisterServiceUtil;

import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.Message;


public class ClpMessageListener extends BaseMessageListener {
    public static String getServletContextName() {
        return ClpSerializer.getServletContextName();
    }

    @Override
    protected void doReceive(Message message) throws Exception {
        String command = message.getString("command");
        String servletContextName = message.getString("servletContextName");

        if (command.equals("undeploy") &&
                servletContextName.equals(getServletContextName())) {
            CommentsLocalServiceUtil.clearService();

            CommentsServiceUtil.clearService();
            ProjectsLocalServiceUtil.clearService();

            ProjectsServiceUtil.clearService();
            RegisterLocalServiceUtil.clearService();

            RegisterServiceUtil.clearService();
        }
    }
}
