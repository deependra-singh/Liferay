package com.liferay.docs.test.poc.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link RegisterService}.
 *
 * @author anuragch
 * @see RegisterService
 * @generated
 */
public class RegisterServiceWrapper implements RegisterService,
    ServiceWrapper<RegisterService> {
    private RegisterService _registerService;

    public RegisterServiceWrapper(RegisterService registerService) {
        _registerService = registerService;
    }

    /**
    * Returns the Spring bean ID for this bean.
    *
    * @return the Spring bean ID for this bean
    */
    @Override
    public java.lang.String getBeanIdentifier() {
        return _registerService.getBeanIdentifier();
    }

    /**
    * Sets the Spring bean ID for this bean.
    *
    * @param beanIdentifier the Spring bean ID for this bean
    */
    @Override
    public void setBeanIdentifier(java.lang.String beanIdentifier) {
        _registerService.setBeanIdentifier(beanIdentifier);
    }

    @Override
    public java.lang.Object invokeMethod(java.lang.String name,
        java.lang.String[] parameterTypes, java.lang.Object[] arguments)
        throws java.lang.Throwable {
        return _registerService.invokeMethod(name, parameterTypes, arguments);
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
     */
    public RegisterService getWrappedRegisterService() {
        return _registerService;
    }

    /**
     * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
     */
    public void setWrappedRegisterService(RegisterService registerService) {
        _registerService = registerService;
    }

    @Override
    public RegisterService getWrappedService() {
        return _registerService;
    }

    @Override
    public void setWrappedService(RegisterService registerService) {
        _registerService = registerService;
    }
}
