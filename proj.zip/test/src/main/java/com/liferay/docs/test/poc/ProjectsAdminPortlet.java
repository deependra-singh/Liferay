package com.liferay.docs.test.poc;

import java.io.IOException;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.liferay.docs.test.poc.images.ImagesUploadDownload;
import com.liferay.docs.test.poc.model.Projects;
import com.liferay.docs.test.poc.service.ProjectsLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.search.Indexer;
import com.liferay.portal.kernel.search.IndexerRegistryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.service.DLAppServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ProjectsAdminPortlet
 */
public class ProjectsAdminPortlet extends MVCPortlet {
 
public void approveStatus(ActionRequest request,ActionResponse response) throws PortalException, SystemException
{
	long projectsId=ParamUtil.getLong(request, "projectsId");
	long userId=ParamUtil.getLong(request, "userId");
	Projects projects=ProjectsLocalServiceUtil.getProjects(projectsId);
	ServiceContext serviceContext=ServiceContextFactory.getInstance(request);
	ProjectsLocalServiceUtil.updateStatus(userId, projectsId, 0, serviceContext);
	Indexer indexer = IndexerRegistryUtil.nullSafeGetIndexer(Projects.class);
	indexer.reindex(projects);
	System.out.println("status Accepted");
}

public void deleteProjects(ActionRequest request, ActionResponse response) {
	long projectsId = ParamUtil.getLong(request, "projectId");
	try {
		ServiceContext serviceContext = ServiceContextFactory.getInstance(Projects.class.getName(), request);
		response.setRenderParameter("projectId", Long.toString(projectsId));
		ProjectsLocalServiceUtil.deleteProjects(projectsId, serviceContext);
		response.setRenderParameter("jspPage", "/html/projectsadmin/view.jsp");
	} 
	catch (Exception e) {
		SessionErrors.add(request, e.getClass().getName());
	}
}


public void downloadFiles(ActionRequest actionRequest, ActionResponse actionResponse)
		throws IOException, PortletException, PortalException, SystemException {
	long projectsId=ParamUtil.getLong(actionRequest, "projectId");
	//DLAppServiceUtil.deleteFileEntry(26301);
	ImagesUploadDownload img=new ImagesUploadDownload();
	ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
	Map<String, String> urlMap =img. getAllFileLink(themeDisplay);
	actionRequest.setAttribute("urlMap", urlMap);
	actionRequest.setAttribute("projectId",projectsId);
	actionResponse.setRenderParameter("jspPage", "/html/projectsadmin/edit_projects.jsp");
}
}

