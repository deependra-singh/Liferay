package com.liferay.docs.test.poc.model.impl;

import com.liferay.docs.test.poc.model.Register;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Register in entity cache.
 *
 * @author anuragch
 * @see Register
 * @generated
 */
public class RegisterCacheModel implements CacheModel<Register>, Externalizable {
    public String uuid;
    public long registerId;
    public long groupId;
    public long companyId;
    public long userId;
    public String userName;
    public long createDate;
    public long modifiedDate;
    public String email;
    public String password;
    public String firstname;
    public String lastname;
    public String country;

    @Override
    public String toString() {
        StringBundler sb = new StringBundler(27);

        sb.append("{uuid=");
        sb.append(uuid);
        sb.append(", registerId=");
        sb.append(registerId);
        sb.append(", groupId=");
        sb.append(groupId);
        sb.append(", companyId=");
        sb.append(companyId);
        sb.append(", userId=");
        sb.append(userId);
        sb.append(", userName=");
        sb.append(userName);
        sb.append(", createDate=");
        sb.append(createDate);
        sb.append(", modifiedDate=");
        sb.append(modifiedDate);
        sb.append(", email=");
        sb.append(email);
        sb.append(", password=");
        sb.append(password);
        sb.append(", firstname=");
        sb.append(firstname);
        sb.append(", lastname=");
        sb.append(lastname);
        sb.append(", country=");
        sb.append(country);
        sb.append("}");

        return sb.toString();
    }

    @Override
    public Register toEntityModel() {
        RegisterImpl registerImpl = new RegisterImpl();

        if (uuid == null) {
            registerImpl.setUuid(StringPool.BLANK);
        } else {
            registerImpl.setUuid(uuid);
        }

        registerImpl.setRegisterId(registerId);
        registerImpl.setGroupId(groupId);
        registerImpl.setCompanyId(companyId);
        registerImpl.setUserId(userId);

        if (userName == null) {
            registerImpl.setUserName(StringPool.BLANK);
        } else {
            registerImpl.setUserName(userName);
        }

        if (createDate == Long.MIN_VALUE) {
            registerImpl.setCreateDate(null);
        } else {
            registerImpl.setCreateDate(new Date(createDate));
        }

        if (modifiedDate == Long.MIN_VALUE) {
            registerImpl.setModifiedDate(null);
        } else {
            registerImpl.setModifiedDate(new Date(modifiedDate));
        }

        if (email == null) {
            registerImpl.setEmail(StringPool.BLANK);
        } else {
            registerImpl.setEmail(email);
        }

        if (password == null) {
            registerImpl.setPassword(StringPool.BLANK);
        } else {
            registerImpl.setPassword(password);
        }

        if (firstname == null) {
            registerImpl.setFirstname(StringPool.BLANK);
        } else {
            registerImpl.setFirstname(firstname);
        }

        if (lastname == null) {
            registerImpl.setLastname(StringPool.BLANK);
        } else {
            registerImpl.setLastname(lastname);
        }

        if (country == null) {
            registerImpl.setCountry(StringPool.BLANK);
        } else {
            registerImpl.setCountry(country);
        }

        registerImpl.resetOriginalValues();

        return registerImpl;
    }

    @Override
    public void readExternal(ObjectInput objectInput) throws IOException {
        uuid = objectInput.readUTF();
        registerId = objectInput.readLong();
        groupId = objectInput.readLong();
        companyId = objectInput.readLong();
        userId = objectInput.readLong();
        userName = objectInput.readUTF();
        createDate = objectInput.readLong();
        modifiedDate = objectInput.readLong();
        email = objectInput.readUTF();
        password = objectInput.readUTF();
        firstname = objectInput.readUTF();
        lastname = objectInput.readUTF();
        country = objectInput.readUTF();
    }

    @Override
    public void writeExternal(ObjectOutput objectOutput)
        throws IOException {
        if (uuid == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(uuid);
        }

        objectOutput.writeLong(registerId);
        objectOutput.writeLong(groupId);
        objectOutput.writeLong(companyId);
        objectOutput.writeLong(userId);

        if (userName == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(userName);
        }

        objectOutput.writeLong(createDate);
        objectOutput.writeLong(modifiedDate);

        if (email == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(email);
        }

        if (password == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(password);
        }

        if (firstname == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(firstname);
        }

        if (lastname == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(lastname);
        }

        if (country == null) {
            objectOutput.writeUTF(StringPool.BLANK);
        } else {
            objectOutput.writeUTF(country);
        }
    }
}
