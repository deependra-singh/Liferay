package com.liferay.docs.test.poc.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.docs.test.poc.model.Register;
import com.liferay.docs.test.poc.service.RegisterLocalServiceUtil;
import com.liferay.docs.test.poc.service.base.RegisterLocalServiceBaseImpl;
import com.liferay.portal.NoSuchUserException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;

/**
 * The implementation of the register local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.liferay.docs.test.poc.service.RegisterLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author anuragch
 * @see com.liferay.docs.test.poc.service.base.RegisterLocalServiceBaseImpl
 * @see com.liferay.docs.test.poc.service.RegisterLocalServiceUtil
 */
public class RegisterLocalServiceImpl extends RegisterLocalServiceBaseImpl {
    /*
     * NOTE FOR DEVELOPERS:
     *
     * Never reference this interface directly. Always use {@link com.liferay.docs.test.poc.service.RegisterLocalServiceUtil} to access the register local service.
     */
	public List<Register> getUsers(long groupId) throws SystemException
	{
	return registerPersistence.findByGroupId(groupId);	
	}
	
	public List<Register> getUsers(long groupId,int start,int end) throws SystemException
	{
		return registerPersistence.findByGroupId(groupId, start, end);
	}
	
	public int getCountUsers(long groupId) throws SystemException
	{
		return registerPersistence.countByGroupId(groupId);
	}
	
	public Register addUsers(long userId,String email,String password,String firstname,String lastname,String country,ServiceContext serviceContext) throws SystemException, NoSuchUserException
	{
		Date date=new Date();
		long registerId=counterLocalService.increment();
		User user=userPersistence.findByPrimaryKey(userId);
		long groupId=serviceContext.getScopeGroupId();
		Register register=registerPersistence.create(registerId);
		register.setUuid(serviceContext.getUuid());
		register.setUserId(userId);
		register.setGroupId(groupId);
		register.setCompanyId(user.getCompanyId());
		register.setUserName(user.getFullName());
		register.setCreateDate(serviceContext.getCreateDate(date));
		register.setModifiedDate(serviceContext.getModifiedDate(date));
		register.setEmail(email);
		register.setPassword(password);
		register.setFirstname(firstname);
		register.setLastname(lastname);
		register.setCountry(country);
		register.setExpandoBridgeAttributes(serviceContext);
		registerPersistence.update(register);
		return register;
	}
	
	public boolean loginUser(String email,String password,ServiceContext serviceContext ) throws SystemException
	{
		boolean flag=false;
		long groupId=serviceContext.getScopeGroupId();
		int count=RegisterLocalServiceUtil.getCountUsers(groupId);
		List<Register> results=RegisterLocalServiceUtil.getUsers(groupId);
		for (Register register : results)
		{
			if(register.getEmail().equals(email))
				{
				System.out.println("1");
				if(register.getPassword().equals(password))
				{
					System.out.println("2");
					flag=true;
				}
				}
		}
		return flag;
	}
}
